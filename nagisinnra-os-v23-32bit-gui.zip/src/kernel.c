#include <stdint.h>

#define W 800
#define H 600
#define FSBASE 0x20000u
#define VBE_INFO 0x90000u
static volatile uint16_t *const fb=(volatile uint16_t*)0xE0000000u;
/* v23: system RAM back buffer. All drawing goes here; one full-frame copy
   is performed after a redraw. This removes visible tearing/flicker. */
static volatile uint16_t *const backbuf=(volatile uint16_t*)0x00300000u;
static uint32_t fb_phys=0, pitch=1600;

static inline uint8_t inb(uint16_t p){uint8_t v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outb(uint16_t p,uint8_t v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}

static uint16_t rgb(uint8_t r,uint8_t g,uint8_t b){return (uint16_t)(((r>>3)<<11)|((g>>2)<<5)|(b>>3));}
static void putp(int x,int y,uint16_t c){if((unsigned)x<W&&(unsigned)y<H) backbuf[(uintptr_t)y*W+(uintptr_t)x]=c;}
static void fill(int x,int y,int w,int h,uint16_t c){if(w<=0||h<=0)return;if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}if(x+w>W)w=W-x;if(y+h>H)h=H-y;if(w<=0||h<=0)return;for(int yy=0;yy<h;yy++){volatile uint16_t*d=backbuf+(uintptr_t)(y+yy)*W+(uintptr_t)x;for(int xx=0;xx<w;xx++)d[xx]=c;}}
static int inside(int x,int y,int w,int h,int px,int py){return px>=x&&px<x+w&&py>=y&&py<y+h;}

/* Compact 5x7 font: A-Z, 0-9, space and UI punctuation. */
static const uint8_t font[][7]={
{14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},
{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,14},{17,17,17,31,17,17,17},
{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},
{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},
{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,27,17},{17,17,10,4,10,17,17},
{17,17,10,4,4,4,4},{31,1,2,4,8,16,31},
{14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},
{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},
{14,17,17,14,17,17,14},{14,17,17,15,1,1,14},
{0,0,0,0,0,0,0},{0,4,0,0,0,4,0},{0,0,0,31,0,0,0},{0,0,0,0,0,0,4},
{31,1,2,4,8,16,31},{31,16,8,4,2,1,31}
};
static const char chars[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 :-._/< >";
static const uint8_t*glyph(char c){if(c>='a'&&c<='z')c=(char)(c-'a'+'A');for(unsigned i=0;i<sizeof(chars)-1;i++)if(chars[i]==c)return font[i];return font[36];}
static void text(int x,int y,const char*s,uint16_t c,int scale){while(*s){const uint8_t*g=glyph(*s++);for(int r=0;r<7;r++)for(int b=0;b<5;b++)if(g[r]&(1u<<(4-b)))fill(x+b*scale,y+r*scale,scale,scale,c);x+=6*scale;}}

/* Rounded rectangles. */
static void roundrect(int x,int y,int w,int h,int r,uint16_t c){
 if(r<1){fill(x,y,w,h,c);return;} if(r*2>w)r=w/2;if(r*2>h)r=h/2;
 fill(x+r,y,w-2*r,h,c);fill(x,y+r,r,h-2*r,c);fill(x+w-r,y+r,r,h-2*r,c);
 for(int yy=0;yy<r;yy++)for(int xx=0;xx<r;xx++){int dx=r-1-xx,dy=r-1-yy;if(dx*dx+dy*dy<r*r){putp(x+xx,y+yy,c);putp(x+w-1-xx,y+yy,c);putp(x+xx,y+h-1-yy,c);putp(x+w-1-xx,y+h-1-yy,c);}}
}

/* Background: deep sky + deterministic stars + diagonal Milky Way band. */
static uint32_t rng=0x51a7c3d1u;
static uint32_t rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static void draw_sky(void){
 uint16_t top=rgb(5,7,25), bottom=rgb(2,3,12);
 for(int y=0;y<H;y++){uint8_t t=(uint8_t)((y*255)/(H-1));uint8_t r=(uint8_t)(((top>>11)&31)*8 + (((bottom>>11)&31)*8-((top>>11)&31)*8)*t/255);(void)r;uint8_t rr=(uint8_t)(5-(3*t/255)),gg=(uint8_t)(7-(4*t/255)),bb=(uint8_t)(25-(13*t/255));fill(0,y,W,1,rgb(rr,gg,bb));}
 /* soft Milky Way: many tiny translucent-looking pale pixels, concentrated along x/1.8 - y/2.0. */
 rng=0x51a7c3d1u;
 for(int i=0;i<2600;i++){int x=(int)(rnd()%W), y=(int)(rnd()%H);int band=(x*3/4 + 80);int d=y-band;if(d<0)d=-d;if(d<55){uint32_t q=rnd()%100;int size=(q<92)?1:2;uint8_t br=(uint8_t)(22+(55-(d<55?d:55))/2+(rnd()%35));uint8_t rr=(uint8_t)(br/2),gg=(uint8_t)(br*3/4),bb=br;roundrect(x,y,size,size,1,rgb(rr,gg,bb));}}
 /* brighter stars */
 for(int i=0;i<180;i++){int x=(int)(rnd()%W),y=(int)(rnd()%H);uint8_t b=(uint8_t)(120+rnd()%136);putp(x,y,rgb(b,b,b));if((rnd()&7)==0){putp(x+1,y,rgb(b/2,b/2,b/2));putp(x-1,y,rgb(b/2,b/2,b/2));}}
}

/* FAT12 RAM volume. */
static uint8_t*fs=(uint8_t*)FSBASE;
static uint16_t fat12_get(uint16_t cl){uint32_t o=512+((uint32_t)cl*3)/2;uint16_t v=fs[o]|((uint16_t)fs[o+1]<<8);return (cl&1)?(v>>4)&0xfff:v&0xfff;}
static uint8_t*cluster_ptr(uint16_t cl){return fs+(5u+(cl-2u))*512u;}
static void name83(char*out,const uint8_t*e){int k=0;for(int i=0;i<8&&e[i]!=' ';i++)out[k++]=e[i];if(e[8]!=' '){out[k++]='.';for(int i=8;i<11&&e[i]!=' ';i++)out[k++]=e[i];}out[k]=0;}
static int file_count(void){int n=0;for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]!=0xe5&&e[11]!=0x0f)n++;}return n;}
static int read_file(int ent,char*out,int cap){if(ent<0)return 0;uint8_t*e=fs+1536+ent*32;uint16_t cl=e[26]|((uint16_t)e[27]<<8);uint32_t sz=e[28]|((uint32_t)e[29]<<8)|((uint32_t)e[30]<<16)|((uint32_t)e[31]<<24);if(sz>(uint32_t)cap-1)sz=cap-1;uint32_t pos=0;while(cl>=2&&cl<0xff8&&pos<sz){uint8_t*p=cluster_ptr(cl);uint32_t take=sz-pos;if(take>512)take=512;for(uint32_t i=0;i<take;i++)out[pos+i]=(char)p[i];pos+=take;cl=fat12_get(cl);}out[pos]=0;return (int)pos;}
static int find_entry(const char*name){for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;char n[16];name83(n,e);int j=0;while(name[j]&&n[j]&&name[j]==n[j])j++;if(!name[j]&&!n[j])return i;}return -1;}

/* PS/2 */
static int mx=400,my=300;static uint8_t mp[3],mpos,mbuttons,mlast,mpress;
static uint8_t shift;
static void wait_ibf_clear(void){for(int i=0;i<100000;i++)if(!(inb(0x64)&2))return;}
static int wait_obf(void){for(int i=0;i<100000;i++)if(inb(0x64)&1)return 1;return 0;}
static void mouse_cmd(uint8_t c){wait_ibf_clear();outb(0x64,0xd4);wait_ibf_clear();outb(0x60,c);}
static void mouse_init(void){wait_ibf_clear();outb(0x64,0xa8);mouse_cmd(0xf4);if(wait_obf())(void)inb(0x60);mpos=0;mx=400;my=300;mbuttons=mlast=mpress=0;}
static int mouse_poll(void){int changed=0;while((inb(0x64)&1)&&(inb(0x64)&0x20)){uint8_t b=inb(0x60);mp[mpos++]=b;if(mpos<3)continue;mpos=0;int dx=(int8_t)mp[1],dy=(int8_t)mp[2];if(!(mp[0]&0xc0)){int nx=mx+dx,ny=my-dy;if(nx<0)nx=0;if(nx>=W)nx=W-1;if(ny<0)ny=0;if(ny>=H)ny=H-1;if(nx!=mx||ny!=my)changed=1;mx=nx;my=ny;}mbuttons=mp[0]&7;if((mbuttons&1)&&!(mlast&1))mpress=1;mlast=mbuttons;}return changed;}
static int keyboard_get(uint8_t*out){if(!(inb(0x64)&1))return 0;if(inb(0x64)&0x20)return 0;uint8_t s=inb(0x60);if(s==0x2a||s==0x36){shift=1;return 0;}if(s==0xaa||s==0xb6){shift=0;return 0;}if(s&0x80)return 0;*out=s;return 1;}
static char keychar(uint8_t s){
 switch(s){
  case 0x02:return shift?'!':'1'; case 0x03:return shift?'@':'2'; case 0x04:return shift?'#':'3';
  case 0x05:return shift?'$':'4'; case 0x06:return shift?'%':'5'; case 0x07:return shift?'^':'6';
  case 0x08:return shift?'&':'7'; case 0x09:return shift?'*':'8'; case 0x0a:return shift?'(':'9';
  case 0x0b:return shift?')':'0'; case 0x0c:return shift?'_':'-'; case 0x0d:return shift?'+':'=';
  case 0x0e:return '\b'; case 0x0f:return '\t'; case 0x10:return 'q'; case 0x11:return 'w';
  case 0x12:return 'e'; case 0x13:return 'r'; case 0x14:return 't'; case 0x15:return 'y';
  case 0x16:return 'u'; case 0x17:return 'i'; case 0x18:return 'o'; case 0x19:return 'p';
  case 0x1a:return shift?'{':'['; case 0x1b:return shift?'}':']'; case 0x1c:return '\n';
  case 0x1e:return 'a'; case 0x1f:return 's'; case 0x20:return 'd'; case 0x21:return 'f';
  case 0x22:return 'g'; case 0x23:return 'h'; case 0x24:return 'j'; case 0x25:return 'k';
  case 0x26:return 'l'; case 0x27:return shift?':':';'; case 0x28:return shift?'"':'\'';
  case 0x29:return shift?'~':'`'; case 0x2b:return shift?'|':'\\'; case 0x2c:return 'z';
  case 0x2d:return 'x'; case 0x2e:return 'c'; case 0x2f:return 'v'; case 0x30:return 'b';
  case 0x31:return 'n'; case 0x32:return 'm'; case 0x33:return shift?'<':','; case 0x34:return shift?'>':'.';
  case 0x35:return shift?'?':'/'; case 0x39:return ' '; default:return 0;
 }
}

#define APP_TERM 0
#define APP_FILES 1
#define APP_EDIT 2
#define APP_PAINT 3
#define APP_TASKS 4
#define APP_BROWSER 5
typedef struct {int x,y,w,h,open,drag,ox,oy;uint8_t app;char title[16];} Window;
static Window win[6];static int active=0,drag_win=-1;
static char term_in[48];static int term_n;
static char term_out[9][55];static int term_lines;
static char editor[513];static int editor_n,editor_file=-1;
static int paint_color=14;
static char browser_url[64];
static int browser_focus=0;
static int browser_url_n;
static char browser_lines[12][72];
static int browser_n;
extern int net_init(void);
extern int net_http_get(const char*host,const char*path,char*out,int cap);

static void scpy(char*d,const char*s,int n){int i=0;for(;i<n-1&&s[i];i++)d[i]=s[i];d[i]=0;}
static void init_windows(void){
 win[0]=(Window){64,112,430,300,1,0,0,0,APP_TERM,"Terminal"};
 win[1]=(Window){190,145,390,285,0,0,0,0,APP_FILES,"Files"};
 win[2]=(Window){220,128,420,290,0,0,0,0,APP_EDIT,"Editor"};
 win[3]=(Window){250,105,430,340,0,0,0,0,APP_PAINT,"Paint"};
 win[4]=(Window){310,170,260,220,0,0,0,0,APP_TASKS,"Tasks"};
 win[5]=(Window){70,62,660,450,0,0,0,0,APP_BROWSER,"Browser"};
}
static void titlebar(Window*w){
 /* Ultra-thin, 22px chrome: the desktop is the frame. */
 roundrect(w->x,w->y,w->w,22,5,rgb(18,21,38));
 fill(w->x+5,w->y,w->w-10,11,rgb(18,21,38));
 text(w->x+10,w->y+7,w->title,rgb(225,231,248),1);
 /* tiny close control, intentionally subtle */
 roundrect(w->x+w->w-22,w->y+7,10,8,3,rgb(175,55,78));
}
static void window_bg(Window*w){
 /* 1px visual edge + almost-black content. */
 roundrect(w->x,w->y+18,w->w,w->h-18,5,rgb(3,5,12));
 fill(w->x+5,w->y+18,w->w-10,w->h-23,rgb(3,5,12));
}
static void desktop(void){
 draw_sky();
 /* No heavy desktop bezel. Only a tiny brand mark. */
 text(20,18,"NAGISINNRA",rgb(225,231,248),1);
 text(694,18,"V22",rgb(135,160,205),1);
}
static void taskbar(void){
 /* 22px thin taskbar. */
 fill(0,578,W,22,rgb(8,10,22));
 fill(0,578,W,1,rgb(42,49,75));
 text(12,585,"N",rgb(115,220,255),1);
 int x=42;
 const char*names[]={"Terminal","Files","Edit","Paint","Tasks","Web"};
 for(int i=0;i<6;i++){
  int ww=(i==0)?62:52;
  uint16_t bg=(active==i&&win[i].open)?rgb(37,48,78):rgb(8,10,22);
  roundrect(x,580,ww,18,4,bg);
  text(x+8,586,names[i],(active==i&&win[i].open)?rgb(240,245,255):rgb(155,168,195),1);
  x+=ww+4;
 }
 text(724,586,"READY",rgb(105,225,165),1);
}
static void draw_term(Window*w){
 window_bg(w);titlebar(w);
 text(w->x+18,w->y+48,"NAGISINNRA OS",rgb(100,255,160),1);
 int yy=w->y+70;for(int i=0;i<term_lines&&yy<w->y+w->h-82;i++){text(w->x+18,yy,term_out[i],rgb(190,200,225),1);yy+=12;}
 text(w->x+18,w->y+w->h-64,"NAGISINNRA>",rgb(100,220,255),1);
 text(w->x+108,w->y+w->h-64,term_in,rgb(245,245,255),1);
 fill(w->x+108+term_n*6,w->y+w->h-66,5,9,rgb(245,245,255));
 text(w->x+18,w->y+w->h-35,"HELP VER DIR TYPE",rgb(150,170,205),1);
}
static void draw_files(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+48,"FAT12 VOLUME",rgb(100,255,160),1);int row=0;for(int i=0;i<32&&row<12;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;char n[16];name83(n,e);text(w->x+22,w->y+76+row*17,n,rgb(235,240,255),2);row++;}text(w->x+18,w->y+w->h-32,"CLICK FILE TO OPEN",rgb(160,180,220),2);}
static void draw_editor(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+48,"TEXT EDITOR",rgb(100,255,160),1);int yy=w->y+76;int col=w->x+18;for(int i=0;i<editor_n&&yy<w->y+w->h-55;i++){char one[2]={editor[i],0};if(editor[i]=='\n'){yy+=17;col=w->x+18;}else{text(col,yy,one,rgb(240,240,250),2);col+=12;if(col>w->x+w->w-30){yy+=17;col=w->x+18;}}}roundrect(w->x+18,w->y+w->h-42,76,28,6,rgb(40,190,190));text(w->x+31,w->y+w->h-34,"SAVE",rgb(0,0,0),2);roundrect(w->x+104,w->y+w->h-42,76,28,6,rgb(40,190,190));text(w->x+117,w->y+w->h-34,"OPEN",rgb(0,0,0),2);}
static void draw_paint(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+48,"PAINT",rgb(100,255,160),1);roundrect(w->x+18,w->y+72,w->w-36,w->h-125,6,rgb(8,9,16));for(int i=0;i<8;i++){roundrect(w->x+20+i*30,w->y+w->h-42,22,22,5,rgb((i&1)?255:80,(i&2)?220:100,(i&4)?255:120));}}
static void draw_tasks(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+48,"MULTITASK",rgb(100,255,160),1);int row=0;for(int i=0;i<6;i++)if(win[i].open){text(w->x+20,w->y+78+row*25,win[i].title,(i==active)?rgb(100,255,180):rgb(235,240,255),2);row++;}}
static int starts(const char*s,const char*p);
static void browser_line(const char*s){if(browser_n<12){scpy(browser_lines[browser_n++],s,72);return;}for(int i=1;i<12;i++)scpy(browser_lines[i-1],browser_lines[i],72);scpy(browser_lines[11],s,72);}
static void browser_home(void){browser_n=0;browser_line("NAGISINNRA OS BROWSER");browser_line("REAL HTTP/1.0 NETWORKING");browser_line("");browser_line("Enter: http://host/path");browser_line("Example: http://neverssl.com/");browser_line("");browser_line("nagisinnra://home");browser_line("file://README.TXT");browser_line("file://ABOUT.TXT");}
static void browser_open(const char*u){
 scpy(browser_url,u,64);browser_url_n=0;while(browser_url[browser_url_n])browser_url_n++;browser_n=0;
 if(starts(u,"NAGISINNRA://HOME")||starts(u,"nagisinnra://home")){browser_home();return;}
 if(starts(u,"FILE://")||starts(u,"file://")){const char*name=u+7;int ent=find_entry(name);if(ent<0){browser_line("404 - FILE NOT FOUND");return;}char b[768];int n=read_file(ent,b,sizeof(b));browser_line(name);browser_line("");char line[72];int j=0;for(int i=0;i<n;i++){char ch=b[i];if(ch=='\r')continue;if(ch=='\n'||j>=70){line[j]=0;browser_line(line);j=0;}else line[j++]=ch;}if(j){line[j]=0;browser_line(line);}return;}
 if(starts(u,"HTTP://")||starts(u,"http://")){const char*host=u+7;const char*slash=host;while(*slash&&*slash!='/')slash++;char h[64];int hn=(int)(slash-host);if(hn<=0||hn>=63){browser_line("BAD URL");return;}for(int i=0;i<hn;i++)h[i]=host[i];h[hn]=0;const char*path=*slash?slash:"/";char body[1536];browser_line("CONNECTING...");browser_line("DNS / ARP / TCP / HTTP");int n=net_http_get(h,path,body,sizeof(body));if(n<0){browser_line("NETWORK ERROR");browser_line("Use v86 with NE2000 networking");browser_line("Backend: fetch / wsproxy / wisp");return;}browser_n=0;browser_line(h);browser_line("");int j=0;char line[72];for(int i=0;i<n;i++){char ch=body[i];if(ch=='\r')continue;if(ch=='\n'||j>=70){line[j]=0;browser_line(line);j=0;}else if((unsigned char)ch>=32||ch=='\t')line[j++]=ch;}if(j){line[j]=0;browser_line(line);}return;}
 browser_line("URL NOT SUPPORTED");browser_line("Use http://host/path");
}
static void draw_browser(Window*w){window_bg(w);titlebar(w);roundrect(w->x+16,w->y+32,w->w-32,24,5,rgb(236,239,247));text(w->x+26,w->y+40,browser_url,rgb(15,18,28),1);if(browser_focus)fill(w->x+26+browser_url_n*6,w->y+39,5,9,rgb(20,25,35));roundrect(w->x+w->w-62,w->y+32,38,24,5,rgb(55,180,210));text(w->x+w->w-52,w->y+40,"GO",rgb(0,0,0),1);int yy=w->y+72;for(int i=0;i<browser_n&&yy<w->y+w->h-24;i++){text(w->x+22,yy,browser_lines[i],rgb(225,230,245),1);yy+=16;}}
static void cursor(void){for(int i=0;i<11;i++)for(int j=0;j<=i/2;j++)putp(mx+i,my+j,rgb(255,255,255));}
static void present(void){
 /* Copy the completed back buffer to the physical LFB in scanline order. */
 for(int y=0;y<H;y++){
  volatile uint16_t *dst=(volatile uint16_t*)((uintptr_t)fb_phys+(uintptr_t)y*pitch);
  volatile const uint16_t *src=backbuf+(uintptr_t)y*W;
  for(int x=0;x<W;x++)dst[x]=src[x];
 }
}
static void redraw(void){
 desktop();
 for(int i=0;i<6;i++)if(win[i].open){
  switch(win[i].app){case APP_TERM:draw_term(&win[i]);break;case APP_FILES:draw_files(&win[i]);break;case APP_EDIT:draw_editor(&win[i]);break;case APP_PAINT:draw_paint(&win[i]);break;case APP_TASKS:draw_tasks(&win[i]);break;case APP_BROWSER:draw_browser(&win[i]);break;}
 }
 taskbar();
 cursor();
 present();
}

static void term_line(const char*s){
 if(term_lines<9){scpy(term_out[term_lines++],s,55);return;}
 for(int i=1;i<9;i++)scpy(term_out[i-1],term_out[i],55);
 scpy(term_out[8],s,55);
}
static int starts(const char*s,const char*p){while(*p){if(*s++!=*p++)return 0;}return 1;}
static void term_command(const char*cmd){
 char c[48];scpy(c,cmd,48);
 for(int i=0;c[i];i++)if(c[i]>='a'&&c[i]<='z')c[i]=(char)(c[i]-'a'+'A');
 if(!c[0])return;
 if(starts(c,"VER") && c[3]==0){term_line("NAGISINNRA OS V23");term_line("32-BIT I386 / VBE 800X600 / NET");}
 else if(starts(c,"HELP") && c[4]==0){term_line("HELP VER DIR TYPE ABOUT CLS REBOOT");}
 else if(starts(c,"ABOUT") && c[5]==0){term_line("NAGISINNRA OS - FAT12 DESKTOP");term_line("WINDOWS / EDITOR / PAINT / TASKS");}
 else if(starts(c,"CLS") && c[3]==0){term_lines=0;for(int i=0;i<9;i++)term_out[i][0]=0;}
 else if(starts(c,"DIR") && c[3]==0){term_line("FAT12:");for(int i=0;i<32&&term_lines<9;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;char n[16];name83(n,e);term_line(n);}}
 else if(starts(c,"TYPE ")){int ent=find_entry(c+5);if(ent<0)term_line("FILE NOT FOUND");else{char b[56];read_file(ent,b,sizeof(b));if(!b[0])term_line("(EMPTY)");else{char line[55];int j=0;for(int i=0;b[i]&&j<54;i++){if(b[i]=='\r')continue;if(b[i]=='\n'){line[j]=0;term_line(line);j=0;}else line[j++]=b[i];}if(j){line[j]=0;term_line(line);}}}}
 else term_line("BAD COMMAND - TYPE HELP");
}
static void load_editor(int ent){if(ent>=0){editor_file=ent;editor_n=read_file(ent,editor,sizeof(editor));win[APP_EDIT].open=1;active=APP_EDIT;}}
static void click_window(int id){Window*w=&win[id];if(inside(w->x+w->w-28,w->y,28,22,mx,my)){w->open=0;active=-1;drag_win=-1;return;}if(inside(w->x,w->y,w->w,22,mx,my)){active=id;drag_win=id;w->ox=mx-w->x;w->oy=my-w->y;return;}active=id;if(id!=APP_BROWSER)browser_focus=0;
 if(id==APP_FILES){int row=(my-(w->y+76))/17;if(row>=0&&row<12){int seen=0;for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;if(seen++==row){load_editor(i);win[APP_EDIT].open=1;active=APP_EDIT;return;}}}}
 if(id==APP_EDIT){if(inside(w->x+18,w->y+w->h-42,76,28,mx,my)){/* RAM FAT12 write-back can be added without changing UI ABI. */}else if(inside(w->x+104,w->y+w->h-42,76,28,mx,my)){load_editor(find_entry("README.TXT"));}}
 if(id==APP_PAINT&&inside(w->x+18,w->y+72,w->w-36,w->h-125,mx,my)){putp(mx,my,rgb(80,220,255));} if(id==APP_BROWSER){
  if(inside(w->x+16,w->y+32,w->w-100,24,mx,my)){active=APP_BROWSER;browser_focus=1;}
  else if(inside(w->x+w->w-62,w->y+32,38,24,mx,my)){browser_focus=1;browser_url[browser_url_n]=0;browser_open(browser_url);}
}
 if(id==APP_TASKS){int row=0;for(int i=0;i<6;i++)if(win[i].open){if(inside(w->x+10,w->y+62+row*25,w->w-20,24,mx,my)){active=i;return;}row++;}}
}
static int top_at(int x,int y){for(int i=5;i>=0;i--)if(win[i].open&&inside(win[i].x,win[i].y,win[i].w,win[i].h,x,y))return i;return -1;}
static void task_click(void){
 if(my<578)return;
 int id=-1;
 if(mx>=42&&mx<104)id=0;
 else if(mx>=108&&mx<164)id=1;
 else if(mx>=168&&mx<224)id=2;
 else if(mx>=228&&mx<284)id=3;
 else if(mx>=288&&mx<344)id=4;
 else if(mx>=348&&mx<404)id=5;
 if(id>=0){
  win[id].open=1;active=id;
  if(id==5){browser_focus=1;if(browser_n==0)browser_home();}
  drag_win=-1;
 }
}
static void mouse_actions(void){if(!mpress)return;mpress=0;if(my>=578){task_click();redraw();return;}int id=top_at(mx,my);if(id>=0){click_window(id);redraw();}}
static void type_key(uint8_t s){
 char c=keychar(s);
 /* Browser owns keyboard focus while its address bar is focused. */
 if(browser_focus&&win[APP_BROWSER].open){
  if(c=='\b'){if(browser_url_n>0)browser_url[--browser_url_n]=0;return;}
  if(c=='\n'){browser_url[browser_url_n]=0;browser_open(browser_url);return;}
  if(c=='\t')return;
  if(c>=32&&c<=126&&browser_url_n<62){browser_url[browser_url_n++]=c;browser_url[browser_url_n]=0;}
  return;
 }
 if(active==APP_BROWSER&&win[APP_BROWSER].open){
  if(c=='\b'){if(browser_url_n>0)browser_url[--browser_url_n]=0;return;}
  if(c=='\n'){browser_url[browser_url_n]=0;browser_open(browser_url);return;}
  if(c>=32&&c<=126&&browser_url_n<62){browser_url[browser_url_n++]=c;browser_url[browser_url_n]=0;}
  return;
 }
 if(c=='\b'){if(term_n>0)term_in[--term_n]=0;return;}
 if(c=='\n'){term_in[term_n]=0;term_command(term_in);term_n=0;term_in[0]=0;return;}
 if(c=='\t')return;
 if(c>=32&&c<=126&&term_n<44){if(c>='a'&&c<='z')c=(char)(c-'a'+'A');term_in[term_n++]=c;term_in[term_n]=0;}
}
void kernel_main(void){
 uint8_t*mi=(uint8_t*)VBE_INFO;
 fb_phys=mi[0x28]|((uint32_t)mi[0x29]<<8)|((uint32_t)mi[0x2a]<<16)|((uint32_t)mi[0x2b]<<24);
 pitch=mi[0x10]|((uint32_t)mi[0x11]<<8);
 if(!fb_phys||!pitch){fb_phys=0xE0000000u;pitch=W*2;}
 /* Clear the back buffer once before the first frame. */
 for(uint32_t i=0;i<(uint32_t)W*H;i++)backbuf[i]=0;
 net_init();
 mouse_init();
 init_windows();
 term_n=0;term_in[0]=0;term_lines=0;
 for(int i=0;i<9;i++)term_out[i][0]=0;
 term_line("TYPE HELP FOR COMMANDS");
 term_line("NET: NE2000 / HTTP READY");
 editor_n=0;editor[0]=0;browser_url[0]=0;browser_url_n=0;browser_n=0;browser_focus=0;
 redraw();
 for(;;){
  int changed=mouse_poll();
  if(drag_win>=0){
   Window*w=&win[drag_win];
   if(mbuttons&1){
    int nx=mx-w->ox,ny=my-w->oy;
    if(nx<0)nx=0;if(ny<46)ny=46;if(nx+w->w>W)nx=W-w->w;if(ny+w->h>568)ny=568-w->h;
    w->x=nx;w->y=ny;changed=1;
   }else drag_win=-1;
  }
  uint8_t s;int key_guard=0;
  while(key_guard++<16 && keyboard_get(&s)){
   changed=1;
   if(s==0x3b){win[0].open=1;active=0;browser_focus=0;}
   else if(s==0x3c){win[1].open=1;active=1;browser_focus=0;}
   else if(s==0x3d){win[2].open=1;active=2;browser_focus=0;}
   else if(s==0x3e){win[3].open=1;active=3;browser_focus=0;}
   else if(s==0x3f){win[4].open=1;active=4;browser_focus=0;}
   else if(s==0x40){win[5].open=1;active=5;browser_focus=1;if(browser_n==0)browser_home();}
   else if(s==0x01){for(int i=0;i<6;i++)win[i].open=0;active=-1;browser_focus=0;}
   else type_key(s);
  }
  if(mpress)mouse_actions();
  if(changed)redraw();
 }
}
