import sys,struct
boot=open(sys.argv[1],'rb').read(); kernel=open(sys.argv[2],'rb').read(); out=sys.argv[3]
assert len(boot)==512 and boot[510:512]==b'\x55\xaa'
assert len(kernel)<=64*512
img=bytearray(1474560)
img[:512]=boot
img[2*512:2*512+len(kernel)]=kernel
SECT=512; NSEC=96; base=66*SECT
fs=bytearray(NSEC*SECT)
fs[0:3]=b'\xeb\x3c\x90';fs[3:11]=b'NAGISINN';struct.pack_into('<H',fs,11,512);fs[13]=1;struct.pack_into('<H',fs,14,1);fs[16]=2;struct.pack_into('<H',fs,17,32);struct.pack_into('<H',fs,19,NSEC);fs[21]=0xF0;fs[22]=1;struct.pack_into('<H',fs,24,18);struct.pack_into('<H',fs,26,2);fs[38]=0x29;fs[43:54]=b'NAGISINNRA '
fs[54:62]=b'FAT12   '
fat=bytearray(SECT);fat[0:3]=b'\xf0\xff\xff'
def fatset(cl,val):
 o=(cl*3)//2
 if cl&1:fat[o]=(fat[o]&15)|(((val&255)<<4)&255);fat[o+1]=(val>>4)&255
 else:fat[o]=val&255;fat[o+1]=(fat[o+1]&240)|((val>>8)&15)
for cl in range(2,8):fatset(cl,0xfff)
fs[SECT:2*SECT]=fat;fs[2*SECT:3*SECT]=fat
files=[('README  ','TXT',b'Nagisinnra OS V24\r\n800x600 VBE GUI\r\nMilky Way desktop\r\n'),('CONFIG  ','SYS',b'NAME=NAGISINNRA OS\r\nMODE=VBE 800x600x16\r\n'),('HELLO   ','TXT',b'Hello from Nagisinnra OS V24!\r\n'),('ABOUT   ','TXT',b'32-bit i386 / FAT12 / Window System\r\n'),('PAINT   ','DAT',b'NAGISINNRA PAINT DATA\r\n'),('INDEX   ','HTM',b'Nagisinnra OS Browser\r\nWelcome to the local web viewer.\r\n'),('TETRIS  ','TXT',b'Nagisinnra Tetris\r\nArrow keys move, Up rotates, Down drops, Space starts.\r\n')]
for idx,(nm,ex,data) in enumerate(files):
 e=bytearray(32);e[0:8]=nm.encode();e[8:11]=ex.encode();e[11]=0x20;cl=2+idx;struct.pack_into('<H',e,26,cl);struct.pack_into('<I',e,28,len(data));fs[3*SECT+idx*32:3*SECT+(idx+1)*32]=e;fs[(5+idx)*SECT:(5+idx)*SECT+len(data)]=data
img[base:base+len(fs)]=fs
assert img[510:512]==b'\x55\xaa'
assert img[2*SECT:2*SECT+len(kernel)]==kernel
open(out,'wb').write(img)
