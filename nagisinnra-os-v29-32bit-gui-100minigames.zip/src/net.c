#include <stdint.h>

/* Minimal NE2000 + ARP/IPv4/UDP/DNS/TCP client for v86's NE2000. */
#define NE_BASE 0x300
#define NE_CR 0x00
#define NE_PSTART 0x01
#define NE_PSTOP 0x02
#define NE_BNRY 0x03
#define NE_TPSR 0x04
#define NE_TBCR0 0x05
#define NE_TBCR1 0x06
#define NE_ISR 0x07
#define NE_RSAR0 0x08
#define NE_RSAR1 0x09
#define NE_RBCR0 0x0A
#define NE_RBCR1 0x0B
#define NE_RCR 0x0C
#define NE_TCR 0x0D
#define NE_DCR 0x0E
#define NE_IMR 0x0F
#define NE_DATA 0x10
#define NE_RESET 0x1F
#define NE_CURR 0x07
#define NE_PAR0 0x01
#define NE_MAR0 0x08

static uint8_t mac[6];
static uint8_t rxbuf[2048];
static uint8_t txbuf[1600];
static uint8_t udpbuf[1024];
static uint8_t tcpbuf[2048];
static uint8_t tcp_src_port=0xD0;
static uint32_t tcp_seq=0x12345678, tcp_ack=0;
static uint32_t my_ip=0xC0A85664u; /* 192.168.86.100 */
static uint32_t gw_ip=0xC0A85601u; /* 192.168.86.1 */
static uint32_t dns_ip=0xC0A85601u;

static inline uint8_t inb(uint16_t p){uint8_t v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outb(uint16_t p,uint8_t v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}
static void io_wait(void){for(volatile int i=0;i<40;i++)__asm__ volatile("nop");}
static uint16_t rd16(const uint8_t*p){return (uint16_t)p[0]|((uint16_t)p[1]<<8);}
static void wr16(uint8_t*p,uint16_t v){p[0]=(uint8_t)v;p[1]=(uint8_t)(v>>8);}
static uint32_t rd32be(const uint8_t*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static void wr32be(uint8_t*p,uint32_t v){p[0]=v>>24;p[1]=v>>16;p[2]=v>>8;p[3]=v;}
static uint16_t csum(const uint8_t*p,int n){uint32_t s=0;while(n>1){s+=((uint16_t)p[0]<<8)|p[1];p+=2;n-=2;if(s&0x10000)s=(s&0xffff)+1;}if(n)s+=(uint16_t)p[0]<<8;while(s>>16)s=(s&0xffff)+(s>>16);return (uint16_t)~s;}
static uint16_t pseudo_sum(uint32_t a,uint32_t b,uint8_t proto,uint16_t len,const uint8_t*p){uint32_t s=0;s+=(a>>16)+(a&0xffff)+(b>>16)+(b&0xffff)+proto+len;while(len>1){s+=((uint16_t)p[0]<<8)|p[1];p+=2;len-=2;}if(len)s+=(uint16_t)p[0]<<8;while(s>>16)s=(s&0xffff)+(s>>16);return (uint16_t)~s;}

static void ne_remote_write(const uint8_t*p,int n,uint16_t addr){outb(NE_BASE+NE_CR,0x12);outb(NE_BASE+NE_RSAR0,addr);outb(NE_BASE+NE_RSAR1,addr>>8);outb(NE_BASE+NE_RBCR0,n);outb(NE_BASE+NE_RBCR1,n>>8);for(int i=0;i<n;i++)outb(NE_BASE+NE_DATA,p[i]);outb(NE_BASE+NE_CR,0x22);}
static void ne_remote_read(uint8_t*p,int n,uint16_t addr){outb(NE_BASE+NE_CR,0x0a);outb(NE_BASE+NE_RSAR0,addr);outb(NE_BASE+NE_RSAR1,addr>>8);outb(NE_BASE+NE_RBCR0,n);outb(NE_BASE+NE_RBCR1,n>>8);for(int i=0;i<n;i++)p[i]=inb(NE_BASE+NE_DATA);outb(NE_BASE+NE_CR,0x22);}
static void ne_tx(const uint8_t*p,int n){if(n<60)n=60;for(int i=0;i<n;i++)txbuf[i]=i<(int)n?p[i]:0;ne_remote_write(txbuf,n,0x4000);outb(NE_BASE+NE_TPSR,0x40);outb(NE_BASE+NE_TBCR0,n);outb(NE_BASE+NE_TBCR1,n>>8);outb(NE_BASE+NE_CR,0x26);for(volatile int i=0;i<200000;i++){if(inb(NE_BASE+NE_ISR)&0x02){outb(NE_BASE+NE_ISR,0x02);break;}}}
static int ne_rx(uint8_t*out,int cap){uint8_t isr=inb(NE_BASE+NE_ISR);if(!(isr&0x01))return 0;outb(NE_BASE+NE_ISR,0x01);outb(NE_BASE+NE_CR,0x61);uint8_t curr=inb(NE_BASE+NE_CURR);outb(NE_BASE+NE_CR,0x22);uint8_t bn=inb(NE_BASE+NE_BNRY);uint8_t page=(uint8_t)(bn+1);if(page==0x80)page=0x4c;if(page==curr)return 0;uint8_t hdr[4];ne_remote_read(hdr,4,(uint16_t)page<<8);int len=hdr[2]|((int)hdr[3]<<8);if(len<4||len>cap){outb(NE_BASE+NE_BNRY,(uint8_t)(hdr[1]-1));if(hdr[1]<=0x4c)outb(NE_BASE+NE_BNRY,0x7f);return 0;}ne_remote_read(out,len,(uint16_t)page<<8|4);uint8_t next=hdr[1];outb(NE_BASE+NE_BNRY,(uint8_t)(next-1));if(next<=0x4c)outb(NE_BASE+NE_BNRY,0x7f);return len;}
static int mac_eq(const uint8_t*a,const uint8_t*b){for(int i=0;i<6;i++)if(a[i]!=b[i])return 0;return 1;}
static void eth_hdr(uint8_t*p,const uint8_t*d,uint16_t type){for(int i=0;i<6;i++){p[i]=d[i];p[6+i]=mac[i];}p[12]=type>>8;p[13]=type;}

static void arp_request(uint32_t target){uint8_t p[42]={0};for(int i=0;i<6;i++){p[i]=0xff;p[6+i]=mac[i];}p[12]=0x08;p[13]=0x06;p[14]=0;p[15]=1;p[16]=8;p[17]=0;p[18]=6;p[19]=4;p[20]=0;p[21]=1;for(int i=0;i<6;i++)p[22+i]=mac[i];wr32be(p+28,my_ip);for(int i=0;i<6;i++)p[32+i]=0;wr32be(p+38,target);ne_tx(p,42);}
static int arp_resolve(uint32_t ip,uint8_t*out){arp_request(ip);for(int t=0;t<100000;t++){int n=ne_rx(rxbuf,sizeof(rxbuf));if(n>=42&&rd16(rxbuf+12)==0x0806&&rd16(rxbuf+20)==2&&rd32be(rxbuf+28)==ip){for(int i=0;i<6;i++)out[i]=rxbuf[22+i];return 1;}}return 0;}

static int udp_send(const uint8_t*dmac,uint32_t dst,uint16_t sport,uint16_t dport,const uint8_t*data,int len){int n=42+8+len;if(n>sizeof(txbuf))return 0;eth_hdr(txbuf,dmac,0x0800);uint8_t*ip=txbuf+14;ip[0]=0x45;ip[1]=0;wr16(ip+2,20+8+len);wr16(ip+4,0x1111);wr16(ip+6,0);ip[8]=64;ip[9]=17;wr16(ip+10,0);wr32be(ip+12,my_ip);wr32be(ip+16,dst);wr16(ip+10,csum(ip,20));uint8_t*u=ip+20;wr16(u,sport);wr16(u+2,dport);wr16(u+4,8+len);wr16(u+6,0);for(int i=0;i<len;i++)u[8+i]=data[i];wr16(u+6,pseudo_sum(my_ip,dst,17,8+len,u));ne_tx(txbuf,n);return 1;}
static int udp_wait(uint16_t sport,uint16_t dport,uint8_t*out,int cap,uint32_t*srcip){for(int t=0;t<250000;t++){int n=ne_rx(rxbuf,sizeof(rxbuf));if(n<42)continue;if(rd16(rxbuf+12)!=0x0800)continue;uint8_t*ip=rxbuf+14;if((ip[0]>>4)!=4||ip[9]!=17)continue;int ihl=(ip[0]&15)*4;uint8_t*u=ip+ihl;if(rd16(u)!=dport||rd16(u+2)!=sport)continue;int l=rd16(u+4)-8;if(l<0)continue;if(l>cap)l=cap;for(int i=0;i<l;i++)out[i]=u[8+i];if(srcip)*srcip=rd32be(ip+12);return l;}return -1;}

static int dns_lookup(const char*host,uint32_t*outip){uint8_t q[128]={0};wr16(q,0x4321);wr16(q+2,0x0100);wr16(q+4,1);int pos=12,start=0;for(int i=0;;i++){if(host[i]=='.'||host[i]==0){int l=i-start;if(l<1||l>63)return 0;q[pos++]=(uint8_t)l;for(int j=start;j<i;j++)q[pos++]=(uint8_t)host[j];start=i+1;if(!host[i])break;}}q[pos++]=0;wr16(q+pos,1);pos+=2;wr16(q+pos,1);pos+=2;uint8_t dm[6];if(!arp_resolve(dns_ip,dm))return 0;if(!udp_send(dm,dns_ip,49153,53,q,pos))return 0;int n=udp_wait(53,49153,udpbuf,sizeof(udpbuf),0);if(n<12||((rd16(udpbuf+2)&0x000f)==0))return 0;int p=12;while(p<n&&udpbuf[p])p+=udpbuf[p]+1;p++;p+=4;for(int ans=0;ans<8&&p+12<=n;ans++){if((udpbuf[p]&0xc0)==0xc0)p+=2;else{while(p<n&&udpbuf[p])p+=udpbuf[p]+1;p++;}if(p+10>n)return 0;uint16_t type=rd16(udpbuf+p);uint16_t cls=rd16(udpbuf+p+2);uint16_t rdlen=rd16(udpbuf+p+8);p+=10;if(type==1&&cls==1&&rdlen==4&&p+4<=n){*outip=((uint32_t)udpbuf[p]<<24)|((uint32_t)udpbuf[p+1]<<16)|((uint32_t)udpbuf[p+2]<<8)|udpbuf[p+3];return 1;}p+=rdlen;}return 0;}

static int tcp_send_segment(const uint8_t*dmac,uint32_t dst,uint16_t sport,uint16_t dport,uint32_t seq,uint32_t ack,uint8_t flags,const uint8_t*data,int len){int n=14+20+20+len;if(n>sizeof(txbuf))return 0;eth_hdr(txbuf,dmac,0x0800);uint8_t*ip=txbuf+14;ip[0]=0x45;wr16(ip+2,20+20+len);wr16(ip+4,0x2222);wr16(ip+6,0);ip[8]=64;ip[9]=6;wr32be(ip+12,my_ip);wr32be(ip+16,dst);wr16(ip+10,csum(ip,20));uint8_t*t=ip+20;wr16(t,sport);wr16(t+2,dport);wr32be(t+4,seq);wr32be(t+8,ack);t[12]=0x50;t[13]=flags;wr16(t+14,8192);wr16(t+16,0);wr16(t+18,0);for(int i=0;i<len;i++)t[20+i]=data[i];wr16(t+16,pseudo_sum(my_ip,dst,6,20+len,t));ne_tx(txbuf,n);return 1;}
static int tcp_wait(uint32_t dst,uint16_t sport,uint16_t dport,uint32_t*seq,uint32_t*ack,uint8_t*flags,uint8_t*out,int cap){for(int t=0;t<400000;t++){int n=ne_rx(rxbuf,sizeof(rxbuf));if(n<54)continue;if(rd16(rxbuf+12)!=0x0800)continue;uint8_t*ip=rxbuf+14;if(ip[9]!=6||rd32be(ip+12)!=dst||rd32be(ip+16)!=my_ip)continue;int ihl=(ip[0]&15)*4;uint8_t*tcp=ip+ihl;if(rd16(tcp+2)!=dport||rd16(tcp)!=sport)continue;uint8_t f=tcp[13];uint32_t s=rd32be(tcp+4),a=rd32be(tcp+8);int h=(tcp[12]>>4)*4;int l=rd16(ip+2)-ihl-h;if(l<0)l=0;if(l>cap)l=cap;for(int i=0;i<l;i++)out[i]=tcp[h+i];if(seq)*seq=s;if(ack)*ack=a;if(flags)*flags=f;return l;}return -1;}

int net_init(void){outb(NE_BASE+NE_CR,0x21);io_wait();(void)inb(NE_BASE+NE_RESET);for(volatile int i=0;i<10000;i++)__asm__ volatile("nop");outb(NE_BASE+NE_CR,0x61);for(int i=0;i<6;i++)mac[i]=inb(NE_BASE+NE_PAR0+i);outb(NE_BASE+NE_CR,0x21);outb(NE_BASE+NE_DCR,0x49);outb(NE_BASE+NE_RBCR0,0);outb(NE_BASE+NE_RBCR1,0);outb(NE_BASE+NE_RCR,0x05); /* accept broadcast + packets addressed to our MAC */outb(NE_BASE+NE_TCR,0);outb(NE_BASE+NE_PSTART,0x4c);outb(NE_BASE+NE_PSTOP,0x80);outb(NE_BASE+NE_BNRY,0x7f);outb(NE_BASE+NE_TPSR,0x40);outb(NE_BASE+NE_ISR,0xff);outb(NE_BASE+NE_IMR,0);outb(NE_BASE+NE_CR,0x61);for(int i=0;i<6;i++)outb(NE_BASE+NE_PAR0+i,mac[i]);for(int i=0;i<8;i++)outb(NE_BASE+NE_MAR0+i,0);outb(NE_BASE+NE_CURR,0x4c);outb(NE_BASE+NE_CR,0x22);return mac[0]!=0||mac[1]!=0||mac[2]!=0;}

int net_http_get(const char*host,const char*path,char*out,int cap){uint32_t ip;if(!dns_lookup(host,&ip))return -1;uint8_t dm[6];if(!arp_resolve(gw_ip,dm))return -2;uint16_t sport=(uint16_t)(49152+(tcp_src_port++&31));uint32_t iss=tcp_seq;tcp_send_segment(dm,ip,sport,80,iss,0,0x02,0,0);uint32_t rs,ra;uint8_t fl;int l=tcp_wait(ip,sport,80,&rs,&ra,&fl,tcpbuf,sizeof(tcpbuf));if(l<0||!(fl&0x12))return -3;tcp_ack=rs+1;tcp_send_segment(dm,ip,sport,80,iss+1,tcp_ack,0x10,0,0);char req[512];int rn=0;const char*prefix="GET ";for(int i=0;prefix[i];i++)req[rn++]=prefix[i];for(int i=0;path[i]&&rn<500;i++)req[rn++]=path[i];const char*tail=" HTTP/1.0\r\nHost: ";for(int i=0;tail[i]&&rn<500;i++)req[rn++]=tail[i];for(int i=0;host[i]&&rn<500;i++)req[rn++]=host[i];const char*end="\r\nConnection: close\r\n\r\n";for(int i=0;end[i]&&rn<510;i++)req[rn++]=end[i];tcp_send_segment(dm,ip,sport,80,iss+1,tcp_ack,0x18,(const uint8_t*)req,rn);int total=0;uint32_t cli_seq=iss+1,peer_ack=tcp_ack;for(int loops=0;loops<40&&total<cap-1;loops++){l=tcp_wait(ip,sport,80,&rs,&ra,&fl,tcpbuf,sizeof(tcpbuf));if(l<0)break;if(l){int take=l;if(take>cap-1-total)take=cap-1-total;for(int i=0;i<take;i++)out[total+i]=(char)tcpbuf[i];total+=take;peer_ack=rs+(uint32_t)l;tcp_send_segment(dm,ip,sport,80,cli_seq,peer_ack,0x10,0,0);}else if(fl&0x01){peer_ack=rs+1;tcp_send_segment(dm,ip,sport,80,cli_seq,peer_ack,0x10,0,0);break;}if(fl&0x01)break;}out[total]=0;tcp_send_segment(dm,ip,sport,80,cli_seq,peer_ack,0x11,0,0);return total;}

const uint8_t*net_mac(void){return mac;}
