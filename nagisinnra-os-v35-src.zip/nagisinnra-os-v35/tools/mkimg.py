#!/usr/bin/env python3
"""Assemble the Nagisinnra OS floppy image: boot sector + kernel + FAT12 RAM-disk prefix."""
import sys, struct, subprocess, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mkfat import mkfs, Fat12

README = """NAGISINNRA OS V35
=================
A small 32-bit desktop OS: 800x600 GUI, FAT12 RAM disk, NE2000 network
with DHCP / DNS / TCP / HTTP, a text-mode web browser and 1000 games.

Quick start
  F1 Terminal   F2 Files   F3 Editor   F4 Paint   F5 System   F6 Browser
  F10 Games     Ctrl+W close window    mouse: drag title bars, resize corner

Network
  The OS asks for an address with DHCP at boot.  Open the Browser (F6) and
  type an http:// address, or use the terminal:
      ping example.com      wget http://example.com/     curl http://neverssl.com/
  https:// is not supported (no TLS).

The disk is a RAM disk: files you create are lost on reboot.
See DOCS\\NETWORK.TXT and DOCS\\SHORTCUT.TXT.
"""
CONFIG = "NAME=NAGISINNRA OS\nVERSION=35\nMODE=VBE 800x600x16\nGAMES=1000\n"
NETWORK = """Networking
==========
Supported adapter: NE2000 (ISA at 0x300, or PCI RTL8029 / compatible).
Works in v86, QEMU (-device ne2k_pci  or  -device ne2k_isa,iobase=0x300,irq=9) and on real cards.

Boot sequence : DHCP DISCOVER/REQUEST -> address, mask, gateway, DNS.
If no DHCP server answers within ~8 s the OS falls back to
192.168.86.100 / 24, gateway and DNS 192.168.86.1 (the v86 default).

Terminal commands
  ifconfig                 show address, MAC, counters
  ifconfig IP MASK GW DNS  set a static address
  dhcp                     ask the DHCP server again
  ping HOST [N]            ICMP echo
  nslookup HOST            DNS lookup (A records, CNAME followed)
  wget URL [FILE]          download to the current directory
  curl URL                 print a page in the terminal
  browse URL               open the browser

HTTP client: HTTP/1.1, Content-Length, chunked and read-until-close bodies,
redirects (301/302/303/307/308), up to 256 KB per page.  No TLS (https://).
"""
SHORTCUTS = """Keyboard
========
F1 Terminal  F2 Files  F3 Editor  F4 Paint  F5 System  F6 Browser
F7 Tetris  F8 Snake  F9 Mines  F10 Games centre  F12 Arcade game
Ctrl+W close the active window

Terminal : Tab complete, Up/Down history, PgUp/PgDn scroll, Ctrl+C cancel, Ctrl+L clear
Editor   : Ctrl+S save, Ctrl+O open, Ctrl+N new, arrows/Home/End/PgUp/PgDn
Browser  : Ctrl+L address bar, Ctrl+R reload, Alt+Left/Right back/forward,
           Ctrl+U view source, PgUp/PgDn/Home/End/Space scroll, Esc stop
Files    : Enter open, Backspace up, Del delete, F2 rename, double-click open
"""
WELCOME = """<html><head><title>Welcome to Nagisinnra OS</title></head><body>
<h1>Nagisinnra OS ブラウザ テスト</h1>
<p>This is a <b>local</b> HTML page served from the RAM disk.
日本語もそのまま表示できます。ひらがな・カタカナ・漢字を含む文章の折り返しも確認してください。</p>
<h2>Lists &amp; links</h2>
<ul><li><a href="../README.TXT">README.TXT</a> (relative link)</li>
<li><a href="http://example.com/">example.com</a> over HTTP</li>
<li>Entities: &lt;tag&gt; &copy; &mdash; &rarr; &hearts;</li></ul>
<ol><li>First</li><li>Second<ul><li>nested bullet</li></ul></li><li>Third</li></ol>
<h2>Table</h2>
<table><tr><th>Key</th><th>Action</th></tr><tr><td>F6</td><td>Browser</td></tr><tr><td>Ctrl+L</td><td>Address bar</td></tr></table>
<h2>Preformatted</h2>
<pre>int main(void) {
    return 0;   /* monospace */
}</pre>
<hr><p><a href="nagisinnra://home">Home page</a></p>
</body></html>
"""
def build_fs():
    img = mkfs(4000)
    fs = Fat12(img)
    fs.add_file(0, 'README.TXT', README.encode('utf8'))
    fs.add_file(0, 'CONFIG.SYS', CONFIG.encode())
    fs.add_file(0, 'HELLO.TXT', 'Hello from Nagisinnra OS!\nこんにちは、世界。\n'.encode('utf8'))
    docs = fs.add_dir(0, 'DOCS')
    fs.add_file(docs, 'NETWORK.TXT', NETWORK.encode())
    fs.add_file(docs, 'SHORTCUT.TXT', SHORTCUTS.encode())
    fs.add_file(docs, 'WELCOME.HTM', WELCOME.encode('utf8'))
    fs.add_file(docs, 'ABOUT.TXT', b'Nagisinnra OS - 32-bit i386, FAT12 RAM disk, TCP/IP stack.\n')
    games = fs.add_dir(0, 'GAMES')
    fs.add_file(games, 'GAMES.TXT', b'Games Center: Tetris, Snake, Mines, Breakout and 996 arcade variants.\nOpen with F10.\n')
    sysd = fs.add_dir(0, 'SYSTEM')
    fs.add_file(sysd, 'CONFIG.SYS', b'FS=FAT12\nNET=NE2000\n')
    return img

def main():
    boot, kern, out = sys.argv[1:4]
    elf = sys.argv[4] if len(sys.argv) > 4 else None
    b = bytearray(open(boot, 'rb').read()); assert len(b) == 512 and b[510:512] == b'\x55\xAA'
    k = bytearray(open(kern, 'rb').read())
    while len(k) % 512: k.append(0)
    vol = build_fs()
    nz = [i for i in range(len(vol)//512) if any(vol[i*512:(i+1)*512])]
    prefix = nz[-1] + 1
    fsdata = bytes(vol[:prefix*512])
    ksec = len(k)//512
    total = ksec + prefix
    limit = (0x90000 - 0x10000)//512
    assert total <= limit, "image too large: %d sectors (limit %d)" % (total, limit)
    if elf:
        nm = subprocess.check_output(['nm', elf]).decode()
        bss_end = [int(l.split()[0], 16) for l in nm.splitlines() if l.endswith(' __bss_end')][0]
        img_end = [int(l.split()[0], 16) for l in nm.splitlines() if l.endswith(' __image_end')][0]
        assert img_end == 0x10000 + len(k), "image_end mismatch %x vs %x" % (img_end, 0x10000 + len(k))
        assert bss_end < 0x8E000, "BSS runs into VBE/stack area: %x" % bss_end
        print("kernel %d bytes (%d sectors), bss end 0x%x, fs prefix %d sectors" % (len(k), ksec, bss_end, prefix))
    struct.pack_into('<HH', b, 0x1F0, total, prefix)
    img = bytes(b) + bytes(k) + fsdata
    img += b'\0' * (2880*512 - len(img))
    open(out, 'wb').write(img)
    print("wrote %s: %d bytes, %d/%d loadable sectors used" % (out, len(img), total, limit))
main()
