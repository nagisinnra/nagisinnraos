"""Minimal FAT12 volume builder (shared by mkimg and tests): 1 sector/cluster, 224 root entries."""
import struct
def mkfs(total_sectors=4000, label=b'NAGISINNRA ', spc=1):
    fatsz=12; res=1; nfats=2; rootent=224
    img=bytearray(total_sectors*512)
    bs=bytearray(512)
    bs[0:3]=b'\xEB\x3C\x90'; bs[3:11]=b'NAGIFS35'
    struct.pack_into('<HBHBHHBHHHII',bs,11,512,spc,res,nfats,rootent,total_sectors,0xF8,fatsz,18,2,0,0)
    bs[36]=0x80; bs[38]=0x29; struct.pack_into('<I',bs,39,0x35353535); bs[43:54]=label; bs[54:62]=b'FAT12   '
    bs[510]=0x55; bs[511]=0xAA
    img[0:512]=bs
    for i in range(nfats):
        o=(res+i*fatsz)*512; img[o]=0xF8; img[o+1]=0xFF; img[o+2]=0xFF
    return img
class Fat12:
    """Independent FAT12 reader/writer used to build and verify images."""
    def __init__(s,img):
        s.img=img
        s.bps,s.spc,s.res,s.nf,s.rootent,s.tot=struct.unpack_from('<HBHBHH',img,11)
        s.fatsz=struct.unpack_from('<H',img,22)[0]
        s.fat_off=s.res*512; s.root_lba=s.res+s.nf*s.fatsz; s.root_secs=(s.rootent*32+511)//512
        s.data_lba=s.root_lba+s.root_secs; s.ncl=(s.tot-s.data_lba)//s.spc
    def fget(s,c):
        o=s.fat_off+c+c//2; v=s.img[o]|(s.img[o+1]<<8)
        return v>>4 if c&1 else v&0xfff
    def fset(s,c,val):
        for k in range(s.nf):
            o=s.fat_off+k*s.fatsz*512+c+c//2
            if c&1: s.img[o]=(s.img[o]&0x0f)|((val&0xf)<<4); s.img[o+1]=val>>4
            else: s.img[o]=val&0xff; s.img[o+1]=(s.img[o+1]&0xf0)|((val>>8)&0xf)
    def cl_off(s,c): return (s.data_lba+(c-2)*s.spc)*512
    def chain(s,c):
        out=[]
        while 2<=c<0xff8:
            out.append(c); c=s.fget(c)
            assert len(out)<5000
        return out
    def dir_entries(s,cluster):
        raw=bytearray()
        if cluster==0: raw=bytes(s.img[s.root_lba*512:(s.root_lba+s.root_secs)*512])
        else:
            for c in s.chain(cluster): raw+=s.img[s.cl_off(c):s.cl_off(c)+s.spc*512]
        res=[]
        for i in range(0,len(raw),32):
            e=raw[i:i+32]
            if e[0]==0: break
            if e[0]==0xE5 or (e[11]&0x0f)==0x0f or (e[11]&8): continue
            name=e[0:8].decode('latin1').rstrip(); ext=e[8:11].decode('latin1').rstrip()
            res.append(dict(name=name+('.'+ext if ext else ''),attr=e[11],cluster=struct.unpack_from('<H',e,26)[0],size=struct.unpack_from('<I',e,28)[0]))
        return res
    def read_file(s,ent):
        data=b''.join(bytes(s.img[s.cl_off(c):s.cl_off(c)+s.spc*512]) for c in s.chain(ent['cluster']))
        return data[:ent['size']]
    def walk(s,cluster=0,prefix=''):
        out={}
        for e in s.dir_entries(cluster):
            if e['name'] in ('.','..'): continue
            p=prefix+'\\'+e['name']
            if e['attr']&0x10: out[p+'\\']=None; out.update(s.walk(e['cluster'],p))
            else: out[p]=s.read_file(e)
        return out
    def free_clusters(s): return sum(1 for c in range(2,s.ncl+2) if s.fget(c)==0)
    # --- writer used by mkimg for the initial content ---
    def _alloc(s):
        for c in range(2,s.ncl+2):
            if s.fget(c)==0: s.fset(c,0xfff); return c
        raise RuntimeError('image full')
    def _add_entry(s,dircl,raw32):
        if dircl==0:
            base=s.root_lba*512
            for i in range(s.rootent):
                o=base+i*32
                if s.img[o] in (0,0xE5): s.img[o:o+32]=raw32; return
            raise RuntimeError('root full')
        cl=s.chain(dircl)
        for c in cl:
            for i in range(s.spc*512//32):
                o=s.cl_off(c)+i*32
                if s.img[o] in (0,0xE5): s.img[o:o+32]=raw32; return
        n=s._alloc(); s.fset(cl[-1],n); o=s.cl_off(n); s.img[o:o+32]=raw32
    @staticmethod
    def name83(n):
        n=n.upper(); b,_,e=n.partition('.'); return (b[:8].ljust(8)+e[:3].ljust(3)).encode('latin1')
    DATE=(2026-1980)<<9|11<<5|18
    def add_file(s,dircl,name,data):
        first=0; prev=0
        for i in range(0,max(len(data),0),s.spc*512):
            c=s._alloc()
            if not first: first=c
            else: s.fset(prev,c)
            prev=c; chunk=data[i:i+s.spc*512]; o=s.cl_off(c); s.img[o:o+len(chunk)]=chunk
        e=bytearray(32); e[0:11]=s.name83(name); e[11]=0x20
        struct.pack_into('<HHHHHHI',e,14,0,s.DATE,s.DATE,0,0,s.DATE,0) if False else None
        struct.pack_into('<H',e,24,s.DATE); struct.pack_into('<H',e,16,s.DATE); struct.pack_into('<H',e,18,s.DATE)
        struct.pack_into('<H',e,26,first); struct.pack_into('<I',e,28,len(data))
        s._add_entry(dircl,bytes(e))
    def add_dir(s,dircl,name):
        c=s._alloc(); o=s.cl_off(c)
        for k in range(s.spc*512): s.img[o+k]=0
        for i,(nm,par) in enumerate((('.',c),('..',dircl))):
            e=bytearray(32); e[0:11]=nm.ljust(11).encode(); e[11]=0x10
            struct.pack_into('<H',e,24,s.DATE); struct.pack_into('<H',e,26,par); s.img[o+i*32:o+i*32+32]=e
        e=bytearray(32); e[0:11]=s.name83(name); e[11]=0x10; struct.pack_into('<H',e,24,s.DATE); struct.pack_into('<H',e,26,c)
        s._add_entry(dircl,bytes(e)); return c
