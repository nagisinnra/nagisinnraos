import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
from emu import L
def measure(o,label,secs=3):
    L.emu_watch(symaddr('present')); i0=o.e.icount; t0=o.ms(); k=0
    while o.ms()-t0<secs*1000:
        o.e.mouse(1 if k&1 else -1,0,0,0); o.pump(2); k+=1
    h=L.emu_watch_hits(); instr=o.e.icount-i0
    print("%-28s %3d frames in %ds -> %.2fM instr/frame (%.1f fps @ 36 MIPS virtual)"%(label,h,secs,instr/max(h,1)/1e6,h/secs))
o=OS(None,boot_ms=3000)
measure(o,"terminal")
o.key(0x40); o.pump(300); measure(o,"browser home")
o.key(0x44); o.pump(300); measure(o,"games centre")
o.key(0x3f); o.pump(300); measure(o,"+ system window")
