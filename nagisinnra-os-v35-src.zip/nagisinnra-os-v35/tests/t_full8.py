import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
o=OS(None,boot_ms=3000); o.pump(300)
o.term('browse file:DOCS/WELCOME.HTM',wait=800)
o.click(60,213); o.pump(600); o.shot('l1_rel')
o.key(0x3c); o.pump(300)
o.click(240,184); o.click(240,184,settle=500)           # into DOCS
o.click(240,232); o.click(240,232,settle=800)           # double-click WELCOME.HTM (4th row)
o.shot('l2_files_open_html')
