"""v86-like virtual network peer: ARP (any IP), DHCP, DNS, ICMP echo, TCP/HTTP server.
Everything is raw packets; times are virtual milliseconds supplied by the harness."""
import struct, random

def csum(b, s=0):
    if len(b) & 1: b += b'\0'
    for i in range(0, len(b), 2): s += (b[i] << 8) | b[i+1]
    while s >> 16: s = (s & 0xffff) + (s >> 16)
    return (~s) & 0xffff

def ip2b(s): return bytes(int(x) for x in s.split('.'))
def b2ip(b): return '.'.join(str(x) for x in b)

class Conn:
    def __init__(s, cip, cport, sip, sport, cmac, irs, mss):
        s.cip,s.cport,s.sip,s.sport,s.cmac = cip,cport,sip,sport,cmac
        s.iss = random.randrange(1<<31); s.irs = irs; s.rcv_nxt = irs+1
        s.snd_una = s.iss+1; s.sent_off = 0; s.out = b''; s.fin_sent = False; s.fin_acked = False
        s.req = b''; s.mss = min(mss, 1460); s.win = 65535; s.state = 'SYN_RCVD'
        s.last_tx = 0; s.responded = False; s.client_fin = False; s.closed = False
        s.rto = 400; s.dupcount = 0

class Peer:
    def __init__(s, ip='192.168.86.1', mac=b'\x02\x00\x86\x00\x00\x01', offer='192.168.86.100',
                 dns=None, http=None, loss=0.0, reorder=0.0, dup=0.0, seed=1, no_dhcp=False, mtu_mss=1460):
        s.ip, s.mac, s.offer = ip, mac, offer
        s.dns = dns or {}
        s.http = http
        s.loss, s.reorder, s.dup = loss, reorder, dup
        s.rng = random.Random(seed); random.seed(seed)
        s.conns = {}
        s.no_dhcp = no_dhcp
        s.held = None
        s.log = []
        s.stats = dict(arp=0, dhcp=0, dns=0, icmp=0, syn=0, req=0, tx_data=0, retx=0, dropped=0, rst=0)
        s.mtu_mss = mtu_mss
        s.ipid = 1
    # ---------- helpers ----------
    def eth(s, dst, typ, payload): return dst + s.mac + struct.pack('>H', typ) + payload
    def ipv4(s, src, dst, proto, payload):
        hdr = struct.pack('>BBHHHBBH4s4s', 0x45, 0, 20+len(payload), s.ipid & 0xffff, 0x4000, 64, proto, 0, ip2b(src), ip2b(dst))
        s.ipid += 1
        c = csum(hdr)
        return hdr[:10] + struct.pack('>H', c) + hdr[12:] + payload
    def out(s, frames, data=False):
        res = []
        for f in frames:
            if data and s.loss and s.rng.random() < s.loss: s.stats['dropped'] += 1; continue
            if data and s.dup and s.rng.random() < s.dup: res.append(f)
            if data and s.reorder and s.rng.random() < s.reorder and s.held is None: s.held = f; continue
            res.append(f)
            if s.held is not None: res.append(s.held); s.held = None
        return res
    # ---------- receive ----------
    def handle(s, frame, now):
        if len(frame) < 14: return []
        dst, src, typ = frame[0:6], frame[6:12], struct.unpack('>H', frame[12:14])[0]
        p = frame[14:]
        if typ == 0x0806: return s.arp(src, p)
        if typ == 0x0800: return s.ip_in(src, p, now)
        return []
    def arp(s, src, p):
        if len(p) < 28: return []
        op = struct.unpack('>H', p[6:8])[0]
        sha, spa, tpa = p[8:14], p[14:18], p[24:28]
        if op != 1: return []
        s.stats['arp'] += 1
        rep = struct.pack('>HHBBH', 1, 0x0800, 6, 4, 2) + s.mac + tpa + sha + spa
        return [s.eth(sha, 0x0806, rep)]
    def ip_in(s, cmac, p, now):
        if len(p) < 20 or p[0] >> 4 != 4: return []
        ihl = (p[0] & 15) * 4; tl = struct.unpack('>H', p[2:4])[0]
        proto = p[9]; src = b2ip(p[12:16]); dst = b2ip(p[16:20]); body = p[ihl:tl]
        # verify header checksum (real stacks do)
        if csum(p[:ihl]) != 0: s.log.append('bad ip csum'); return []
        if proto == 1: return s.icmp(cmac, src, dst, body)
        if proto == 17: return s.udp(cmac, src, dst, body)
        if proto == 6: return s.tcp(cmac, src, dst, body, now)
        return []
    def icmp(s, cmac, src, dst, b):
        if len(b) >= 8 and b[0] == 8:
            s.stats['icmp'] += 1
            r = b'\x00\x00\x00\x00' + b[4:]
            r = r[:2] + struct.pack('>H', csum(r)) + r[4:]
            return [s.eth(cmac, 0x0800, s.ipv4(dst, src, 1, r))]
        return []
    def udp(s, cmac, src, dst, b):
        if len(b) < 8: return []
        sp, dp, ln = struct.unpack('>HHH', b[:6]); d = b[8:ln]
        if dp == 67 and not s.no_dhcp: return s.dhcp(cmac, d)
        if dp == 53: return s.dnsq(cmac, src, dst, sp, d)
        return []
    def udp_reply(s, cmac, src, dst, sp, dp, data, bcast=False):
        u = struct.pack('>HHHH', sp, dp, 8+len(data), 0) + data
        ps = ip2b(src) + ip2b(dst) + struct.pack('>BBH', 0, 17, len(u))
        c = csum(ps + u) or 0xffff
        u = u[:6] + struct.pack('>H', c) + u[8:]
        return s.eth(b'\xff'*6 if bcast else cmac, 0x0800, s.ipv4(src, dst, 17, u))
    def dhcp(s, cmac, d):
        if len(d) < 241 or d[0] != 1: return []
        xid = d[4:8]; chaddr = d[28:34]
        opts = {}; i = 240
        while i < len(d) and d[i] != 255:
            if d[i] == 0: i += 1; continue
            opts[d[i]] = d[i+2:i+2+d[i+1]]; i += 2 + d[i+1]
        mt = opts.get(53, b'\0')[0]
        if mt not in (1, 3): return []
        s.stats['dhcp'] += 1
        rt = 2 if mt == 1 else 5
        r = bytes([2,1,6,0]) + xid + b'\0\0\x80\0' + b'\0'*4 + ip2b(s.offer) + ip2b(s.ip) + b'\0'*4 + chaddr + b'\0'*10 + b'\0'*192 + b'\x63\x82\x53\x63'
        r += bytes([53,1,rt, 54,4]) + ip2b(s.ip) + bytes([1,4,255,255,255,0, 3,4]) + ip2b(s.ip) + bytes([6,4]) + ip2b(s.ip) + bytes([51,4,0,1,0x51,0x80, 255])
        return [s.udp_reply(chaddr, s.ip, '255.255.255.255', 67, 68, r, bcast=True)]
    def dnsq(s, cmac, src, dst, sp, d):
        if len(d) < 12: return []
        s.stats['dns'] += 1
        qid = d[:2]; pos = 12; labels = []
        while d[pos]:
            l = d[pos]; labels.append(d[pos+1:pos+1+l].decode()); pos += 1 + l
        pos += 1; qtype = struct.unpack('>H', d[pos:pos+2])[0]; q = d[12:pos+4]
        name = '.'.join(labels).lower()
        ent = s.dns.get(name)
        ans = b''; rcode = 0; cnt = 0
        def enc(n): return b''.join(bytes([len(x)]) + x.encode() for x in n.split('.')) + b'\0'
        if ent is None: rcode = 3
        elif qtype == 1:
            chain = []
            cur = name
            while isinstance(s.dns.get(cur), tuple):
                tgt = s.dns[cur][1]; ans += b'\xc0\x0c' + struct.pack('>HHIH', 5, 1, 60, len(enc(tgt))) + enc(tgt); cnt += 1
                chain.append(tgt); cur = tgt
                if s.dns[cur] is None: break
                if len(chain) > 5: break
            ipv = s.dns.get(cur)
            if isinstance(ipv, str):
                ans += (b'\xc0\x0c' if not chain else enc(cur)) + struct.pack('>HHIH', 1, 1, 60, 4) + ip2b(ipv); cnt += 1
            if s.dns_cname_only and chain: ans = ans[:ans.rindex((b'\xc0\x0c' if not chain else enc(cur)) + struct.pack('>HHIH', 1, 1, 60, 4))]; cnt -= 1
        resp = qid + struct.pack('>HHHHH', 0x8180 | rcode, 1, cnt, 0, 0) + q + ans
        return [s.udp_reply(cmac, dst, src, 53, sp, resp)]
    dns_cname_only = False
    # ---------- TCP ----------
    def tcpseg(s, c, flags, seq, ack, data=b'', opts=b''):
        hl = 20 + len(opts)
        h = struct.pack('>HHIIBBHHH', c.sport, c.cport, seq & 0xffffffff, ack & 0xffffffff, (hl//4) << 4, flags, 65535, 0, 0) + opts
        seg = h + data
        ps = ip2b(c.sip) + ip2b(c.cip) + struct.pack('>BBH', 0, 6, len(seg))
        cs = csum(ps + seg)
        seg = seg[:16] + struct.pack('>H', cs) + seg[18:]
        return s.eth(c.cmac, 0x0800, s.ipv4(c.sip, c.cip, 6, seg))
    def tcp(s, cmac, src, dst, b, now):
        if len(b) < 20: return []
        sp, dp, seq, ack, off, fl, win = struct.unpack('>HHIIBBH', b[:16]); hl = (off >> 4) * 4
        ps = ip2b(src) + ip2b(dst) + struct.pack('>BBH', 0, 6, len(b))
        if csum(ps + b) != 0: s.log.append('bad tcp csum'); return []
        data = b[hl:]
        key = (src, sp, dst, dp)
        c = s.conns.get(key)
        if fl & 2:  # SYN
            if dp != 80: return [s.rst_for(cmac, src, dst, sp, dp, seq, ack, fl, len(data))]
            mss = 536
            i = 20
            while i < hl:
                k = b[i]
                if k == 0: break
                if k == 1: i += 1; continue
                if k == 2: mss = struct.unpack('>H', b[i+2:i+4])[0]
                i += b[i+1]
            if c is None or c.closed:
                c = Conn(src, sp, dst, dp, cmac, seq, mss); s.conns[key] = c; s.stats['syn'] += 1
            c.last_tx = now
            return [s.tcpseg(c, 0x12, c.iss, c.irs+1, b'', bytes([2,4]) + struct.pack('>H', s.mtu_mss))]
        if c is None:
            if fl & 4: return []
            return [s.rst_for(cmac, src, dst, sp, dp, seq, ack, fl, len(data))]
        if fl & 4: c.closed = True; return []
        res = []
        c.win = win
        if c.state == 'SYN_RCVD' and fl & 0x10 and ack == c.iss+1: c.state = 'ESTAB'
        # ack processing
        if fl & 0x10:
            total_end = c.iss + 1 + len(c.out) + (1 if c.fin_sent else 0)
            if (ack - c.snd_una) & 0xffffffff < 0x80000000 and (total_end - ack) & 0xffffffff < 0x80000000:
                if ack != c.snd_una: c.dupcount = 0
                c.snd_una = ack
                if c.fin_sent and ack == total_end: c.fin_acked = True
        # data
        if data or fl & 1:
            if seq == c.rcv_nxt:
                if not c.responded: c.req += data
                c.rcv_nxt = (c.rcv_nxt + len(data)) & 0xffffffff
                if fl & 1: c.rcv_nxt = (c.rcv_nxt + 1) & 0xffffffff; c.client_fin = True
            elif ((seq - c.rcv_nxt) & 0xffffffff) >= 0x80000000:
                pass  # old duplicate: just ack
            res.append(s.tcpseg(c, 0x10, c.iss + 1 + c.sent_off + (1 if c.fin_sent else 0) if False else s.snd_nxt(c), c.rcv_nxt))
        if not c.responded and b'\r\n\r\n' in c.req:
            c.responded = True; s.stats['req'] += 1
            c.out = s.build_response(c)
        res += s.send_data(c, now)
        return s.out(res[:1], False) + s.out(res[1:], True) if res else []
    def snd_nxt(s, c): return (c.iss + 1 + c.sent_off + (1 if c.fin_sent else 0)) & 0xffffffff
    def rst_for(s, cmac, src, dst, sp, dp, seq, ack, fl, ln):
        c = Conn(src, sp, dst, dp, cmac, seq, 536)
        if fl & 0x10: return s.tcpseg(c, 0x04, ack, 0)
        return s.tcpseg(c, 0x14, 0, seq + ln + (1 if fl & 3 else 0))
    def build_response(s, c):
        head, _ = c.req.split(b'\r\n\r\n', 1)
        lines = head.decode('latin1').split('\r\n')
        meth, path, ver = lines[0].split(' ')
        hdrs = {}
        for l in lines[1:]:
            if ':' in l: k, v = l.split(':', 1); hdrs[k.strip().lower()] = v.strip()
        r = s.http(meth, hdrs.get('host', ''), path, hdrs) if s.http else dict(status=404, body=b'no handler')
        status = r.get('status', 200); body = r.get('body', b''); mode = r.get('mode', 'cl')
        h = [f"HTTP/1.1 {status} {r.get('reason','OK')}"]
        for k, v in r.get('headers', []): h.append(f"{k}: {v}")
        if mode == 'cl': h.append(f"Content-Length: {len(body)}")
        if mode == 'chunked': h.append("Transfer-Encoding: chunked")
        h.append("Connection: close")
        raw = ('\r\n'.join(h) + '\r\n\r\n').encode('latin1')
        if mode == 'chunked':
            cs = r.get('chunk', 700); out = b''
            for i in range(0, len(body), cs): ch = body[i:i+cs]; out += b'%x\r\n' % len(ch) + ch + b'\r\n'
            out += b'0\r\n\r\n'; raw += out
        else: raw += body
        return raw
    def send_data(s, c, now):
        res = []
        if not c.out: return res
        inflight_off = ((c.snd_una - (c.iss + 1)) & 0xffffffff)
        if inflight_off > len(c.out) + 1: inflight_off = len(c.out)
        acked_off = min(inflight_off, len(c.out))
        if c.sent_off < acked_off: c.sent_off = acked_off
        while c.sent_off < len(c.out):
            inflight = c.sent_off - acked_off
            if inflight >= min(c.win, 8 * c.mss): break
            n = min(c.mss, len(c.out) - c.sent_off, c.win - inflight)
            if n <= 0: break
            res.append(s.tcpseg(c, 0x18, c.iss + 1 + c.sent_off, c.rcv_nxt, c.out[c.sent_off:c.sent_off+n]))
            c.sent_off += n; s.stats['tx_data'] += 1; c.last_tx = now
        if c.sent_off >= len(c.out) and not c.fin_sent:
            res.append(s.tcpseg(c, 0x11, c.iss + 1 + len(c.out), c.rcv_nxt)); c.fin_sent = True; c.last_tx = now
        return res
    def tick(s, now):
        res = []
        for c in list(s.conns.values()):
            if c.closed or not c.out: continue
            total_end = c.iss + 1 + len(c.out) + (1 if c.fin_sent else 0)
            if c.snd_una != total_end and now - c.last_tx > c.rto:
                # go-back-N
                c.sent_off = (c.snd_una - (c.iss + 1)) & 0xffffffff
                if c.sent_off > len(c.out): c.sent_off = len(c.out)
                c.fin_sent = False; c.last_tx = now; s.stats['retx'] += 1; c.rto = min(c.rto * 2, 3000)
                res += s.send_data(c, now)
        return s.out(res, True)
