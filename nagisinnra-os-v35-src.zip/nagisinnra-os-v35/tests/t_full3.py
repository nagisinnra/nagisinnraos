import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
def handler(m,host,path,h):
    if path=='/': return dict(body=b"<html><head><title>Example Domain</title></head><body><h1>Example Domain</h1><p>Welcome. <a href='/second'>second page</a></p></body></html>",headers=[('Content-Type','text/html')])
    if path=='/second': return dict(body=b"<html><head><title>Second</title></head><body><h1>Second page</h1><p>You clicked a link. <a href='/'>back to first</a></p></body></html>",headers=[('Content-Type','text/html')])
    return dict(status=404,reason='Not Found',body=b'x')
p=Peer(dns={'example.com':'93.184.216.34'},http=handler)
o=OS(p,boot_ms=3000); o.pump(500)
o.key(0x40); o.pump(300); o.key(0x26,mods=2); o.type('example.com\n'); o.pump(1500)
o.click(120,116); o.pump(1500)          # click 'second page' link (line 2 of page)
o.shot('f3_link')
o.click(39,79); o.pump(1500)            # back
o.shot('f3_back')
# --- editor: type, save as, reopen
o.key(0x3d); o.pump(200)                # F3
o.type('Hello editor!\nsecond line with TAB:\t.\n')
o.key(0x1f,mods=2); o.pump(200)         # Ctrl+S -> prompt (untitled)
o.type('note.txt\n'); o.pump(300)
o.shot('f3_editor')
# --- files app
o.key(0x3c); o.pump(300); o.shot('f3_files')
# --- paint
o.key(0x3e); o.pump(300)
for i in range(30): o.e.mouse(3,2,1,0); o.pump(5)
o.e.mouse(0,0,0,0); o.pump(100); o.shot('f3_paint')
# --- system, tetris
o.key(0x3f); o.pump(300)
o.key(0x41); o.pump(1500)               # F7 tetris
o.key(0x4b,ext=False); o.pump(200)
o.shot('f3_misc')
print("ok", p.stats)
