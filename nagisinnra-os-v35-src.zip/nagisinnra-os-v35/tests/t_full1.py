import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
BODY=b"<html><head><title>Example Domain</title></head><body><h1>Example Domain</h1><p>This domain is for use in illustrative examples. <a href='http://www.iana.org/domains/example'>More information...</a></p></body></html>"
def handler(m,host,path,h):
    if path=='/': return dict(body=BODY,headers=[('Content-Type','text/html; charset=UTF-8')])
    return dict(status=404,reason='Not Found',body=b'nope')
p=Peer(dns={'example.com':'93.184.216.34','www.iana.org':'192.0.43.8'},http=handler)
os_=OS(p,boot_ms=3000)
os_.pump(500)
os_.shot('f1_boot')
os_.term('ifconfig'); os_.term('ping example.com 2',wait=3500); os_.term('nslookup example.com',wait=800)
os_.term('wget http://example.com/ex.htm',wait=1500); os_.term('dir',wait=300); os_.term('curl http://example.com/',wait=1500)
os_.shot('f1_term')
print("done; stats",p.stats)
