import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
"""Boot the image in several configurations and assert the desktop is drawn."""
import sys, struct
sys.path.insert(0,ROOT+'/emu')
import numpy as np
from emu import Emu, L
ok=True
for noext,mem in ((0,64),(1,64),(0,16),(1,16),(0,32)):
    L.emu_set_no_ext(noext)
    e=Emu(ROOT+'/nagisinnra-os-v35.img',mem_mb=mem,nic=0)
    for _ in range(40):
        r=e.run(20_000_000)
        assert not r, e.fault()
    bi=struct.unpack('<6I',e.ram(0x500,24))
    im=np.array(e.screenshot().convert('L'))
    taskbar=int((im[580:598,:]>30).sum())>500; title=int((im[60:80,40:700]>30).sum())>100
    good=bi[0]==0x3547414e and taskbar and title and L.emu_vbe_active()==1
    print("boot noext=%d ram=%dMB  magic/ram_kb=%#x/%d  desktop=%s"%(noext,mem,bi[0],bi[1],"OK" if good else "FAIL"))
    ok&=good
sys.exit(0 if ok else 1)
