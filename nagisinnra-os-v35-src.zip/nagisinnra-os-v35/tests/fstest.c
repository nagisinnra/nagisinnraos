#include "nagi.h"
#include "fat12.h"
#define RES ((volatile u32*)0x7F000)
static u8 buf[70000], rb[70000];
static void pat(u8*b,u32 n,u32 seed){for(u32 i=0;i<n;i++)b[i]=(u8)((i*31+seed*7+(i>>8))^seed);}
static int check(const char*path,u16 cwd,u32 n,u32 seed){
    u16 d;char leaf[16];FsEnt f;
    if(fs_resolve(path,cwd,&d,leaf))return 0;
    if(!fs_find(d,leaf,&f))return 0;
    if(f.size!=n)return 0;
    memset(rb,0,sizeof rb);
    if(fs_read(&f,rb,sizeof rb)!=(int)n)return 0;
    pat(buf,n,seed);return !memcmp(buf,rb,n);
}
static int put(const char*path,u16 cwd,u32 n,u32 seed){
    u16 d;char leaf[16];if(fs_resolve(path,cwd,&d,leaf))return -99;
    pat(buf,n,seed);return fs_write(d,leaf,buf,n);
}
void kmain(void){
    timer_init();
    int fails=0,step=0;
#define T(c) do{step++;if(!(c)){fails++;RES[100+fails]=step;}}while(0)
    T(fs_init((u8*)0x200000));
    u32 free0=fs_free_bytes();
    T(put("HELLO.TXT",0,13,1)==0);
    T(put("big.bin",0,60000,2)==0);
    T(put("EMPTY",0,0,3)==0);
    T(put("a.b",0,513,4)==0);
    T(fs_mkdir(0,"DOCS")==0);
    T(fs_mkdir(0,"docs")==FSE_EXISTS);
    u16 docs;T(fs_chdir("\\docs",0,&docs)==0);
    T(put("note.txt",docs,1000,5)==0);
    T(fs_mkdir(docs,"SUB")==0);
    T(put("\\DOCS\\SUB\\deep.dat",0,5000,6)==0);
    u16 sub;T(fs_chdir("docs/sub",0,&sub)==0);
    u16 up;T(fs_chdir("..",sub,&up)==0);T(up==docs);
    u16 rt;T(fs_chdir("..\\..",sub,&rt)==0);T(rt==0);
    /* force directory growth: 40 files in SUB (> 16 entries per 512B cluster) */
    for(int i=0;i<40;i++){char n[16];ksnprintf(n,sizeof n,"F%d.DAT",i);T(put(n,sub,100+i,100+i)==0);}
    for(int i=0;i<40;i++){char n[16];ksnprintf(n,sizeof n,"F%d.DAT",i);T(check(n,sub,100+i,100+i));}
    T(check("HELLO.TXT",0,13,1));T(check("BIG.BIN",0,60000,2));T(check("EMPTY",0,0,3));T(check("A.B",0,513,4));
    T(check("\\docs\\note.txt",0,1000,5));T(check("docs\\sub\\deep.dat",0,5000,6));
    /* overwrite smaller / larger */
    T(put("big.bin",0,700,22)==0);T(check("big.bin",0,700,22));
    T(put("hello.txt",0,30000,23)==0);T(check("hello.txt",0,30000,23));
    /* rename + delete */
    T(fs_rename(0,"A.B","C.D")==0);T(check("C.D",0,513,4));T(!fs_find(0,"A.B",NULL));
    T(fs_delete(0,"EMPTY")==0);T(!fs_find(0,"EMPTY",NULL));
    T(fs_delete(0,"DOCS")==FSE_NOTEMPTY);
    for(int i=0;i<40;i+=2){char n[16];ksnprintf(n,sizeof n,"F%d.DAT",i);T(fs_delete(sub,n)==0);}
    for(int i=1;i<40;i+=2){char n[16];ksnprintf(n,sizeof n,"F%d.DAT",i);T(check(n,sub,100+i,100+i));}
    /* invalid names */
    T(put("toolongname.txt",0,1,1)==FSE_NAME);T(put("a*b",0,1,1)==FSE_NAME);
    /* fill the disk then recover */
    int k=0;for(;k<400;k++){char n[16];ksnprintf(n,sizeof n,"X%d",k);int r=put(n,0,40000,k);if(r==FSE_FULL||r==FSE_DIRFULL)break;T(r==0);}
    T(k>10&&k<400);
    T(put("BIG2",0,60000,9)==FSE_FULL);
    for(int i=0;i<k;i++){char n[16];ksnprintf(n,sizeof n,"X%d",i);T(fs_delete(0,n)==0);}
    T(put("BIG2",0,60000,9)==0);T(check("BIG2",0,60000,9));
    char p[64];fs_path(sub,p,sizeof p);
    scpy((char*)0x7F800,p,60);
    RES[0]=1;RES[1]=fails;RES[2]=step;RES[3]=free0;RES[4]=fs_free_bytes();
    for(;;)__asm__("hlt");
}
