#!/bin/bash
# Full regression: network stack, FAT12, HTML engine, boot configurations, GUI stress.
set -e
cd "$(dirname "$0")"
ROOT=$(cd .. && pwd)
make -s -C $ROOT/emu
( cd $ROOT && make -s && make -s -C emu )
bash build_nt.sh
echo "== network (DHCP/DNS/HTTP/ping)";            python3 t_net1.py | tail -1
echo "== network under loss/reorder/dup/PCI/fallback"; python3 t_net2.py | tail -1
echo "== FAT12 vs independent parser";              python3 run_fstest.py | grep -E "done=|FAT consistency"
echo "== HTML layout engine (smoke)";               python3 run_htmltest.py > /tmp/html_out.txt && grep -c "^---" /tmp/html_out.txt
echo "== boot configurations";                      python3 t_boot_check.py
echo "== GUI stress / leak check";                  python3 t_stress.py | grep -E "delta|recovered"
echo "ALL REGRESSION STAGES FINISHED"
