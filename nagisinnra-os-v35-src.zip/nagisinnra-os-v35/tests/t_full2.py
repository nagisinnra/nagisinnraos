import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
LONG="".join("<p>Paragraph %d: The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs. <a href='/p%d'>link %d</a></p>"%(i,i,i) for i in range(1,80))
JP="<html><head><meta charset='Shift_JIS'><title>日本語ページ</title></head><body><h1>日本語のテスト</h1><p>これはShift_JISで配信されるページです。漢字・ひらがな・カタカナ、ｱｲｳ半角。<a href='/'>トップへ</a></p></body></html>".encode('cp932')
def handler(m,host,path,h):
    if path=='/': return dict(body=b"<html><head><title>Example Domain</title></head><body><h1>Example Domain</h1><p>Welcome. <a href='/long'>long page</a> | <a href='/jp'>japanese</a> | <a href='/redir'>redirect</a> | <a href='/file.zip'>zip</a></p></body></html>",headers=[('Content-Type','text/html')])
    if path=='/long': return dict(body=("<html><head><title>Long</title></head><body>"+LONG+"</body></html>").encode(),mode='chunked',chunk=900,headers=[('Content-Type','text/html; charset=utf-8')])
    if path=='/jp': return dict(body=JP,headers=[('Content-Type','text/html')])
    if path=='/redir': return dict(status=302,reason='Found',headers=[('Location','/jp')],body=b'')
    if path=='/file.zip': return dict(body=bytes(range(256))*40,headers=[('Content-Type','application/zip')])
    return dict(status=404,reason='Not Found',body=b'<h1>Not found</h1>',headers=[('Content-Type','text/html')])
p=Peer(dns={'example.com':'93.184.216.34'},http=handler)
o=OS(p,boot_ms=3000); o.pump(500)
o.key(0x40)       # F6 -> browser
o.pump(500); o.shot('f2_home')
o.key(0x26,mods=2)   # Ctrl+L
o.type('example.com\n'); o.pump(1500); o.shot('f2_example')
# click the 'long page' link: find it visually by trying known position later; use keyboard navigation instead
o.key(0x26,mods=2); o.type('example.com/long\n'); o.pump(2500); o.shot('f2_long')
o.wheel(5); o.pump(300); o.shot('f2_long_scrolled')
o.key(0x26,mods=2); o.type('example.com/jp\n'); o.pump(1500); o.shot('f2_jp')
o.key(0x26,mods=2); o.type('example.com/redir\n'); o.pump(2000); o.shot('f2_redir')
o.key(0x26,mods=2); o.type('example.com/file.zip\n'); o.pump(2000); o.shot('f2_zip')
o.key(0x26,mods=2); o.type('https://example.com/\n'); o.pump(800); o.shot('f2_https')
print(p.stats)
