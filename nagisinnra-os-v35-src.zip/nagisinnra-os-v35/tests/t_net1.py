import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, hashlib
sys.path.insert(0,ROOT+'/tests')
from netsim import NetSim
from peer import Peer

BIG = bytes((i*7+i//251) & 255 for i in range(150000))
def handler(meth, host, path, hdrs):
    if path == '/': return dict(body=b'<html><title>Hello</title><body>Hello from fake web!</body></html>', headers=[('Content-Type','text/html')])
    if path == '/big': return dict(body=BIG, headers=[('Content-Type','application/octet-stream')])
    if path == '/chunk': return dict(body=BIG[:5000], mode='chunked', chunk=333, headers=[('Content-Type','text/plain')])
    if path == '/close': return dict(body=b'until-close body ' * 100, mode='close')
    if path == '/redir': return dict(status=302, reason='Found', headers=[('Location','http://example.com/')], body=b'')
    if path == '/empty': return dict(body=b'')
    return dict(status=404, reason='Not Found', body=b'nope ' + path.encode())

dns = {'example.com':'93.184.216.34', 'www.test.org':('CNAME','real.test.org'), 'real.test.org':'10.9.8.7', 'neverssl.com':'34.223.124.45'}
p = Peer(dns=dns, http=handler)
sim = NetSim(p)
ok = sim.pump(8000, lambda: sim.umb(8) in (3,4))
print("net_state", sim.umb(8), "ip %08x gw %08x dns %08x" % (sim.umb(9), sim.umb(10), sim.umb(11)), "t=%dms"%sim.ms(), p.stats)
assert sim.umb(8)==3 and sim.umb(9)==0xC0A85664, "DHCP failed"

r = sim.http('http://example.com/'); print("GET /", r['ok'], r['status'], r['n'], r['body'][:60], r['ctype'])
assert r['status']==200 and b'Hello from fake web' in r['body']
r = sim.http('http://www.test.org/big'); print("GET /big (CNAME)", r['ok'], r['status'], r['n'], "match", r['body']==BIG, p.stats)
assert r['body']==BIG
r = sim.http('http://example.com/chunk'); print("chunked", r['status'], r['n'], r['chunked'], r['body']==BIG[:5000])
assert r['body']==BIG[:5000]
r = sim.http('http://example.com/close'); print("until-close", r['status'], r['n'])
assert r['n']==1700
r = sim.http('http://example.com/redir'); print("redirect", r['status'], r['loc'])
r = sim.http('http://example.com/nothing'); print("404", r['status'], r['body'])
r = sim.http('http://example.com/empty'); print("empty", r['status'], r['n'])
r = sim.http('https://example.com/'); print("https ->", r)
r = sim.http('http://nonexistent.invalid/'); print("nxdomain ->", r['ok'], r['status'])
st=sim.cmd(2,'8.8.8.8'); print("ping", st, "seq", sim.mb(2), "rtt", sim.mb(3),"ms")
print("rx drops", sim.umb(14), "peer", p.stats, p.log[:3])
print("ALL OK")
