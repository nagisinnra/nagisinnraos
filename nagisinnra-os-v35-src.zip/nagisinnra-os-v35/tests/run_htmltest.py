import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, ctypes, subprocess
sys.path.insert(0,ROOT+'/emu')
from emu import Emu, L
CF="-m32 -march=i386 -ffreestanding -fno-pie -fno-stack-protector -fno-builtin -fno-tree-loop-distribute-patterns -nostdlib -O2 -Wall -Wextra -Wno-misleading-indentation -Wno-unused-parameter -I../src"
subprocess.check_call("""as --32 nt_entry.S -o /tmp/nt_entry.o && gcc %s -c htmltest.c -o /tmp/htmltest.o && for f in lib timer html gfx font_data; do gcc %s -c ../src/$f.c -o /tmp/$f.o; done && ld -m elf_i386 -T nt.ld -o /tmp/htmltest.elf /tmp/nt_entry.o /tmp/htmltest.o /tmp/lib.o /tmp/timer.o /tmp/html.o /tmp/gfx.o /tmp/font_data.o 2>/dev/null && objcopy -O binary /tmp/htmltest.elf htmltest.bin"""%(CF,CF),shell=True,cwd=ROOT+'/tests')
L.emu_boot_direct.argtypes=[ctypes.c_uint32,ctypes.c_uint32]
e=Emu(b'\0'*512,mem_mb=32,nic=0); L.emu_boot_direct(0x10000,0x9f000)
e.poke(0x10000,open(ROOT+'/tests/htmltest.bin','rb').read())
g=lambda i:int.from_bytes(e.ram(0x7F000+4*i,4),'little')
def layout(src,cols=40,html=True,ctype=''):
    e.poke(0x200000,src); e.poke(0x7F100,ctype.encode()+b'\0')
    for i,v in ((1,len(src)),(2,cols),(3,1 if html else 0)): e.poke(0x7F000+4*i,v.to_bytes(4,'little'))
    e.poke(0x7F028,(0).to_bytes(4,'little')); e.poke(0x7F000,(1).to_bytes(4,'little'))
    for _ in range(400):
        e.run(200000)
        if g(0)==0 and g(10)==1: break
    e.poke(0x7F028,(0).to_bytes(4,'little'))
    nl=g(5); nc=g(4)
    cp=e.ram(0x300000,nc*2); lk=e.ram(0x340000,nc*2); ls=e.ram(0x3A0000,nl*4); ll=e.ram(0x3C0000,nl*2)
    lines=[]
    for i in range(nl):
        s=int.from_bytes(ls[i*4:i*4+4],'little'); n=int.from_bytes(ll[i*2:i*2+2],'little')
        txt=''; prev=0
        for k in range(s,s+n):
            c=int.from_bytes(cp[k*2:k*2+2],'little'); l=int.from_bytes(lk[k*2:k*2+2],'little')
            if l!=prev: txt+=('{%d:'%l) if l else '}'; prev=l
            txt+=chr(c)
        if prev: txt+='}'
        lines.append(txt)
    title=e.ram(0x7F800,80).split(b'\0')[0].decode('utf8','replace')
    e.poke(0x7F028,(0).to_bytes(4,'little')); e.poke(0x7F000+40,(0).to_bytes(4,'little'))
    return lines,title,g(6),g(8)
def show(name,*a,**k):
    lines,title,nl,cs=layout(*a,**k)
    print("--- %s (title=%r links=%d charset=%d)"%(name,title,nl,cs))
    for l in lines: print("|"+l)
    return lines
if __name__=='__main__':
    show("basic",b"<html><head><title>My Page</title><style>p{color:red}</style><script>var x='<b>no</b>';</script></head><body><h1>Hello &amp; welcome</h1><p>This is a <a href='/x?a=1&amp;b=2'>link to somewhere</a> in a paragraph that must wrap around nicely at forty columns.</p><p>Second&nbsp;paragraph.<br>after br</p></body></html>")
    show("lists",b"<ul><li>one<li>two <b>bold</b><ul><li>nested</li></ul></ul><ol><li>first</li><li>second</li></ol><p>tail",30)
    show("pre+table",b"<pre>line1\n  indented\tTAB\n</pre><table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table><hr>end",30)
    show("entities",b"&lt;tag&gt; &quot;q&quot; &#65;&#x42; &copy; &mdash; &unknown; a&amp;b &eacute;",40)
    show("utf8 jp",'<p>日本語のテスト。ひらがなカタカナ漢字表示確認 ネットワーク接続</p>'.encode('utf8'),20)
    show("sjis",'<meta charset="Shift_JIS"><p>日本語のテスト。ネットワーク</p>'.encode('shift_jis'),20)
    show("sjis via header",'<p>日本語ｱｲｳ半角</p>'.encode('cp932'),20,ctype='text/html; charset=Shift_JIS')
    show("euc",'<p>日本語のテスト。漢字</p>'.encode('euc_jp'),20,ctype='text/html; charset=EUC-JP')
    show("latin1",'<p>caf\xe9 na\xefve</p>'.encode('latin1'),40)
    show("plain",b"first line is quite long and should be hard wrapped at the column limit\nshort\n\nafter blank",30,html=False)
    show("long word",b"<p>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa end</p>",20)
    show("unclosed/garbage",b"<div><p>text <b>bold <i>x</div> < 5 and 3 > 2 <br/><img src=a alt='pic'> <input type=submit value=Go>",40)
