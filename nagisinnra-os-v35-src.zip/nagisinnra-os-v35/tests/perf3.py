import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
from emu import L
def measure(o,label):
    L.emu_watch2(symaddr('redraw'),symaddr('present'))
    for k in range(40): o.e.mouse(1 if k&1 else -1,0,0,0); o.pump(60)
    n=L.emu_watch2_n(); s=L.emu_watch2_sum()
    print("%-26s scene build %.2fM instr  (+0.24M present)  n=%d"%(label,s/max(n,1)/1e6,n))
o=OS(None,boot_ms=3000)
measure(o,"terminal only")
o.key(0x40); o.pump(300); measure(o,"+ browser (home)")
o.key(0x44); o.pump(300); measure(o,"+ games centre")
