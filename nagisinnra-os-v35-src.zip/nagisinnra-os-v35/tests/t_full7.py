import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
o=OS(None,boot_ms=3000); o.pump(300)
o.term('browse file:DOCS/WELCOME.HTM',wait=800)
o.click(90,193); o.pump(600); o.shot('k1_rel')          # relative link ../README.TXT
# Files app: open DOCS, double-click WELCOME.HTM
o.key(0x3c); o.pump(300)
o.click(240,184); o.click(240,184,settle=500)           # double click DOCS (first row after header)
o.shot('k2_files_docs')
# editor: Ctrl+O
o.key(0x3d); o.pump(200); o.key(0x18,mods=2); o.pump(200); o.type('docs\\about.txt\n'); o.pump(300)
o.shot('k3_editor_open')
