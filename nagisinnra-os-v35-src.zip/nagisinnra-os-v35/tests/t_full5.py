import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
o=OS(None,boot_ms=3000); o.pump(300)
for c in ['mkdir work','cd work','echo hello world > a.txt','echo second >> a.txt','type a.txt','copy a.txt b.txt','ren b.txt c.txt','dir','cd ..','dir work','del work\\c.txt','rmdir work','mem','ver']:
    o.term(c,wait=250)
# tab completion + history
o.type('type READ'); o.key(0x0f); o.pump(100); o.key(0x1c); o.pump(300)
o.key(0x48); o.pump(100)       # history up -> shows previous command
o.shot('h1_term')
# local html via browse command + relative link
o.term('cls',200); o.term('browse file:DOCS/WELCOME.HTM',wait=800)
o.shot('h2_local')
# click relative link ../README.TXT: find it on screen by scanning later; use Ctrl+U view source instead
o.key(0x16,mods=2); o.pump(400); o.shot('h3_source')
print("ok")
