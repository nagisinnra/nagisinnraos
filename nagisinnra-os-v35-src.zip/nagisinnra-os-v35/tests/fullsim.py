import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, ctypes, subprocess, struct
sys.path.insert(0,ROOT+'/emu'); sys.path.insert(0,ROOT+'/tests')
from emu import Emu, L
from peer import Peer
IMG=ROOT+'/nagisinnra-os-v35.img'; ELF=ROOT+'/build/kernel.elf'
def symaddr(name):
    for l in subprocess.check_output(['nm',ELF]).decode().splitlines():
        p=l.split()
        if len(p)==3 and p[2]==name: return int(p[0],16)
SC={}
for i,c in enumerate("1234567890-=",2): SC[c]=(i,0)
for i,c in enumerate("qwertyuiop[]",0x10): SC[c]=(i,0)
for i,c in enumerate("asdfghjkl;'`",0x1e): SC[c]=(i,0)
for i,c in enumerate("\\zxcvbnm,./",0x2b): SC[c]=(i,0)
SC[' ']=(0x39,0); SC['\n']=(0x1c,0); SC['\b']=(0x0e,0); SC['\t']=(0x0f,0)
for c,b in zip('!@#$%^&*()_+','1234567890-='): SC[c]=(SC[b][0],1)
for c,b in zip('{}:"~|<>?','[];\'`\\,./'): SC[c]=(SC[b][0],1)
for c in 'abcdefghijklmnopqrstuvwxyz': SC[c.upper()]=(SC[c][0],1)
class OS:
    def __init__(s,peer=None,nic=1,mem=64,boot_ms=2500):
        s.e=Emu(IMG,mem_mb=mem,nic=nic if peer else 0); s.peer=peer; s.mxa=symaddr('mx'); s.mya=symaddr('my')
        s.pump(boot_ms)
    def ms(s): return s.e.ticks*1000//1193182
    def pump(s,ms,until=None):
        end=s.ms()+ms
        while s.ms()<end:
            r=s.e.run(30000)
            if r: raise RuntimeError("emu stop %d %s"%(r,s.e.fault()))
            if s.peer:
                now=s.ms()
                for f in s.e.nic_tx():
                    for o in s.peer.handle(f,now): s.e.nic_rx(o)
                for o in s.peer.tick(now): s.e.nic_rx(o)
            if until and until(): return True
        return until() if until else None
    def key(s,sc,mods=0,ext=False,settle=60):
        if mods&1: s.e.key(0x2a,release=False)
        if mods&2: s.e.key(0x1d,release=False)
        if mods&4: s.e.key(0x38,release=False)
        s.e.key(sc,ext=ext)
        if mods&4: s.e.key(0x38|0x80,release=False)
        if mods&2: s.e.key(0x1d|0x80,release=False)
        if mods&1: s.e.key(0x2a|0x80,release=False)
        s.pump(settle)
    def type(s,text,settle=25):
        for ch in text:
            sc,sh=SC[ch]
            if sh: s.e.key(0x2a,release=False)
            s.e.key(sc)
            if sh: s.e.key(0xaa,release=False)
            s.pump(settle)
    def pos(s): return (int.from_bytes(s.e.ram(s.mxa,4),'little',signed=True),int.from_bytes(s.e.ram(s.mya,4),'little',signed=True))
    def move(s,x,y):
        for _ in range(60):
            cx,cy=s.pos(); dx,dy=x-cx,y-cy
            if abs(dx)<1 and abs(dy)<1: break
            s.e.mouse(max(-120,min(120,dx)),max(-120,min(120,dy)),0,0); s.pump(8)
    def click(s,x,y,settle=80):
        s.move(x,y); s.e.mouse(0,0,1,0); s.pump(30); s.e.mouse(0,0,0,0); s.pump(settle)
    def wheel(s,dz): s.e.mouse(0,0,0,dz); s.pump(80)
    def shot(s,name): s.e.screenshot(ROOT+'/tests/%s.png'%name)
    def term(s,cmd,wait=800): s.type(cmd+'\n'); s.pump(wait)
