import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, struct
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
PAGE=b"<html><head><title>P</title></head><body>"+b"<p>line of text with a <a href='/x'>link</a> and more words to fill space</p>"*60+b"</body></html>"
def handler(m,host,path,h):
    if path=='/slow': return dict(body=PAGE,mode='chunked',chunk=400,headers=[('Content-Type','text/html')])
    if path=='/err500': return dict(status=500,reason='Server Error',body=b'<h1>boom</h1>',headers=[('Content-Type','text/html')])
    return dict(body=PAGE,headers=[('Content-Type','text/html')])
class P2(Peer):
    def tcp(s,cmac,src,dst,b,now):
        import struct
        dp=struct.unpack('>H',b[2:4])[0]
        if dp==81:   # closed port -> RST
            sp,_,seq,ack,off,fl,win=struct.unpack('>HHIIBBH',b[:16])
            if fl&2:
                from peer import Conn
                c=Conn(src,sp,dst,dp,cmac,seq,536); s.stats['rst']+=1
                return [s.tcpseg(c,0x14,0,seq+1)]
            return []
        if dp==82: return []    # black hole: SYN never answered
        return Peer.tcp(s,cmac,src,dst,b,now)
p=P2(dns={'a.test':'10.0.0.1','slow.test':'10.0.0.2'},http=handler)
o=OS(p,boot_ms=3000); o.pump(300)
used_addr=symaddr('used')
used=lambda: int.from_bytes(o.e.ram(used_addr,4),'little')
o.key(0x40); o.pump(300)
def load(url,wait=2500):
    o.key(0x26,mods=2); o.type(url+'\n',settle=12); o.pump(wait)
load('a.test/');                       base=used(); print("pages in use after first load:",base)
for i in range(12): load('a.test/p%d'%i,1500); load('slow.test/slow',2000)
print("after 24 loads  used=%d (delta %+d)"%(used(),used()-base))
load('a.test/err500',1500);  o.shot('j1_500')
load('nonexist.test/',3500); o.shot('j2_dns')
load('a.test:81/',2000);     o.shot('j3_refused')
load('a.test:82/',2500);     o.shot('j4_hang_midway')
o.key(0x01); o.pump(300);    o.shot('j5_stopped')     # Esc cancels
load('a.test/',1500)
print("recovered after errors; used delta %+d"%(used()-base), "peer",p.stats)
