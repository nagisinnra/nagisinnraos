import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, ctypes, os
sys.path.insert(0, ROOT+'/emu')
from emu import Emu
from peer import Peer

class NetSim:
    """Runs nettest.bin on the emulator against a Peer, in virtual time."""
    def __init__(s, peer, nic=1, binpath=ROOT+'/tests/nettest.bin', mem_mb=32):
        img = b'\0' * 512
        s.e = Emu(img, mem_mb=mem_mb, nic=nic)
        from emu import L
        L.emu_boot_direct.argtypes = [ctypes.c_uint32, ctypes.c_uint32]
        L.emu_boot_direct(0x10000, 0x9f000)
        s.e.poke(0x10000, open(binpath, 'rb').read())
        s.peer = peer; s.now = 0; s.delay_q = []
    def ms(s): return s.e.ticks * 1000 // 1193182
    def pump(s, ms, until=None):
        end = s.ms() + ms
        while s.ms() < end:
            r = s.e.run(30000)
            if r: raise RuntimeError('emulator stopped: %d %s' % (r, s.e.fault()))
            now = s.ms()
            for f in s.e.nic_tx():
                for o in s.peer.handle(f, now): s.deliver(o)
            for o in s.peer.tick(now): s.deliver(o)
            if until and until(): return True
        return until() if until else None
    def deliver(s, f): s.e.nic_rx(f)
    def mb(s, i): return int.from_bytes(s.e.ram(0x7F000 + 4*i, 4), 'little', signed=True)
    def umb(s, i): return int.from_bytes(s.e.ram(0x7F000 + 4*i, 4), 'little')
    def setmb(s, i, v): s.e.poke(0x7F000 + 4*i, int(v).to_bytes(4, 'little', signed=True))
    def cmd(s, c, arg, timeout=20000):
        s.e.poke(0x7F100, arg.encode() + b'\0'); s.setmb(1, 0); s.setmb(0, c)
        ok = s.pump(timeout, lambda: s.umb(1) != 0)
        return s.umb(1)
    def http(s, url, timeout=30000):
        st = s.cmd(1, url, timeout)
        r = dict(ok=(st == 1), status=s.mb(2), n=s.mb(3), trunc=s.mb(4), chunked=s.mb(5), cl=s.mb(6))
        r['body'] = s.e.ram(0x200000, max(r['n'], 0))
        r['loc'] = s.e.ram(0x7F800, 200).split(b'\0')[0].decode()
        r['ctype'] = s.e.ram(0x7F900, 48).split(b'\0')[0].decode()
        return r
