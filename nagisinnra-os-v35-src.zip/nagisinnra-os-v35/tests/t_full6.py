import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
o=OS(None,boot_ms=3000); o.pump(300)
for c in ['mkdir work','cd work','echo hello world > a.txt','echo second >> a.txt','type a.txt','copy a.txt b.txt','ren b.txt c.txt','dir','cd ..','rmdir work','del work\\c.txt','del work\\a.txt','rmdir work','dir','bogus']:
    o.term(c,wait=250)
o.shot('i1_fileops')
