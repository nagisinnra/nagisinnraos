import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
def handler(m,host,path,h):
    if path=='/': return dict(body=b"<html><head><title>Example Domain</title></head><body><h1>Example Domain</h1><p>Welcome. <a href='/second'>second page</a></p></body></html>",headers=[('Content-Type','text/html')])
    if path=='/second': return dict(body=b"<html><head><title>Second</title></head><body><h1>Second page</h1><p>You clicked a link.</p></body></html>",headers=[('Content-Type','text/html')])
    return dict(status=404,reason='Not Found',body=b'x')
p=Peer(dns={'example.com':'93.184.216.34'},http=handler)
o=OS(p,boot_ms=3000); o.pump(300)
o.key(0x40); o.pump(300); o.key(0x26,mods=2); o.type('example.com\n'); o.pump(1500)
o.click(140,139); o.pump(1500); o.shot('g1_link')
o.click(39,79); o.pump(1500); o.shot('g2_back')
o.click(39,79); o.pump(300)   # back again at start: no-op
o.click(748,45) ; o.pump(200)  # maximize? (x=16+768-40=744..) 
o.shot('g3_max')
# games centre
o.key(0x44); o.pump(600); o.shot('g4_games')
o.key(0x42); o.pump(2500); o.shot('g5_snake')    # F8 snake
# start menu
o.click(24,589); o.pump(300); o.shot('g6_start')
print("link click requests:",p.stats['req'])
