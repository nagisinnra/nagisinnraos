#include "nagi.h"
/* Headless network test kernel. Host drives it through a mailbox at 0x7F000. */
#define MB ((volatile u32*)0x7F000)
#define MB_URL ((char*)0x7F100)
#define BODY ((u8*)0x200000)
#define BODYCAP (512*1024)
static Http http;
void kmain(void){
    timer_init();
    net_init();
    MB[8]=net_state; /* status mirror */
    int busy=0,ping_seq=0;
    for(;;){
        net_poll();
        MB[8]=net_state;MB[9]=net_ip;MB[10]=net_gw;MB[11]=net_dns;MB[12]=nic_rx_frames;MB[13]=nic_tx_frames;MB[14]=nic_rx_drops;
        u32 cmd=MB[0];
        if(cmd&&!busy){
            if(cmd==1){ /* http get */
                char host[80],path[300];u16 port;
                int r=url_split(MB_URL,host,sizeof host,&port,path,sizeof path);
                if(r!=1){MB[1]=2;MB[2]=(r==-1)?HE_HTTPS:HE_BADURL;MB[0]=0;}
                else{ http_get(&http,host,port,path,BODY,BODYCAP); busy=1; MB[1]=0; }
            } else if(cmd==2){ /* ping */
                u32 ip;ip_parse(MB_URL,&ip);ping_send(ip,++ping_seq);busy=2;MB[1]=0;
            } else if(cmd==3){ /* dns */
                if(!dns_start(MB_URL)){MB[1]=2;MB[0]=0;} else {busy=3;MB[1]=0;}
            } else if(cmd==4){ net_dhcp_start(); MB[0]=0; }
            MB[0]=cmd==4?0:MB[0];
        }
        if(busy==1){
            http_poll(&http);
            if(http.state==HTTP_DONE||http.state==HTTP_ERROR){
                MB[2]=http.state==HTTP_DONE?http.status:-http.err;MB[3]=http.len;MB[4]=http.truncated;
                MB[5]=http.chunked;MB[6]=http.content_length;
                scpy((char*)0x7F800,http.location,200);scpy((char*)0x7F900,http.ctype,48);
                MB[1]=http.state==HTTP_DONE?1:2;busy=0;MB[0]=0;
            }
        } else if(busy==2){
            u32 from;int seq;u32 rtt;
            if(ping_poll(&from,&seq,&rtt)){MB[2]=seq;MB[3]=rtt;MB[1]=1;busy=0;MB[0]=0;}
        } else if(busy==3){
            u32 ip;int r=dns_poll(&ip);
            if(r){MB[1]=r>0?1:2;MB[2]=ip;busy=0;MB[0]=0;}
        }
    }
}
