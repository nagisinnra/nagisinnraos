.code32
.section .text.entry
.global _start
.extern kmain
.extern __bss_start
.extern __bss_end
_start:
 cli
 movw $0x10,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%ss
 movl $0x9f000,%esp
 cld
 movl $__bss_start,%edi
 movl $__bss_end,%ecx
 subl %edi,%ecx
 xorl %eax,%eax
 rep stosb
 call kmain
1: hlt
 jmp 1b
