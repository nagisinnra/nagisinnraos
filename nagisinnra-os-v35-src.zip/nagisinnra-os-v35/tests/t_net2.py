import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from netsim import NetSim
from peer import Peer
BIG = bytes((i*13+i//97) & 255 for i in range(120000))
def handler(meth, host, path, hdrs):
    if path == '/big': return dict(body=BIG)
    if path == '/chunk': return dict(body=BIG[:30000], mode='chunked', chunk=1000)
    return dict(body=b'ok')
dns={'a.test':'10.1.1.1'}
def run(name, nic=1, **kw):
    p=Peer(dns=dns,http=handler,**kw); sim=NetSim(p,nic=nic)
    sim.pump(15000, lambda: sim.umb(8) in (3,4))
    res=[]
    for url,exp in (('http://a.test/big',BIG),('http://a.test/chunk',BIG[:30000]),('http://a.test/x',b'ok')):
        r=sim.http(url,timeout=90000); res.append(r['ok'] and r['body']==exp)
    print("%-34s state=%d results=%s retx=%d dropped=%d ringdrops=%d t=%ds"%(name,sim.umb(8),res,p.stats['retx'],p.stats['dropped'],sim.umb(14),sim.ms()//1000))
    return all(res) and sim.umb(8) in (3,4)
ok=True
ok&=run("clean, PCI NIC", nic=2)
ok&=run("5% loss", loss=0.05)
ok&=run("15% loss", loss=0.15, seed=5)
ok&=run("reorder 20%", reorder=0.2, seed=3)
ok&=run("dup 10% + loss 5% + reorder 10%", dup=0.1, loss=0.05, reorder=0.1, seed=9)
ok&=run("no DHCP server (static fallback)", no_dhcp=True)
ok&=run("small MSS 536", mtu_mss=536)
print("ALL OK" if ok else "SOME FAILED")
