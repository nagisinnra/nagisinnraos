import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0,ROOT+'/tests')
from fullsim import *
JP="<html><head><meta charset='Shift_JIS'><title>日本語ページ</title></head><body><h1>日本語のテスト</h1><p>これはShift_JISで配信されるHTTPページです。漢字・ひらがな・カタカナ、ｱｲｳ半角も表示できます。</p><ul><li><a href='/'>トップへ</a></li><li>ネットワーク接続設定</li></ul></body></html>".encode('cp932')
EX=b"<html><head><title>Example Domain</title></head><body><h1>Example Domain</h1><p>This domain is for use in illustrative examples in documents.</p><p><a href='/jp'>Japanese page (Shift_JIS)</a></p></body></html>"
def handler(m,host,path,h):
    if path=='/jp': return dict(body=JP,headers=[('Content-Type','text/html')])
    return dict(body=EX,headers=[('Content-Type','text/html; charset=UTF-8')])
p=Peer(dns={'example.com':'93.184.216.34'},http=handler)
o=OS(p,boot_ms=3000); o.pump(500)
for c in ['ifconfig','ping example.com 3','wget http://example.com/ index.htm','dir']: o.term(c,wait=1500 if 'ping' in c else 800)
o.shot('s1_terminal')
o.key(0x40); o.pump(300); o.key(0x26,mods=2); o.type('example.com\n'); o.pump(1500); o.shot('s2_browser')
o.key(0x26,mods=2); o.type('example.com/jp\n'); o.pump(1500); o.shot('s3_japanese')
o.key(0x3c); o.pump(300); o.shot('s4_files')
