#include "nagi.h"
#include "html.h"
#define MB ((volatile u32*)0x7F000)
void kmain(void){
    timer_init();
    static Page pg;
    pg.cp=(u16*)0x300000;pg.lk=(u16*)0x340000;pg.st=(u8*)0x380000;pg.ccap=100000;
    pg.ls=(u32*)0x3A0000;pg.ll=(u16*)0x3C0000;pg.lcap=8000;
    pg.pool=(char*)0x3D0000;pg.pool_cap=60000;pg.lkoff=(u32*)0x3E0000;pg.lkcap=4000;
    for(;;){
        if(MB[0]==1){
            int len=MB[1],cols=MB[2],ish=MB[3];
            const char*ct=(const char*)0x7F100;
            int cs=html_charset((u8*)0x200000,len,ct[0]?ct:NULL);
            page_layout(&pg,(u8*)0x200000,len,cols,ish,cs);
            MB[4]=pg.ncells;MB[5]=pg.nlines;MB[6]=pg.nlinks;MB[7]=pg.truncated;MB[8]=cs;
            scpy((char*)0x7F800,pg.title,80);
            MB[0]=0;MB[10]=1;
        }
    }
}
