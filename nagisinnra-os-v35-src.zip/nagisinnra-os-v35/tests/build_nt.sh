set -e
cd "$(dirname "$0")"
as --32 nt_entry.S -o /tmp/nt_entry.o
for f in nettest; do gcc -m32 -march=i386 -ffreestanding -fno-pie -fno-stack-protector -fno-builtin -fno-tree-loop-distribute-patterns -nostdlib -O2 -Wall -Wextra -Wno-misleading-indentation -Wno-unused-but-set-variable -I../src -c $f.c -o /tmp/$f.o; done
for f in lib timer mem nic net http; do gcc -m32 -march=i386 -ffreestanding -fno-pie -fno-stack-protector -fno-builtin -fno-tree-loop-distribute-patterns -nostdlib -O2 -Wall -Wextra -Wno-misleading-indentation -Wno-unused-but-set-variable -I../src -c ../src/$f.c -o /tmp/$f.o; done
ld -m elf_i386 -T nt.ld -o /tmp/nettest.elf /tmp/nt_entry.o /tmp/nettest.o /tmp/lib.o /tmp/timer.o /tmp/mem.o /tmp/nic.o /tmp/net.o /tmp/http.o 2>/dev/null
objcopy -O binary /tmp/nettest.elf nettest.bin
