import os
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, ctypes
sys.path.insert(0,ROOT+'/emu'); sys.path.insert(0,ROOT+'/tools')
from emu import Emu, L
from mkfat import mkfs, Fat12
import subprocess
CF="-m32 -march=i386 -ffreestanding -fno-pie -fno-stack-protector -fno-builtin -fno-tree-loop-distribute-patterns -nostdlib -O2 -Wall -Wextra -Wno-misleading-indentation -I../src"
cmds="""as --32 nt_entry.S -o /tmp/nt_entry.o && gcc %s -c fstest.c -o /tmp/fstest.o && for f in lib timer fat12; do gcc %s -c ../src/$f.c -o /tmp/$f.o; done && ld -m elf_i386 -T nt.ld -o /tmp/fstest.elf /tmp/nt_entry.o /tmp/fstest.o /tmp/lib.o /tmp/timer.o /tmp/fat12.o 2>/dev/null && objcopy -O binary /tmp/fstest.elf fstest.bin"""%(CF,CF)
subprocess.check_call(cmds,shell=True,cwd=ROOT+'/tests')
vol=mkfs(4000)
e=Emu(b'\0'*512,mem_mb=32,nic=0)
L.emu_boot_direct.argtypes=[ctypes.c_uint32,ctypes.c_uint32]; L.emu_boot_direct(0x10000,0x9f000)
e.poke(0x10000,open(ROOT+'/tests/fstest.bin','rb').read()); e.poke(0x200000,bytes(vol))
for i in range(200):
    r=e.run(5_000_000)
    if r: print("stop",r,e.fault()); break
    if int.from_bytes(e.ram(0x7F000,4),'little')==1: break
g=lambda i:int.from_bytes(e.ram(0x7F000+4*i,4),'little')
print("done=%d fails=%d steps=%d free %d -> %d  path(sub)=%s"%(g(0),g(1),g(2),g(3),g(4),e.ram(0x7F800,30).split(b'\0')[0]))
print("failed steps:",[g(100+i) for i in range(1,g(1)+1)])
img=bytearray(e.ram(0x200000,4000*512))
fs=Fat12(img)
tree=fs.walk()
print("independent parse: %d entries, free clusters %d"%(len(tree),fs.free_clusters()))
for k,v in sorted(tree.items())[:8]: print("  ",k,None if v is None else len(v))
# cross-check FAT consistency: every cluster reachable exactly once
seen={}
def mark(cl,owner):
    for c in fs.chain(cl):
        assert c not in seen,("cross-linked",c,owner,seen[c]); seen[c]=owner
def rec(cl,pref):
    for en in fs.dir_entries(cl):
        if en['name'] in ('.','..'): continue
        if en['cluster']: mark(en['cluster'],pref+en['name'])
        if en['attr']&0x10: rec(en['cluster'],pref+en['name']+'\\')
rec(0,'')
used=sum(1 for c in range(2,fs.ncl+2) if fs.fget(c)!=0)
print("FAT consistency: reachable %d == allocated %d ->"%(len(seen),used), len(seen)==used)
