#ifndef WM_H
#define WM_H
#include "gfx.h"
#include "input.h"
enum {APP_TERM=0,APP_FILES,APP_EDIT,APP_PAINT,APP_TASKS,APP_BROWSER,APP_TETRIS,APP_SNAKE,APP_MINES,APP_BREAKOUT,APP_GAMES,APP_ARCADE,NAPPS};
typedef struct {
    int x,y,w,h,open,drag,ox,oy;
    u8 app; char title[48];
    int max,sx,sy,sw,sh;        /* maximize: saved geometry */
    int resizable,minw,minh;
} Window;
extern Window win[NAPPS];
extern int active,start_menu,zorder[NAPPS];
extern int ui_dirty;                 /* set by apps when something changed */
/* palette */
#define C_TEXT   rgb(218,226,244)
#define C_DIM    rgb(125,142,170)
#define C_ACC    rgb(80,200,240)
#define C_GREEN  rgb(100,255,160)
#define C_RED    rgb(255,110,120)
#define C_YEL    rgb(255,214,110)
#define C_PANEL  rgb(10,15,28)
#define C_BG0    rgb(4,7,15)
#define C_FIELD  rgb(14,21,36)
#define C_LINE   rgb(34,43,65)
static inline int inside(int x,int y,int w,int h,int px,int py){return px>=x&&px<x+w&&py>=y&&py<y+h;}
void wm_init(void);
void redraw(void);
void titlebar(Window *w);
void window_bg(Window *w);
void raise_window(int id);
void open_app(int id);
int top_at(int x,int y);
void toggle_max(int id);
void taskbar_draw(void);
int taskbar_click(void);                 /* returns 1 if consumed */
int start_menu_click(void);              /* returns 1 if consumed */
void cursor_draw(void);
void cursor_move_fast(void);
void do_reboot(void);
/* ---- apps ---- */
#define CONTENT_X(w) ((w)->x+10)
#define CONTENT_Y(w) ((w)->y+34)
#define CONTENT_W(w) ((w)->w-20)
#define CONTENT_H(w) ((w)->h-44)
u16 term_cwd(void);
void term_init(void);   void term_draw(Window *w);   void term_key(Key *k);   void term_click(Window *w);   void term_tick(u32 now); void term_wheel(int dz);
void term_line(const char *s);
void term_printf(int color,const char *fmt,...);
void term_run_boot(void);
void files_init(void);  void files_draw(Window *w);  void files_key(Key *k);   void files_click(Window *w);  void files_wheel(int dz);
void editor_init(void); void editor_draw(Window *w); void editor_key(Key *k);  void editor_click(Window *w);  void editor_wheel(int dz);
int editor_open_file(u16 dir,const char *name);
void editor_new(void);
void paint_init(void);  void paint_draw(Window *w);  void paint_click(Window *w);  void paint_drag(Window *w);
void sys_draw(Window *w); void sys_click(Window *w);
void browser_init(void); void browser_draw(Window *w); void browser_key(Key *k); void browser_click(Window *w); void browser_drag(Window *w);
void browser_wheel(int dz); void browser_tick(u32 now); void browser_open_url(const char *url); void browser_home(void); void browser_resized(Window *w);
int browser_busy(void);
/* games (legacy) */
void games_init(void);
int games_tick(u32 now);
int games_key(Key *k);
void games_click(int id,Window *w);
void draw_tetris(Window*); void draw_snake(Window*); void draw_mines(Window*); void draw_breakout(Window*); void draw_games(Window*); void draw_arcade(Window*);
/* usb (legacy) */
void usb_scan(void); int usb_mount_fat32(void); int fat32_dir(void); void usb_status(void);
#endif
