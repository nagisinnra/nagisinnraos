#include "fat12.h"
/* Small read/write FAT12 driver working on a RAM disk (512-byte sectors). */
int fs_ok;u32 fs_gen;
static u8 *img;
static u32 bps,spc,res,nfats,rootent,fatsz,totsec,fat_lba,root_lba,root_secs,data_lba,nclus;
static u8 *fat;
static inline u32 rd16(const u8*p){return p[0]|(p[1]<<8);}
static inline u32 rd32(const u8*p){return p[0]|(p[1]<<8)|((u32)p[2]<<16)|((u32)p[3]<<24);}
static inline void wr16(u8*p,u32 v){p[0]=(u8)v;p[1]=(u8)(v>>8);}
static inline void wr32(u8*p,u32 v){p[0]=(u8)v;p[1]=(u8)(v>>8);p[2]=(u8)(v>>16);p[3]=(u8)(v>>24);}

int fs_init(u8 *base){
    img=base;fs_ok=0;
    if(rd16(img+11)!=512)return 0;
    bps=rd16(img+11);spc=img[13];res=rd16(img+14);nfats=img[16];rootent=rd16(img+17);
    totsec=rd16(img+19);if(!totsec)totsec=rd32(img+32);fatsz=rd16(img+22);
    if(!spc||!nfats||!fatsz||!rootent||bps!=512)return 0;
    fat_lba=res;root_lba=res+nfats*fatsz;root_secs=(rootent*32+511)/512;data_lba=root_lba+root_secs;
    nclus=(totsec-data_lba)/spc;
    if(nclus>=4085)return 0;
    fat=img+fat_lba*512;fs_ok=1;return 1;
}
static u16 fat_get(u16 c){u32 o=c+(c>>1);u32 v=fat[o]|(fat[o+1]<<8);return (u16)((c&1)?v>>4:v&0xFFF);}
static void fat_set1(u8*f,u16 c,u16 val){
    u32 o=c+(c>>1);
    if(c&1){f[o]=(u8)((f[o]&0x0F)|((val&0x0F)<<4));f[o+1]=(u8)(val>>4);}
    else{f[o]=(u8)val;f[o+1]=(u8)((f[o+1]&0xF0)|((val>>8)&0x0F));}
}
static void fat_set(u16 c,u16 val){for(u32 i=0;i<nfats;i++)fat_set1(img+(fat_lba+i*fatsz)*512,c,val);}
static u8 *cl_ptr(u16 c){return img+(data_lba+(u32)(c-2)*spc)*512;}
static u32 cl_bytes(void){return spc*512;}
static u16 alloc_cluster(void){
    for(u16 c=2;c<nclus+2;c++)if(fat_get(c)==0){fat_set(c,0xFFF);memset(cl_ptr(c),0,cl_bytes());return c;}
    return 0;
}
static void free_chain(u16 c){
    int guard=0;
    while(c>=2&&c<0xFF8&&guard++<5000){u16 n=fat_get(c);fat_set(c,0);c=n;}
}
u32 fs_free_bytes(void){u32 n=0;for(u16 c=2;c<nclus+2;c++)if(fat_get(c)==0)n++;return n*cl_bytes();}
u32 fs_total_bytes(void){return nclus*cl_bytes();}

/* ---- directory access ---- */
static u8 *dir_ptr(u16 dir,int idx,int grow){
    if(dir==0)return ((u32)idx<rootent)?img+root_lba*512+(u32)idx*32:NULL;
    int per=(int)(cl_bytes()/32);int n=idx/per;u16 c=dir;
    for(int i=0;i<n;i++){
        u16 nx=fat_get(c);
        if(nx<2||nx>=0xFF8){
            if(!grow)return NULL;
            u16 nc=alloc_cluster();if(!nc)return NULL;
            fat_set(c,nc);nx=nc;
        }
        c=nx;
    }
    return cl_ptr(c)+(idx%per)*32;
}
static int to83(const char *n,char o[11]){
    memset(o,' ',11);
    int i=0,j=0,ext=0;
    if(!*n)return 0;
    if(!strcmp(n,".")||!strcmp(n,"..")){for(;n[i];i++)o[i]=n[i];return 1;}
    for(;n[i];i++){
        char c=n[i];
        if(c=='.'){ if(ext||j==0)return 0; ext=1;j=8;continue; }
        if(c<=' '||c=='"'||c=='*'||c=='+'||c==','||c=='/'||c==':'||c==';'||c=='<'||c=='='||c=='>'||c=='?'||c=='\\'||c=='['||c==']'||c=='|')return 0;
        c=(char)ktoupper(c);
        if(!ext){ if(j>=8)return 0; o[j++]=c; }
        else { if(j>=11)return 0; o[j++]=c; }
    }
    return 1;
}
static void from83(const u8 *e,char *o){
    int k=0;
    for(int i=0;i<8&&e[i]!=' ';i++)o[k++]=(char)e[i];
    if(e[8]!=' '){o[k++]='.';for(int i=8;i<11&&e[i]!=' ';i++)o[k++]=(char)e[i];}
    o[k]=0;
}
static void fill_ent(FsEnt *f,const u8 *e,u16 dir,int idx){
    from83(e,f->name);f->attr=e[11];f->size=rd32(e+28);f->cluster=(u16)rd16(e+26);
    f->time=(u16)rd16(e+22);f->date=(u16)rd16(e+24);f->dir=dir;f->idx=idx;
}
int fs_list(u16 dir,FsEnt *out,int max){
    int n=0;
    for(int i=0;n<max;i++){
        u8 *e=dir_ptr(dir,i,0);if(!e||e[0]==0)break;
        if(e[0]==0xE5||(e[11]&0x0F)==0x0F||(e[11]&0x08))continue;
        if(e[0]=='.')continue;
        fill_ent(&out[n++],e,dir,i);
    }
    return n;
}
int fs_find(u16 dir,const char *name,FsEnt *f){
    char k[11];if(!to83(name,k))return 0;
    for(int i=0;;i++){
        u8 *e=dir_ptr(dir,i,0);if(!e||e[0]==0)return 0;
        if(e[0]==0xE5||(e[11]&0x0F)==0x0F||(e[11]&0x08))continue;
        if(!memcmp(e,k,11)){if(f)fill_ent(f,e,dir,i);return 1;}
    }
}
int fs_read(const FsEnt *f,u8 *buf,int cap){
    u32 left=f->size;int n=0;u16 c=f->cluster;int guard=0;
    while(left&&c>=2&&c<0xFF8&&n<cap&&guard++<5000){
        u32 take=left<cl_bytes()?left:cl_bytes();
        if(n+(int)take>cap)take=(u32)(cap-n);
        memcpy(buf+n,cl_ptr(c),take);n+=(int)take;left-=take;c=fat_get(c);
    }
    return n;
}
static void stamp(u8 *e,int create){
    int y,mo,d,h,mi,s;rtc_read(&y,&mo,&d,&h,&mi,&s);
    u32 date=(u32)((y-1980)<<9)|(u32)(mo<<5)|(u32)d,time=(u32)(h<<11)|(u32)(mi<<5)|(u32)(s/2);
    if(create){wr16(e+14,time);wr16(e+16,date);}
    wr16(e+18,date);wr16(e+22,time);wr16(e+24,date);
}
static u8 *new_entry(u16 dir,int *idxout){
    for(int i=0;;i++){
        u8 *e=dir_ptr(dir,i,0);
        if(!e){ if(dir==0)return NULL; e=dir_ptr(dir,i,1); if(!e)return NULL; }
        if(e[0]==0||e[0]==0xE5){*idxout=i;return e;}
    }
}
int fs_write(u16 dir,const char *name,const u8 *data,u32 len){
    char k[11];if(!to83(name,k)||k[0]=='.')return FSE_NAME;
    FsEnt old;int exists=fs_find(dir,name,&old);
    if(exists&&(old.attr&ATTR_DIR))return FSE_ISDIR;
    u32 need=(len+cl_bytes()-1)/cl_bytes();
    u32 avail=fs_free_bytes()/cl_bytes();
    if(exists){u32 oc=0;u16 c=old.cluster;int g=0;while(c>=2&&c<0xFF8&&g++<5000){oc++;c=fat_get(c);}avail+=oc;}
    if(need>avail)return FSE_FULL;
    u8 *e;int idx;
    if(exists){e=dir_ptr(dir,old.idx,0);free_chain(old.cluster);}
    else{e=new_entry(dir,&idx);if(!e)return FSE_DIRFULL;memset(e,0,32);memcpy(e,k,11);e[11]=0x20;stamp(e,1);}
    u16 first=0,prev=0;u32 off=0;
    for(u32 i=0;i<need;i++){
        u16 c=alloc_cluster();
        if(!c){ /* should not happen: checked above */ break; }
        if(!first)first=c;else fat_set(prev,c);
        prev=c;
        u32 take=len-off;if(take>cl_bytes())take=cl_bytes();
        memcpy(cl_ptr(c),data+off,take);off+=take;
    }
    wr16(e+26,first);wr32(e+28,len);stamp(e,0);fs_gen++;
    return 0;
}
int fs_mkdir(u16 dir,const char *name){
    char k[11];if(!to83(name,k)||k[0]=='.')return FSE_NAME;
    if(fs_find(dir,name,NULL))return FSE_EXISTS;
    int idx;u8 *e=new_entry(dir,&idx);if(!e)return FSE_DIRFULL;
    u16 c=alloc_cluster();if(!c)return FSE_FULL;
    memset(e,0,32);memcpy(e,k,11);e[11]=ATTR_DIR;wr16(e+26,c);stamp(e,1);
    u8 *d=cl_ptr(c);
    memset(d,' ',11);d[0]='.';d[11]=ATTR_DIR;wr16(d+26,c);stamp(d,1);
    memset(d+32,' ',11);d[32]='.';d[33]='.';d[32+11]=ATTR_DIR;wr16(d+32+26,dir);stamp(d+32,1);fs_gen++;
    return 0;
}
int fs_delete(u16 dir,const char *name){
    FsEnt f;if(!fs_find(dir,name,&f))return FSE_NOTFOUND;
    if(f.attr&ATTR_DIR){
        for(int i=0;;i++){
            u8 *e=dir_ptr(f.cluster,i,0);if(!e||e[0]==0)break;
            if(e[0]==0xE5||e[0]=='.')continue;
            if((e[11]&0x0F)==0x0F)continue;
            return FSE_NOTEMPTY;
        }
    }
    free_chain(f.cluster);
    u8 *e=dir_ptr(dir,f.idx,0);e[0]=0xE5;fs_gen++;
    return 0;
}
int fs_rename(u16 dir,const char *oldn,const char *newn){
    char k[11];if(!to83(newn,k)||k[0]=='.')return FSE_NAME;
    FsEnt f;if(!fs_find(dir,oldn,&f))return FSE_NOTFOUND;
    if(fs_find(dir,newn,NULL))return FSE_EXISTS;
    memcpy(dir_ptr(dir,f.idx,0),k,11);fs_gen++;
    return 0;
}
/* ---- paths ---- */
static int dir_parent(u16 dir,u16 *par){
    if(dir==0){*par=0;return 1;}
    u8 *e=dir_ptr(dir,1,0);if(!e||e[0]!='.'||e[1]!='.')return 0;
    *par=(u16)rd16(e+26);return 1;
}
int fs_resolve(const char *path,u16 cwd,u16 *dirout,char *leaf){
    u16 dir=cwd;leaf[0]=0;
    const char *p=path;
    if(*p=='\\'||*p=='/'){dir=0;while(*p=='\\'||*p=='/')p++;}
    for(;;){
        char comp[16];int n=0;
        while(*p&&*p!='\\'&&*p!='/'){if(n<15)comp[n++]=*p;p++;}
        comp[n]=0;
        int more=0;while(*p=='\\'||*p=='/'){p++;more=1;}
        if(!comp[0]){ if(!more||!*p)break; continue; }
        if(!*p&&!more){scpy(leaf,comp,13);break;}
        /* intermediate (or trailing-slash) component: must be a directory */
        if(!strcmp(comp,".")){}
        else if(!strcmp(comp,"..")){u16 pr;if(!dir_parent(dir,&pr))return FSE_NOTFOUND;dir=pr;}
        else{FsEnt f;if(!fs_find(dir,comp,&f)||!(f.attr&ATTR_DIR))return FSE_NOTFOUND;dir=f.cluster;}
        if(!*p)break;
    }
    /* a leaf of "." or ".." is treated as a directory path */
    if(!strcmp(leaf,".")){leaf[0]=0;}
    else if(!strcmp(leaf,"..")){u16 pr;if(!dir_parent(dir,&pr))return FSE_NOTFOUND;dir=pr;leaf[0]=0;}
    *dirout=dir;return 0;
}
int fs_chdir(const char *path,u16 cwd,u16 *out){
    u16 d;char leaf[16];
    int r=fs_resolve(path,cwd,&d,leaf);if(r)return r;
    if(leaf[0]){FsEnt f;if(!fs_find(d,leaf,&f)||!(f.attr&ATTR_DIR))return FSE_NOTFOUND;d=f.cluster;}
    *out=d;return 0;
}
void fs_path(u16 dir,char *out,int cap){
    char tmp[128];int tl=0;tmp[0]=0;
    int guard=0;
    while(dir!=0&&guard++<16){
        u16 par;if(!dir_parent(dir,&par))break;
        char nm[13]="?";
        for(int i=0;;i++){
            u8 *e=dir_ptr(par,i,0);if(!e||e[0]==0)break;
            if(e[0]==0xE5||(e[11]&0x0F)==0x0F)continue;
            if((u16)rd16(e+26)==dir&&(e[11]&ATTR_DIR)&&e[0]!='.'){from83(e,nm);break;}
        }
        char t2[128];ksnprintf(t2,sizeof t2,"\\%s%s",nm,tmp);scpy(tmp,t2,sizeof tmp);tl=(int)strlen(tmp);dir=par;
    }
    (void)tl;
    if(!tmp[0])scpy(out,"\\",cap);else scpy(out,tmp,cap);
}
const char *fs_errstr(int e){
    switch(e){case FSE_NAME:return "invalid file name";case FSE_FULL:return "disk full";case FSE_DIRFULL:return "directory full";
    case FSE_ISDIR:return "is a directory";case FSE_NOTEMPTY:return "directory not empty";case FSE_EXISTS:return "already exists";
    case FSE_NOTFOUND:return "not found";}
    return "error";
}
