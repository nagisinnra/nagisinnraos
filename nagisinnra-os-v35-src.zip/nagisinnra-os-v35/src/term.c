#include "wm.h"
#include "fat12.h"
/* Terminal: scrollback, history, completion, async jobs (ping/wget/curl/nslookup/dhcp). */
#define TL_MAX 400
#define TL_LEN 200
#define VRMAX 500
static char tl[TL_MAX][TL_LEN];static u16 tl_col[TL_MAX];static int tl_cnt;
static char in[160];static int in_n,in_cur;
static char hist[16][160];static int hist_n,hist_i=-1;
static int scroll;static u16 cwd;
u16 term_cwd(void){return cwd;}

static void push_line(u16 c,const char *s){
    char *d=tl[tl_cnt%TL_MAX];scpy(d,s,TL_LEN);tl_col[tl_cnt%TL_MAX]=c;tl_cnt++;scroll=0;ui_dirty=1;
}
void term_line(const char *s){push_line(C_TEXT,s);}
void term_printf(int color,const char *fmt,...){
    char b[400];va_list ap;va_start(ap,fmt);kvsnprintf(b,sizeof b,fmt,ap);va_end(ap);
    char *p=b;
    for(;;){char *nl=strchr(p,'\n');if(nl)*nl=0;push_line((u16)color,p);if(!nl)break;p=nl+1;if(!*p)break;}
}
#define OUT(fmt,...) term_printf(C_TEXT,fmt,##__VA_ARGS__)
#define ERR(fmt,...) term_printf(C_RED,fmt,##__VA_ARGS__)
#define INF(fmt,...) term_printf(C_ACC,fmt,##__VA_ARGS__)
#define OK(fmt,...) term_printf(C_GREEN,fmt,##__VA_ARGS__)

/* ---------------- jobs ---------------- */
enum {J_NONE,J_PING,J_WGET,J_CURL,J_NSLOOKUP,J_DHCP};
static struct {
    int type;u32 t0,last;int step;char host[80];u32 ip;int count,sent,recv,seq;u32 rtt_min,rtt_max,rtt_sum;
    char url[300];char fname[16];u16 dir;Http http;u8 *buf;int cap,pages;int shown;
} job;
static void job_end(void){
    if(job.buf){mem_free_pages(job.buf,(u32)job.pages);job.buf=NULL;}
    job.type=J_NONE;ui_dirty=1;
}
static int job_alloc(int pages){
    job.buf=mem_alloc_pages((u32)pages);
    if(!job.buf){ERR("out of memory");job.type=J_NONE;return 0;}
    job.pages=pages;job.cap=pages*4096;return 1;
}
static void name_from_url(const char *path,char *out){
    const char *s=path;const char *last=path;
    for(;*s&&*s!='?';s++)if(*s=='/')last=s+1;
    char base[16],ext[8];int bi=0,ei=0,dot=0;
    for(const char *p=last;*p&&*p!='?'&&*p!='#';p++){
        char c=(char)ktoupper(*p);
        if(c=='.'){ if(dot)break; dot=1; continue; }
        if(!((c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'))continue;
        if(!dot){if(bi<8)base[bi++]=c;}else{if(ei<3)ext[ei++]=c;}
    }
    base[bi]=0;ext[ei]=0;
    if(!bi){scpy(base,"INDEX",sizeof base);if(!ei)scpy(ext,"HTM",sizeof ext);}
    if(ei)ksnprintf(out,16,"%s.%s",base,ext);else scpy(out,base,16);
}
static void job_start_http(int type,const char *url,const char *fname){
    char host[80],path[300];u16 port;
    int r=url_split(url,host,sizeof host,&port,path,sizeof path);
    if(r==-1){ERR("%s",http_errstr(HE_HTTPS));return;}
    if(r!=1){ERR("bad URL: %s",url);return;}
    memset(&job,0,sizeof job);job.type=type;
    if(!job_alloc(type==J_WGET?96:64))return;
    scpy(job.url,url,sizeof job.url);job.dir=cwd;
    if(fname&&fname[0])scpy(job.fname,fname,sizeof job.fname);else name_from_url(path,job.fname);
    job.t0=ms_now();
    http_get(&job.http,host,port,path,job.buf,job.cap);
    INF("Connecting to %s ...",host);
}
static void sapp(char *d,int cap,const char *s){int l=(int)strlen(d);if(l<cap-1)scpy(d+l,s,cap-l);}
static void print_text_body(const u8 *b,int n,int maxlines){
    char line[TL_LEN];int j=0,lines=0;
    for(int i=0;i<n;i++){
        u8 c=b[i];
        if(c=='\r')continue;
        if(c=='\n'){line[j]=0;OUT("%s",line);j=0;if(++lines>=maxlines){INF("... (truncated)");return;}continue;}
        if(c=='\t')c=' ';
        if(c<32)c='.';
        if(j<TL_LEN-2)line[j++]=(char)c;
    }
    if(j){line[j]=0;OUT("%s",line);}
}
static void job_step(u32 now){
    switch(job.type){
    case J_PING:{
        if(job.step==0){
            u32 ip;int r=dns_poll(&ip);
            if(r<0){ERR("ping: cannot resolve %s",job.host);job_end();return;}
            if(r==1){job.ip=ip;char s[16];ip_str(ip,s);INF("PING %s (%s): 40 data bytes",job.host,s);job.step=1;job.last=now-2000;}
            return;
        }
        u32 from;int seq;u32 rtt;
        if(ping_poll(&from,&seq,&rtt)&&seq==job.seq){
            char s[16];ip_str(from,s);OK("Reply from %s: seq=%d time=%d ms",s,seq,(int)rtt);
            job.recv++;job.rtt_sum+=rtt;if(!job.rtt_min||rtt<job.rtt_min)job.rtt_min=rtt;if(rtt>job.rtt_max)job.rtt_max=rtt;
            job.last=now-900;job.step=2;       /* send next after ~1 s */
        }
        if(job.step==1&&now-job.last>2000&&job.seq>0){ERR("Request timed out: seq=%d",job.seq);job.step=2;job.last=now-1000;}
        if(job.step==1&&job.seq==0)job.step=2;
        if(job.step==2&&now-job.last>=1000){
            if(job.sent>=job.count){
                INF("--- %s ping statistics ---",job.host);
                OUT("%d packets transmitted, %d received, %d%% loss",job.sent,job.recv,job.sent?100*(job.sent-job.recv)/job.sent:0);
                if(job.recv)OUT("rtt min/avg/max = %d/%d/%d ms",(int)job.rtt_min,(int)(job.rtt_sum/(u32)job.recv),(int)job.rtt_max);
                job_end();return;
            }
            job.seq=++job.sent;ping_send(job.ip,job.seq);job.last=now;job.step=1;
        }
        return;
    }
    case J_NSLOOKUP:{
        u32 ip;int r=dns_poll(&ip);
        if(r<0){ERR("nslookup: %s: not found",job.host);job_end();}
        else if(r==1){char s[16],d[16];ip_str(ip,s);ip_str(net_dns,d);OUT("Server:  %s",d);OK("Name:    %s",job.host);OK("Address: %s",s);job_end();}
        return;
    }
    case J_DHCP:{
        if(net_state!=NET_DHCP){
            char a[16],g[16],d[16],m[16];ip_str(net_ip,a);ip_str(net_gw,g);ip_str(net_dns,d);ip_str(net_mask,m);
            if(net_state==NET_UP_DHCP)OK("DHCP: address %s mask %s",a,m);else ERR("DHCP: no server answered, using fallback %s",a);
            OUT("gateway %s  dns %s",g,d);job_end();
        }
        return;
    }
    case J_WGET:case J_CURL:{
        Http *h=&job.http;http_poll(h);
        if(h->state==HTTP_ERROR){ERR("failed: %s",http_errstr(h->err));job_end();return;}
        if(job.shown<1&&(h->state==HTTP_HEADERS||h->state==HTTP_BODY)){job.shown=1;INF("connected, sending request");}
        if(job.shown<2&&h->state==HTTP_BODY){job.shown=2;OUT("HTTP %d  %s  %s",h->status,h->ctype[0]?h->ctype:"(no type)",h->content_length>=0?"":"(length unknown)");}
        if(h->state==HTTP_DONE){
            if(h->status>=300&&h->status<400&&h->location[0]&&h->redirects<5){
                char host[80],path[300];u16 port;
                if(!strncmp(h->location,"http://",7)&&url_split(h->location,host,sizeof host,&port,path,sizeof path)==1){
                    INF("redirect -> %s",h->location);int rd=h->redirects+1;
                    http_get(h,host,port,path,job.buf,job.cap);h->redirects=rd;return;
                }
                if(!strncmp(h->location,"https://",8)){ERR("redirected to %s (https not supported)",h->location);job_end();return;}
                if(h->location[0]=='/'){ char host2[80];u16 p2;char pp[300];url_split(job.url,host2,sizeof host2,&p2,pp,sizeof pp);
                    INF("redirect -> %s",h->location);int rd=h->redirects+1;http_get(h,host2,p2,h->location,job.buf,job.cap);h->redirects=rd;return; }
            }
            if(job.type==J_WGET){
                int e=fs_write(job.dir,job.fname,job.buf,(u32)h->len);
                if(e)ERR("cannot save %s: %s",job.fname,fs_errstr(e));
                else term_printf(h->status<400?C_GREEN:C_YEL,"HTTP %d: saved %s (%d bytes)%s%s",h->status,job.fname,h->len,h->truncated?"  [TRUNCATED at buffer limit]":"",h->status>=400?"  (server returned an error page)":"");
            } else {
                OUT("HTTP %d  %d bytes",h->status,h->len);
                print_text_body(job.buf,h->len,200);
            }
            job_end();
        }
        return;
    }
    }
}
void term_tick(u32 now){
    static int last_net=-1;
    if(net_state!=last_net){
        if(last_net>=0||net_state>=NET_UP_DHCP){
            if(net_state>=NET_UP_DHCP&&!(job.type==J_DHCP)){char a[16],g[16];ip_str(net_ip,a);ip_str(net_gw,g);
                if(net_state==NET_UP_DHCP)OK("Network up (DHCP): %s  gw %s",a,g);else ERR("No DHCP server; fallback address %s  gw %s",a,g);}
        }
        last_net=net_state;
    }
    if(job.type)job_step(now);
}

/* ---------------- file helpers ---------------- */
static u8 *load_file(const char *path,u32 *size,u32 *pages,FsEnt *fe){
    u16 d;char leaf[16];FsEnt e;
    if(fs_resolve(path,cwd,&d,leaf)||!leaf[0]||!fs_find(d,leaf,&e))return NULL;
    if(e.attr&ATTR_DIR)return NULL;
    u32 pg=(e.size+4095)/4096;if(!pg)pg=1;
    u8 *b=mem_alloc_pages(pg);if(!b)return NULL;
    fs_read(&e,b,(int)(pg*4096));*size=e.size;*pages=pg;if(fe)*fe=e;return b;
}
static void print_date(u16 date,u16 time,char *o){
    if(!date){scpy(o,"                ",17);return;}
    ksnprintf(o,24,"%d-%02d-%02d %02d:%02d",1980+(date>>9),(date>>5)&15,date&31,time>>11,(time>>5)&63);
}
static void cmd_dir(const char *arg){
    static FsEnt ents[160];u16 d;
    if(arg&&arg[0]){if(fs_chdir(arg,cwd,&d)){ERR("dir: %s: not found",arg);return;}}else d=cwd;
    char p[128];fs_path(d,p,sizeof p);INF(" Directory of %s",p);
    int n=fs_list(d,ents,160);u32 bytes=0;int files=0,dirs=0;
    if(d!=0)OUT("  ..                <DIR>");
    for(int i=0;i<n;i++){
        char dt[24];print_date(ents[i].date,ents[i].time,dt);
        if(ents[i].attr&ATTR_DIR){dirs++;term_printf(C_YEL,"  %-12s     <DIR>  %s",ents[i].name,dt);}
        else{files++;bytes+=ents[i].size;OUT("  %-12s %9d  %s",ents[i].name,ents[i].size,dt);}
    }
    OUT(" %d file(s) %d bytes, %d dir(s), %d bytes free",files,bytes,dirs,fs_free_bytes());
}
static void cmd_type(const char *arg){
    u32 sz,pg;u8 *b=load_file(arg,&sz,&pg,NULL);
    if(!b){ERR("type: %s: not found",arg);return;}
    if(!sz)OUT("(empty file)");else print_text_body(b,(int)sz>60000?60000:(int)sz,1000);
    mem_free_pages(b,pg);
}
static void cmd_copy(const char *a,const char *bn){
    u32 sz,pg;FsEnt fe;u8 *b=load_file(a,&sz,&pg,&fe);
    if(!b){ERR("copy: %s: not found",a);return;}
    u16 d;char leaf[16];int r=fs_resolve(bn,cwd,&d,leaf);
    if(!r){
        if(!leaf[0])scpy(leaf,fe.name,sizeof leaf);
        else{FsEnt t;if(fs_find(d,leaf,&t)&&(t.attr&ATTR_DIR)){d=t.cluster;scpy(leaf,fe.name,sizeof leaf);}}
        r=fs_write(d,leaf,b,sz);
    }
    if(r)ERR("copy: %s",fs_errstr(r));else OK("copied %s (%d bytes)",leaf,sz);
    mem_free_pages(b,pg);
}
static int com_run(const char *name){
    u32 sz,pg;u8 *b=load_file(name,&sz,&pg,NULL);
    if(!b){ERR("run: %s: not found",name);return 0;}
    if(!sz||sz>65536){ERR("run: bad size");mem_free_pages(b,pg);return 0;}
    OUT("running %s ...",name);
    void(*entry)(void)=(void(*)(void))b;entry();
    mem_free_pages(b,pg);OUT("exit 0");return 1;
}
static void show_ifconfig(void){
    if(net_state==NET_NONE){ERR("no network adapter found");return;}
    char a[16],m[16],g[16],d[16];ip_str(net_ip,a);ip_str(net_mask,m);ip_str(net_gw,g);ip_str(net_dns,d);
    INF("%s",nic_name);
    OUT("  MAC      %02x:%02x:%02x:%02x:%02x:%02x",nic_mac[0],nic_mac[1],nic_mac[2],nic_mac[3],nic_mac[4],nic_mac[5]);
    OUT("  address  %s   netmask %s",a,m);OUT("  gateway  %s   dns     %s",g,d);
    OUT("  state    %s   rx %d  tx %d  drops %d",net_state==NET_UP_DHCP?"up (DHCP)":net_state==NET_UP_STATIC?"up (static/fallback)":net_state==NET_DHCP?"configuring...":"down",nic_rx_frames,nic_tx_frames,nic_rx_drops);
}
static const char *HELP[]={
"Files:    dir [path]  cd path  pwd  type file  copy a b  ren a b  del file",
"          mkdir name  rmdir name  echo text [> file]  edit file  run file",
"Network:  ifconfig [ip mask gw dns]  dhcp  ping host [n]  nslookup host",
"          wget url [file]  curl url  browse [url]",
"System:   ver  mem  date  uptime  cls  usb  mount  udir  reboot",
"Keys:     Tab complete, Up/Down history, PgUp/PgDn scroll, Ctrl+C cancel job",
"          F1 Term F2 Files F3 Edit F4 Paint F5 System F6 Browser F10 Games",0};
static int split(char *s,char **av,int max){
    int n=0;
    while(*s&&n<max){
        while(*s==' ')s++;if(!*s)break;
        if(*s=='"'){av[n++]=++s;while(*s&&*s!='"')s++;if(*s)*s++=0;}
        else{av[n++]=s;while(*s&&*s!=' ')s++;if(*s)*s++=0;}
    }
    return n;
}
static void run_cmd(char *line){
    char *av[10];char tmp[160];scpy(tmp,line,sizeof tmp);
    /* echo redirection */
    char *redir=NULL;int append=0;
    if(!strnicmp(tmp,"echo",4)&&(tmp[4]==' '||!tmp[4])){
        char *g=strchr(tmp,'>');
        if(g){if(g[1]=='>'){append=1;*g++=0;}*g++=0;while(*g==' ')g++;redir=g;}
    }
    int ac=split(tmp,av,10);if(!ac)return;
    const char *c=av[0];
    #define IS(x) (!stricmp(c,x))
    if(IS("help")||IS("?")){for(int i=0;HELP[i];i++)INF("%s",HELP[i]);}
    else if(IS("ver")||IS("about")){OK("NAGISINNRA OS V%s  (i386, 800x600 VBE, FAT12 RAM disk, NE2000 + TCP/IP)",VERSION_STR);}
    else if(IS("cls")||IS("clear")){tl_cnt=0;scroll=0;}
    else if(IS("dir")||IS("ls"))cmd_dir(ac>1?av[1]:NULL);
    else if(IS("pwd")){char p[128];fs_path(cwd,p,sizeof p);OUT("%s",p);}
    else if(IS("cd")||IS("chdir")){
        if(ac<2){char p[128];fs_path(cwd,p,sizeof p);OUT("%s",p);}
        else{u16 d;if(fs_chdir(av[1],cwd,&d))ERR("cd: %s: no such directory",av[1]);else cwd=d;}
    }
    else if(IS("type")||IS("cat")){if(ac<2)ERR("usage: type file");else cmd_type(av[1]);}
    else if(IS("echo")){
        char out[160]="";for(int i=1;i<ac;i++){if(i>1)sapp(out,sizeof out," ");sapp(out,sizeof out,av[i]);}
        if(redir&&*redir){
            u16 d;char leaf[16];
            if(fs_resolve(redir,cwd,&d,leaf)||!leaf[0]){ERR("echo: bad file name");}
            else{
                static u8 buf[2048];int n=0;
                if(append){FsEnt e;if(fs_find(d,leaf,&e)&&e.size<sizeof buf-200)n=fs_read(&e,buf,(int)sizeof buf-200);}
                int l=(int)strlen(out);memcpy(buf+n,out,(u32)l);n+=l;buf[n++]='\n';
                int r=fs_write(d,leaf,buf,(u32)n);if(r)ERR("echo: %s",fs_errstr(r));
            }
        } else OUT("%s",out);
    }
    else if(IS("mkdir")||IS("md")){if(ac<2)ERR("usage: mkdir name");else{u16 d;char leaf[16];int r=fs_resolve(av[1],cwd,&d,leaf);if(!r)r=leaf[0]?fs_mkdir(d,leaf):FSE_NAME;if(r)ERR("mkdir: %s",fs_errstr(r));}}
    else if(IS("rmdir")||IS("rd")||IS("del")||IS("rm")||IS("erase")){
        if(ac<2)ERR("usage: del name");
        else{u16 d;char leaf[16];int r=fs_resolve(av[1],cwd,&d,leaf);if(!r)r=leaf[0]?fs_delete(d,leaf):FSE_NAME;if(r)ERR("%s: %s: %s",c,av[1],fs_errstr(r));}
    }
    else if(IS("ren")||IS("rename")||IS("mv")){
        if(ac<3)ERR("usage: ren old new");
        else{u16 d;char leaf[16];int r=fs_resolve(av[1],cwd,&d,leaf);if(!r)r=leaf[0]?fs_rename(d,leaf,av[2]):FSE_NAME;if(r)ERR("ren: %s",fs_errstr(r));}
    }
    else if(IS("copy")||IS("cp")){if(ac<3)ERR("usage: copy src dst");else cmd_copy(av[1],av[2]);}
    else if(IS("edit")||IS("nano")||IS("notepad")){
        if(ac<2){editor_new();open_app(APP_EDIT);}
        else{u16 d;char leaf[16];if(fs_resolve(av[1],cwd,&d,leaf)||!leaf[0])ERR("edit: bad path");else{if(!editor_open_file(d,leaf))editor_new();open_app(APP_EDIT);}}
    }
    else if(IS("run")){if(ac<2)ERR("usage: run file.com");else com_run(av[1]);}
    else if(IS("mem")){
        OUT("RAM pages: %d KB total, %d KB free (page allocator)",(int)mem_total_pages_count()*4,(int)mem_free_pages_count()*4);
        OUT("RAM disk: %d KB total, %d KB free",(int)(fs_total_bytes()/1024),(int)(fs_free_bytes()/1024));
    }
    else if(IS("date")||IS("time")){int y,mo,d,h,mi,s;rtc_read(&y,&mo,&d,&h,&mi,&s);OUT("%d-%02d-%02d %02d:%02d:%02d",y,mo,d,h,mi,s);}
    else if(IS("uptime")){u32 s=ms_now()/1000;OUT("up %d min %d s",(int)(s/60),(int)(s%60));}
    else if(IS("ifconfig")||IS("ipconfig")||IS("ip")){
        if(ac>=5){u32 a,m,g,d;if(ip_parse(av[1],&a)&&ip_parse(av[2],&m)&&ip_parse(av[3],&g)&&ip_parse(av[4],&d)){if(net_state==NET_NONE)ERR("no network adapter");else{net_set_static(a,m,g,d);OK("static configuration applied");}}else ERR("usage: ifconfig ip mask gw dns");}
        else show_ifconfig();
    }
    else if(IS("dhcp")){if(net_state==NET_NONE)ERR("no network adapter");else{net_dhcp_start();memset(&job,0,sizeof job);job.type=J_DHCP;INF("requesting address via DHCP ...");}}
    else if(IS("ping")){
        if(ac<2){ERR("usage: ping host [count]");return;}
        if(net_state<NET_UP_DHCP){ERR("network is not up (see ifconfig)");return;}
        memset(&job,0,sizeof job);job.type=J_PING;scpy(job.host,av[1],sizeof job.host);job.count=ac>2?katoi(av[2]):4;if(job.count<1)job.count=1;if(job.count>50)job.count=50;
        if(!dns_start(av[1])){ERR("ping: cannot resolve %s",av[1]);job.type=J_NONE;}
    }
    else if(IS("nslookup")||IS("dig")||IS("host")){
        if(ac<2){ERR("usage: nslookup host");return;}
        if(net_state<NET_UP_DHCP){ERR("network is not up");return;}
        memset(&job,0,sizeof job);job.type=J_NSLOOKUP;scpy(job.host,av[1],sizeof job.host);
        if(!dns_start(av[1])){ERR("nslookup: cannot resolve %s",av[1]);job.type=J_NONE;}
    }
    else if(IS("wget")){if(ac<2)ERR("usage: wget url [file]");else job_start_http(J_WGET,av[1],ac>2?av[2]:NULL);}
    else if(IS("curl")){if(ac<2)ERR("usage: curl url");else job_start_http(J_CURL,av[1],NULL);}
    else if(IS("browse")||IS("web")||IS("www")){open_app(APP_BROWSER);if(ac>1)browser_open_url(av[1]);}
    else if(IS("usb"))usb_scan();
    else if(IS("mount")||IS("fat32")){if(usb_mount_fat32())OK("D: mount ok");else ERR("D: mount failed");}
    else if(IS("udir"))fat32_dir();
    else if(!stricmp(c,"d:"))usb_status();
    else if(IS("reboot")||IS("restart")){OUT("rebooting...");redraw();do_reboot();}
    else if(IS("shutdown")||IS("poweroff")||IS("halt")){OUT("It is now safe to close this window / turn off the power.");outw(0x604,0x2000);outw(0xB004,0x2000);}
    else ERR("%s: command not found (try help)",c);
    #undef IS
}

/* ---------------- completion / editing ---------------- */
static void complete(void){
    int e=in_cur,s=e;while(s>0&&in[s-1]!=' ')s--;
    char tok[100];int tn=e-s;if(tn>=(int)sizeof tok)return;memcpy(tok,in+s,(u32)tn);tok[tn]=0;
    int sp=-1;for(int i=0;i<tn;i++)if(tok[i]=='\\'||tok[i]=='/')sp=i;
    char dirpart[100];int dl=sp+1;memcpy(dirpart,tok,(u32)dl);dirpart[dl]=0;
    const char *pfx=tok+dl;u16 d=cwd;
    if(dl){char dp[100];scpy(dp,dirpart,sizeof dp);if(dl>1)dp[dl-1]=0;if(fs_chdir(dl==1?"\\":dp,cwd,&d))return;}
    static FsEnt ents[160];int n=fs_list(d,ents,160);
    int hits=0,pl=(int)strlen(pfx);char first[16];char common[16];common[0]=0;
    for(int i=0;i<n;i++)if(!strnicmp(ents[i].name,pfx,(u32)pl)){
        if(!hits){scpy(common,ents[i].name,sizeof common);scpy(first,ents[i].name,sizeof first);}
        else{int k=0;while(common[k]&&ktoupper(common[k])==ktoupper(ents[i].name[k]))k++;common[k]=0;}
        hits++;
    }
    if(!hits)return;
    if(hits>1){char line[160]="";for(int i=0;i<n;i++)if(!strnicmp(ents[i].name,pfx,(u32)pl)){sapp(line,sizeof line,ents[i].name);sapp(line,sizeof line,"  ");}push_line(C_DIM,line);}
    char add[40];scpy(add,common+pl,sizeof add);
    if(hits==1){FsEnt f;if(fs_find(d,first,&f)&&(f.attr&ATTR_DIR))sapp(add,sizeof add,"\\");else sapp(add,sizeof add," ");}
    int al=(int)strlen(add);
    if(in_n+al<(int)sizeof in-1){memmove(in+in_cur+al,in+in_cur,(u32)(in_n-in_cur+1));memcpy(in+in_cur,add,(u32)al);in_n+=al;in_cur+=al;}
}
void term_key(Key *k){
    ui_dirty=1;
    if((k->mods&MOD_CTRL)&&k->sc==0x2E){ if(job.type){http_cancel(&job.http);ERR("^C");job_end();}else{in[0]=0;in_n=in_cur=0;} return; }  /* Ctrl+C */
    if((k->mods&MOD_CTRL)&&k->sc==0x26){tl_cnt=0;return;}                                /* Ctrl+L */
    if((k->mods&MOD_CTRL)&&k->sc==0x16){in[0]=0;in_n=in_cur=0;return;}                   /* Ctrl+U */
    if((k->mods&MOD_CTRL)&&k->sc==0x1E){in_cur=0;return;}
    if((k->mods&MOD_CTRL)&&k->sc==0x12){in_cur=in_n;return;}
    if(k->sc==K_PGUP){scroll+=8;return;} if(k->sc==K_PGDN){scroll-=8;if(scroll<0)scroll=0;return;}
    if(job.type)return;
    if(k->sc==K_LEFT){if(in_cur>0)in_cur--;return;} if(k->sc==K_RIGHT){if(in_cur<in_n)in_cur++;return;}
    if(k->sc==K_HOME){in_cur=0;return;} if(k->sc==K_END){in_cur=in_n;return;}
    if(k->sc==K_UP){ if(hist_n){ if(hist_i<0)hist_i=hist_n; if(hist_i>0){hist_i--;scpy(in,hist[hist_i%16],sizeof in);in_n=in_cur=(int)strlen(in);} } return; }
    if(k->sc==K_DOWN){ if(hist_i>=0){hist_i++; if(hist_i>=hist_n){hist_i=-1;in[0]=0;in_n=in_cur=0;}else{scpy(in,hist[hist_i%16],sizeof in);in_n=in_cur=(int)strlen(in);}} return; }
    if(k->sc==K_DEL){if(in_cur<in_n){memmove(in+in_cur,in+in_cur+1,(u32)(in_n-in_cur));in_n--;}return;}
    if(k->sc==K_TAB){complete();return;}
    if(k->ch==8){if(in_cur>0){memmove(in+in_cur-1,in+in_cur,(u32)(in_n-in_cur+1));in_cur--;in_n--;}return;}
    if(k->ch=='\n'){
        char p[128];fs_path(cwd,p,sizeof p);
        term_printf(C_GREEN,"%s> %s",p,in);
        if(in_n){ if(!(hist_n&&!strcmp(hist[(hist_n-1)%16],in))){scpy(hist[hist_n%16],in,sizeof hist[0]);hist_n++;} }
        hist_i=-1;char line[160];scpy(line,in,sizeof line);in[0]=0;in_n=in_cur=0;
        run_cmd(line);return;
    }
    if(k->ch>=32&&k->ch<127&&in_n<(int)sizeof in-2){memmove(in+in_cur+1,in+in_cur,(u32)(in_n-in_cur+1));in[in_cur++]=(char)k->ch;in_n++;}
}
void term_wheel(int dz){scroll-=dz*3;if(scroll<0)scroll=0;ui_dirty=1;}
void term_click(Window *w){(void)w;}

/* ---------------- drawing ---------------- */
typedef struct{int line,start,len;}VR;
static VR vr[VRMAX];
static int wrap_line(const char *s,int maxpx,int *starts,int maxn){
    int n=0,x=0;starts[n++]=0;const char *p=s;
    while(*p){const char *q=p;u32 cp=utf8_next(&q);int cw=cp_width(cp);
        if(x+cw>maxpx&&x>0){if(n<maxn)starts[n++]=(int)(p-s);x=0;}
        x+=cw;p=q;}
    return n;
}
void term_draw(Window *w){
    int x0=CONTENT_X(w)+4,y0=CONTENT_Y(w)+4,cw=CONTENT_W(w)-8,ch=CONTENT_H(w)-8;
    int rows=ch/16;if(rows<2)return;int outrows=rows-1;
    set_clip(CONTENT_X(w),CONTENT_Y(w),CONTENT_W(w),CONTENT_H(w));
    int need=outrows+scroll;if(need>VRMAX)need=VRMAX;
    int n=0;
    for(int li=tl_cnt-1;li>=0&&li>=tl_cnt-TL_MAX&&n<need;li--){
        const char *s=tl[li%TL_MAX];int st[40];int pc=wrap_line(s,cw,st,40);
        for(int p=pc-1;p>=0&&n<VRMAX;p--){vr[n].line=li;vr[n].start=st[p];vr[n].len=(p+1<pc?st[p+1]:(int)strlen(s))-st[p];n++;}
    }
    int maxscroll=n>outrows?n-outrows:0;if(scroll>maxscroll)scroll=maxscroll;
    int off=(n<outrows)?outrows-n:0;          /* short output: start at the top like a real terminal */
    for(int r=0;r<outrows;r++){
        int idx=scroll+r;if(idx>=n)break;
        int y=y0+(outrows-1-r-off)*16;const char *s=tl[vr[idx].line%TL_MAX];
        text16n(x0,y,s+vr[idx].start,vr[idx].len,tl_col[vr[idx].line%TL_MAX],0);
    }
    int py=y0+(outrows-off)*16;
    if(scroll>0){text16(x0+cw-80,py-16,"[scrolled]",C_DIM);}
    if(job.type){text16(x0,py,"[running - Ctrl+C to cancel]",C_YEL);}
    else{
        char p[128],pr[160];fs_path(cwd,p,sizeof p);ksnprintf(pr,sizeof pr,"%s> ",p);
        int pw=text16(x0,py,pr,C_GREEN);
        /* horizontal window onto the input line */
        int maxw=cw-pw;int cx=text16w(in+0)>0?0:0;(void)cx;
        int off=0;{char tmp[160];scpy(tmp,in,sizeof tmp);tmp[in_cur]=0;while(text16w(tmp+off)>maxw-8)off++;}
        text16(x0+pw,py,in+off,C_TEXT);
        char tmp[160];scpy(tmp,in,sizeof tmp);tmp[in_cur]=0;
        int cxp=x0+pw+text16w(tmp+off);
        if((ms_now()/500)&1)fill(cxp,py+1,8,14,C_ACC);else fill(cxp,py+14,8,2,C_ACC);
    }
    clip_reset();
}
void term_init(void){tl_cnt=0;in[0]=0;in_n=in_cur=0;cwd=0;scroll=0;memset(&job,0,sizeof job);}
void term_run_boot(void){
    OK("NAGISINNRA OS V%s",VERSION_STR);
    OUT("800x600 high-color | FAT12 RAM disk %d KB | RAM %d MB managed",(int)(fs_total_bytes()/1024),(int)(mem_total_pages_count()*4/1024));
    if(net_state==NET_NONE)ERR("Network: no NE2000 adapter found");
    else INF("Network: %s  MAC %02x:%02x:%02x:%02x:%02x:%02x",nic_name,nic_mac[0],nic_mac[1],nic_mac[2],nic_mac[3],nic_mac[4],nic_mac[5]);
    OUT("Type 'help' for commands. Try:  wget http://example.com   or open the Browser (F6).");
}
