#include "wm.h"
#include "fat12.h"
#include "html.h"
/* Web browser: async HTTP -> HTML layout -> scrollable text view with links. */
#define RAWPAGES 64
#define RAWCAP (RAWPAGES*4096)
static u8 *raw;static int raw_len;
static Page pg;static int mem_ok,started;
static Http http;static int loading,redirects;
static char cur_url[300],req_url[300];
static char urlb[300];static int url_n,url_cur,url_focus,url_sel;
static int scroll,sb_drag,pending_scroll,need_relayout,page_is_html,page_cs,view_src,cols_now;
static char status[140];
typedef struct{char url[300];int scroll;}Hist;
static Hist hist[16];static int hist_n,hist_pos=-1;
static u32 last_prog;

static const char HOME_HTML[]=
"<html><head><title>NAGISINNRA Browser</title></head><body>"
"<h1>NAGISINNRA OS ブラウザ</h1>"
"<p>HTTPで接続して、ページをテキスト表示します。上のアドレス欄にURLを入力してEnterを押してください。<br>"
"This browser speaks plain <b>http://</b> only (no TLS). Sites that force https cannot be opened.</p>"
"<h2>Try these (plain HTTP)</h2>"
"<ul>"
"<li><a href=\"http://example.com/\">example.com</a> - the classic example page</li>"
"<li><a href=\"http://neverssl.com/\">neverssl.com</a> - always-HTTP test page</li>"
"<li><a href=\"http://info.cern.ch/\">info.cern.ch</a> - the first website</li>"
"<li><a href=\"http://httpforever.com/\">httpforever.com</a> - HTTP test site</li>"
"<li><a href=\"http://frogfind.com/\">frogfind.com</a> - search engine for simple browsers</li>"
"</ul>"
"<h2>Local</h2>"
"<ul><li><a href=\"file:README.TXT\">README.TXT</a></li><li><a href=\"file:DOCS/WELCOME.HTM\">DOCS/WELCOME.HTM</a> (local HTML demo)</li></ul>"
"<h2>Keys</h2>"
"<pre>Ctrl+L  address bar     Ctrl+R  reload\n"
"Alt+Left / Alt+Right  back / forward\n"
"PgUp PgDn Home End  scroll   (mouse wheel works too)\n"
"Ctrl+U  view source     Esc  stop loading</pre>"
"</body></html>";

static void setstatus(const char *fmt,...){va_list ap;va_start(ap,fmt);kvsnprintf(status,sizeof status,fmt,ap);va_end(ap);ui_dirty=1;}
static int alloc_all(void){
    if(mem_ok)return 1;
    raw=mem_alloc_pages(RAWPAGES);
    pg.ccap=120000;pg.cp=mem_alloc_pages((pg.ccap*2+4095)/4096);pg.lk=mem_alloc_pages((pg.ccap*2+4095)/4096);pg.st=mem_alloc_pages((pg.ccap+4095)/4096);
    pg.lcap=6000;pg.ls=mem_alloc_pages((pg.lcap*4+4095)/4096);pg.ll=mem_alloc_pages((pg.lcap*2+4095)/4096);
    pg.pool_cap=65536;pg.pool=mem_alloc_pages(16);pg.lkcap=3000;pg.lkoff=mem_alloc_pages((pg.lkcap*4+4095)/4096);
    mem_ok=raw&&pg.cp&&pg.lk&&pg.st&&pg.ls&&pg.ll&&pg.pool&&pg.lkoff;
    page_reset(&pg);return mem_ok;
}
void browser_init(void){started=0;loading=0;hist_n=0;hist_pos=-1;url_n=0;urlb[0]=0;scroll=0;}
static void geom(Window *w,int *vx,int *vy,int *vw,int *vh){
    *vx=w->x+10;*vy=w->y+68;*vw=w->w-20-14;*vh=w->h-68-6-18-4;
}
static void relayout(Window *w){
    if(!mem_ok)return;
    int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);cols_now=vw/8;
    if(loading){need_relayout=1;return;}
    page_layout(&pg,raw,raw_len,cols_now,page_is_html&&!view_src,page_cs);
    if(pg.title[0]&&page_is_html&&!view_src){char t[48];ksnprintf(t,sizeof t,"Browser - %s",pg.title);scpy(win[APP_BROWSER].title,t,sizeof win[APP_BROWSER].title);}
    int maxs=(int)pg.nlines-vh/16;if(maxs<0)maxs=0;if(scroll>maxs)scroll=maxs;
    need_relayout=0;ui_dirty=1;
}
void browser_resized(Window *w){relayout(w);}
static void set_page(const u8 *src,int n,int is_html,const char *ctype){
    if(n>RAWCAP-1)n=RAWCAP-1;
    if(src!=raw)memcpy(raw,src,(u32)n);
    raw[n]=0;raw_len=n;page_is_html=is_html;page_cs=html_charset(raw,n,ctype);view_src=0;
    relayout(&win[APP_BROWSER]);
}
static void show_html(const char *html,const char *title){
    (void)title;set_page((const u8*)html,(int)strlen(html),1,NULL);
}
static void show_error(const char *head,const char *detail,const char *url){
    char b[900];
    ksnprintf(b,sizeof b,"<html><head><title>%s</title></head><body><h2>%s</h2><p>%s</p><p>URL: %s</p><hr><p><a href=\"nagisinnra://home\">Home</a></p></body></html>",head,head,detail,url);
    scroll=0;set_page((const u8*)b,(int)strlen(b),1,NULL);
}
/* ---- URL handling ---- */
static void norm_input(const char *in,char *out,int cap){
    while(*in==' ')in++;
    if(!strnicmp(in,"http://",7)||!strnicmp(in,"https://",8)||!strnicmp(in,"file:",5)||!strnicmp(in,"nagisinnra:",11)||!strnicmp(in,"about:",6)||strstr(in,"://")){scpy(out,in,cap);}
    else ksnprintf(out,cap,"http://%s",in);
    int l=(int)strlen(out);while(l>0&&out[l-1]==' ')out[--l]=0;
}
static void resolve(const char *base,const char *ref,char *out,int cap){
    if(!strnicmp(ref,"http://",7)||!strnicmp(ref,"https://",8)||!strnicmp(ref,"nagisinnra:",11)||!strnicmp(ref,"file:",5)||!strnicmp(ref,"about:",6)||!strnicmp(ref,"mailto:",7)||!strnicmp(ref,"javascript:",11)||!strnicmp(ref,"ftp:",4)){scpy(out,ref,cap);return;}
    char origin[200]="",path[300]="/";
    int isfile=!strnicmp(base,"file:",5);
    if(isfile){
        scpy(origin,"file:",sizeof origin);scpy(path,base+5,sizeof path);
    } else {
        const char *p=strstr(base,"://");
        if(!p){scpy(out,ref,cap);return;}
        p+=3;const char *sl=strchr(p,'/');
        int ol=sl?(int)(sl-base):(int)strlen(base);
        if(ol>(int)sizeof origin-1)ol=(int)sizeof origin-1;memcpy(origin,base,(u32)ol);origin[ol]=0;
        scpy(path,sl?sl:"/",sizeof path);
    }
    char *q=strchr(path,'#');if(q)*q=0;
    if(ref[0]=='#'||!ref[0]){ksnprintf(out,cap,"%s%s",origin,path);return;}
    if(ref[0]=='/'&&ref[1]=='/'){ksnprintf(out,cap,"http:%s",ref);return;}
    char np[400];
    if(ref[0]=='/')scpy(np,ref,sizeof np);
    else if(ref[0]=='?'){char *qq=strchr(path,'?');if(qq)*qq=0;ksnprintf(np,sizeof np,"%s%s",path,ref);}
    else{
        char *qq=strchr(path,'?');if(qq)*qq=0;
        char *ls=path;for(char *s=path;*s;s++)if(*s=='/'||*s=='\\')ls=s;
        int dl=(int)(ls-path)+((*ls=='/'||*ls=='\\')?1:0);if(isfile&&dl==0){}
        if(dl>(int)sizeof np-2)dl=(int)sizeof np-2;memcpy(np,path,(u32)dl);np[dl]=0;
        scpy(np+dl,ref,(int)sizeof np-dl);
    }
    /* normalise dot segments (path part only) */
    char qs[300];qs[0]=0;char *qm=strchr(np,'?');if(qm){scpy(qs,qm,sizeof qs);*qm=0;}
    char res[400];int rl=0;const char *s=np;
    while(*s){
        if(*s=='/'){ if(rl==0||res[rl-1]!='/')res[rl++]='/'; s++; }
        char seg[100];int sn=0;while(*s&&*s!='/'&&sn<99)seg[sn++]=*s++;seg[sn]=0;
        if(!strcmp(seg,".")||!seg[0])continue;
        if(!strcmp(seg,"..")){ if(rl>1){rl--;while(rl>0&&res[rl-1]!='/')rl--;} continue; }
        if(rl+sn+1<(int)sizeof res){memcpy(res+rl,seg,(u32)sn);rl+=sn;}
        if(*s=='/'&&rl+1<(int)sizeof res&&res[rl-1]!='/'){res[rl++]='/';s++;}
    }
    if(!rl)res[rl++]='/';res[rl]=0;
    ksnprintf(out,cap,"%s%s%s",origin,res,qs);
}
static void hist_push(const char *u){
    if(hist_pos>=0)hist[hist_pos].scroll=scroll;
    hist_pos++;hist_n=hist_pos+1;
    if(hist_pos>=16){memmove(&hist[0],&hist[1],sizeof(Hist)*15);hist_pos=15;hist_n=16;}
    scpy(hist[hist_pos].url,u,sizeof hist[0].url);hist[hist_pos].scroll=0;
}
static void do_fetch(const char *u){
    char host[80],path[300];u16 port;
    int r=url_split(u,host,sizeof host,&port,path,sizeof path);
    if(r==-1){loading=0;show_error("HTTPS is not supported","This browser has no TLS, so https:// pages cannot be opened. Try the http:// version of the site, or a site that serves plain HTTP.",u);setstatus("https not supported");return;}
    if(r!=1){loading=0;show_error("Bad address","The address could not be understood.",u);return;}
    scpy(req_url,u,sizeof req_url);loading=1;last_prog=ms_now();
    http_get(&http,host,port,path,raw,RAWCAP);
    setstatus("Looking up %s ...",host);
}
static void go(const char *input,int push){
    if(!alloc_all()){setstatus("Out of memory");return;}
    char u[300];norm_input(input,u,sizeof u);
    if(loading){http_cancel(&http);loading=0;}
    redirects=0;
    if(push)hist_push(u);
    scpy(cur_url,u,sizeof cur_url);scpy(urlb,u,sizeof urlb);url_n=(int)strlen(urlb);url_cur=url_n;url_sel=0;
    scroll=push?0:pending_scroll;pending_scroll=0;
    scpy(win[APP_BROWSER].title,"Browser",sizeof win[APP_BROWSER].title);
    if(!strnicmp(u,"nagisinnra:",11)||!strnicmp(u,"about:",6)){show_html(HOME_HTML,"home");setstatus("Home");return;}
    if(!strnicmp(u,"file:",5)){
        const char *p=u+5;
        u16 d;char leaf[16];FsEnt e;
        if(fs_resolve(p,term_cwd(),&d,leaf)||!leaf[0]||!fs_find(d,leaf,&e)||(e.attr&ATTR_DIR)){show_error("File not found","No such local file.",u);return;}
        u32 n=e.size>(u32)RAWCAP-1?(u32)RAWCAP-1:e.size;
        fs_read(&e,raw,(int)n);raw[n]=0;
        int ish=(stristr(e.name,".HTM")!=NULL);
        raw_len=(int)n;page_is_html=ish;page_cs=html_charset(raw,(int)n,NULL);view_src=0;relayout(&win[APP_BROWSER]);
        setstatus("%s - %d bytes",e.name,(int)n);return;
    }
    if(!strnicmp(u,"mailto:",7)||!strnicmp(u,"javascript:",11)||!strnicmp(u,"ftp:",4)){setstatus("Unsupported link type");return;}
    do_fetch(u);
}
void browser_open_url(const char *u){started=1;go(u,1);ui_dirty=1;}
void browser_home(void){if(!started){started=1;go("nagisinnra://home",1);}}
int browser_busy(void){return loading;}
static void back(void){ if(hist_pos>0){hist[hist_pos].scroll=scroll;hist_pos--;pending_scroll=hist[hist_pos].scroll;go(hist[hist_pos].url,0);} }
static void forward(void){ if(hist_pos+1<hist_n){hist[hist_pos].scroll=scroll;hist_pos++;pending_scroll=hist[hist_pos].scroll;go(hist[hist_pos].url,0);} }
static void reload(void){ pending_scroll=scroll;go(cur_url,0); }

static void make_dl_name(const char *path,char *out){
    const char *last=path;for(const char *s=path;*s&&*s!='?';s++)if(*s=='/')last=s+1;
    char b[10],e[5];int bi=0,ei=0,dot=0;
    for(const char *p=last;*p&&*p!='?'&&*p!='#';p++){
        char c=(char)ktoupper(*p);
        if(c=='.'){dot=1;ei=0;continue;}
        if(!((c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'))continue;
        if(!dot){if(bi<8)b[bi++]=c;}else if(ei<3)e[ei++]=c;
    }
    b[bi]=0;e[ei]=0;if(!bi)scpy(b,"DOWNLOAD",sizeof b);
    if(ei)ksnprintf(out,16,"%s.%s",b,e);else scpy(out,b,16);
}
static int looks_html(const u8 *b,int n){
    int m=n<512?n:512;
    for(int i=0;i+4<m;i++){
        if(b[i]=='<'&&(!strnicmp((const char*)b+i,"<html",5)||!strnicmp((const char*)b+i,"<!doc",5)||!strnicmp((const char*)b+i,"<head",5)||!strnicmp((const char*)b+i,"<body",5)||!strnicmp((const char*)b+i,"<p>",3)||!strnicmp((const char*)b+i,"<h1",3)||!strnicmp((const char*)b+i,"<a ",3)||!strnicmp((const char*)b+i,"<div",4)||!strnicmp((const char*)b+i,"<title",6)))return 1;
    }
    return 0;
}
static void fetch_done(void){
    Http *h=&http;
    if(h->status>=300&&h->status<400&&h->location[0]){
        if(++redirects>6){loading=0;show_error("Too many redirects","The server redirected too many times.",req_url);return;}
        char nu[300];resolve(req_url,h->location,nu,sizeof nu);
        scpy(cur_url,nu,sizeof cur_url);scpy(urlb,nu,sizeof urlb);url_n=(int)strlen(urlb);url_cur=url_n;
        setstatus("Redirect -> %s",nu);do_fetch(nu);return;
    }
    loading=0;
    const char *ct=h->ctype;
    int html=!strnicmp(ct,"text/html",9)||stristr(ct,"xhtml")||(!ct[0]&&looks_html(raw,h->len));
    int text=html||!strnicmp(ct,"text/",5)||stristr(ct,"json")||stristr(ct,"xml")||stristr(ct,"javascript")||(!ct[0]&&!looks_html(raw,h->len));
    if(h->status>=400&&!html){char d[120];ksnprintf(d,sizeof d,"The server answered with status %d.",h->status);show_error("Request failed",d,req_url);return;}
    if(text){
        scpy(cur_url,req_url,sizeof cur_url);scpy(urlb,req_url,sizeof urlb);url_n=(int)strlen(urlb);url_cur=url_n;
        page_is_html=html;page_cs=html_charset(raw,h->len,ct);raw_len=h->len;raw[h->len]=0;view_src=0;
        scroll=pending_scroll;pending_scroll=0;relayout(&win[APP_BROWSER]);
        setstatus("Done: %d bytes, %d lines%s%s",h->len,(int)pg.nlines,h->truncated?" (truncated)":"",pg.truncated?" (page too large, cut)":"");
        return;
    }
    /* binary: save to \DOWNLOAD */
    char host[80],path[300];u16 port;url_split(req_url,host,sizeof host,&port,path,sizeof path);
    char fn[16];make_dl_name(path,fn);
    FsEnt de;u16 dd=0;int r;
    if(!fs_find(0,"DOWNLOAD",&de)){r=fs_mkdir(0,"DOWNLOAD");if(r){show_error("Cannot save file",fs_errstr(r),req_url);return;}fs_find(0,"DOWNLOAD",&de);}
    dd=de.cluster;
    r=fs_write(dd,fn,raw,(u32)h->len);
    char b[700];
    if(r)ksnprintf(b,sizeof b,"<html><body><h2>Download failed</h2><p>%s (%s, %d bytes)</p></body></html>",fs_errstr(r),ct,h->len);
    else ksnprintf(b,sizeof b,"<html><head><title>Downloaded</title></head><body><h2>File downloaded</h2><p>Saved as <b>\\DOWNLOAD\\%s</b> (%d bytes, type %s).%s</p><p><a href=\"nagisinnra://home\">Home</a></p></body></html>",fn,h->len,ct[0]?ct:"unknown",h->truncated?" The file was larger than the 256 KB buffer and was cut.":"");
    scroll=0;set_page((const u8*)b,(int)strlen(b),1,NULL);
    scpy(cur_url,req_url,sizeof cur_url);setstatus(r?"Download failed":"Saved %s",fn);
}
void browser_tick(u32 now){
    if(!loading)return;
    http_poll(&http);
    if(http.state==HTTP_ERROR){loading=0;show_error("Cannot open page",http_errstr(http.err),req_url);setstatus("Error: %s",http_errstr(http.err));return;}
    if(http.state==HTTP_DONE){fetch_done();ui_dirty=1;return;}
    if(now-last_prog>150){
        last_prog=now;
        switch(http.state){
        case HTTP_WAITNET:setstatus("Waiting for network configuration (DHCP) ...");break;
        case HTTP_DNS:setstatus("Looking up %s ...",http.host);break;
        case HTTP_CONNECT:setstatus("Connecting to %s ...",http.host);break;
        case HTTP_HEADERS:setstatus("Waiting for response from %s ...",http.host);break;
        case HTTP_BODY:setstatus("Receiving %d bytes ...",http.len);break;
        default:break;}
    }
}
/* ---- drawing ---- */
static int line_x_hit(int line,int px,int vx,int *lk){
    u32 s=pg.ls[line],n=pg.ll[line];int x=vx;
    for(u32 i=0;i<n;i++){int cw=cp_width(pg.cp[s+i]);if(px>=x&&px<x+cw){*lk=pg.lk[s+i];return 1;}x+=cw;}
    *lk=0;return 0;
}
static int hover_link(Window *w){
    if(!mem_ok||!raw_len)return 0;
    int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);
    if(!inside(vx,vy,vw,vh,mx,my))return 0;
    int line=scroll+(my-vy)/16;if(line<0||line>=(int)pg.nlines)return 0;
    int lk;line_x_hit(line,mx,vx,&lk);return lk;
}
static void button(int x,int y,int w,int h,const char *label,int enabled){
    int hv=enabled&&inside(x,y,w,h,mx,my);
    roundrect(x,y,w,h,5,hv?rgb(30,48,76):rgb(14,22,38));
    int tw=text16w(label);text16(x+(w-tw)/2,y+(h-16)/2,label,enabled?C_TEXT:rgb(70,82,105));
}
void browser_draw(Window *w){
    int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);
    int ty=w->y+36;
    button(w->x+10,ty,26,26,"\xE2\x86\x90",hist_pos>0);
    button(w->x+40,ty,26,26,"\xE2\x86\x92",hist_pos+1<hist_n);
    button(w->x+70,ty,26,26,loading?"x":"R",1);
    button(w->x+100,ty,26,26,"H",1);
    int ux=w->x+132,uw=w->w-132-10-40;
    roundrect(ux,ty,uw,26,5,url_focus?rgb(20,34,58):C_FIELD);
    if(url_focus)frame_rect(ux,ty,uw,26,C_ACC);
    set_clip(ux+4,ty,uw-8,26);
    {
        int tw=text16w(urlb);int tx=ux+8;
        char pre[300];scpy(pre,urlb,sizeof pre);pre[url_cur]=0;int cpx=text16w(pre);
        int shift=0;if(cpx>uw-24)shift=cpx-(uw-24);
        if(url_focus&&url_sel&&url_n)fill(tx,ty+4,tw,18,rgb(40,90,150));
        text16(tx-shift,ty+5,urlb,C_TEXT);
        if(url_focus&&!url_sel&&((ms_now()/500)&1))fill(tx-shift+cpx,ty+4,2,18,C_ACC);
    }
    set_clip(w->x-2,w->y-2,w->w+4,w->h+4);
    button(w->x+w->w-10-34,ty,34,26,"Go",1);
    /* viewport */
    fill(vx,vy,vw,vh,rgb(8,12,22));
    set_clip(vx,vy,vw,vh);
    int hl=hover_link(w);
    if(mem_ok&&raw_len){
        int rows=vh/16+1;
        for(int r=0;r<rows;r++){
            int line=scroll+r;if(line>=(int)pg.nlines)break;
            u32 s=pg.ls[line],n=pg.ll[line];int x=vx,y=vy+r*16;
            for(u32 i=0;i<n;i++){
                u16 cp=pg.cp[s+i];u8 st=pg.st[s+i];u16 lk=pg.lk[s+i];
                u16 col=C_TEXT;int fl=0;
                if(st&ST_CODE)col=rgb(190,235,190);
                if(st&ST_DIM)col=C_DIM;
                if(st&ST_HEAD)col=C_YEL;
                if(st&ST_BOLD)fl|=TF_BOLD;
                if(lk&&(st&ST_LINK)){col=(hl&&hl==lk)?rgb(170,220,255):rgb(100,175,255);fl|=TF_UL;}
                x+=draw_cp(x,y,cp,col,fl);
            }
        }
    } else text16(vx+8,vy+8,loading?"Loading ...":"(no page)",C_DIM);
    clip_reset();set_clip(w->x-2,w->y-2,w->w+4,w->h+4);
    /* scrollbar */
    int sx=vx+vw+2;fill(sx,vy,10,vh,rgb(12,18,32));
    if(mem_ok&&raw_len&&(int)pg.nlines*16>vh){
        int total=(int)pg.nlines*16;int th=vh*vh/total;if(th<18)th=18;
        int range=vh-th;int maxs=(int)pg.nlines-vh/16;int ty2=maxs>0?vy+range*scroll/maxs:vy;
        roundrect(sx,ty2,10,th,4,sb_drag?rgb(90,150,220):rgb(50,80,120));
    }
    /* status */
    int sy=w->y+w->h-6-18;
    fill(w->x+10,sy,w->w-20,18,rgb(8,12,22));
    const char *msg=status;char hb[300];
    if(hl){const char *l=page_link(&pg,hl);if(l){resolve(cur_url,l,hb,sizeof hb);msg=hb;}}
    set_clip(w->x+12,sy,w->w-24,18);
    text16(w->x+14,sy+1,msg,hl?rgb(150,210,255):(loading?C_YEL:C_DIM));
    clip_reset();
}
/* ---- input ---- */
static void focus_url(void){url_focus=1;url_sel=1;url_cur=url_n;ui_dirty=1;}
static void set_scroll(Window *w,int v){
    int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);
    int maxs=(int)pg.nlines-vh/16;if(maxs<0)maxs=0;if(v<0)v=0;if(v>maxs)v=maxs;scroll=v;ui_dirty=1;
}
static void sb_set_from_mouse(Window *w){
    int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);
    int total=(int)pg.nlines*16;if(total<=vh)return;
    int th=vh*vh/total;if(th<18)th=18;int range=vh-th;if(range<=0)return;
    int maxs=(int)pg.nlines-vh/16;int pos=my-vy-th/2;
    set_scroll(w,pos*maxs/range);
}
void browser_click(Window *w){
    int ty=w->y+36;int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);
    if(inside(w->x+10,ty,26,26,mx,my)){back();return;}
    if(inside(w->x+40,ty,26,26,mx,my)){forward();return;}
    if(inside(w->x+70,ty,26,26,mx,my)){if(loading){http_cancel(&http);loading=0;setstatus("Stopped");}else reload();return;}
    if(inside(w->x+100,ty,26,26,mx,my)){go("nagisinnra://home",1);url_focus=0;return;}
    int ux=w->x+132,uw=w->w-132-10-40;
    if(inside(ux,ty,uw,26,mx,my)){focus_url();return;}
    if(inside(w->x+w->w-10-34,ty,34,26,mx,my)){url_focus=0;if(urlb[0])go(urlb,1);return;}
    url_focus=0;
    if(inside(vx+vw,vy,14,vh,mx,my)){sb_drag=1;sb_set_from_mouse(w);return;}
    int hl=hover_link(w);
    if(hl){const char *l=page_link(&pg,hl);if(l){char nu[300];resolve(cur_url,l,nu,sizeof nu);go(nu,1);}}
}
void browser_drag(Window *w){ if(sb_drag){ if(mbuttons&1)sb_set_from_mouse(w); else sb_drag=0; } }
void browser_wheel(int dz){set_scroll(&win[APP_BROWSER],scroll+dz*3);}
void browser_key(Key *k){
    Window *w=&win[APP_BROWSER];int vx,vy,vw,vh;geom(w,&vx,&vy,&vw,&vh);int page=vh/16-1;
    ui_dirty=1;
    if((k->mods&MOD_CTRL)){
        if(k->sc==0x26){focus_url();return;}           /* Ctrl+L */
        if(k->sc==0x13){reload();return;}               /* Ctrl+R */
        if(k->sc==0x16){ if(mem_ok&&raw_len&&!loading){view_src=!view_src;scroll=0;relayout(w);} return; } /* Ctrl+U */
        if(k->sc==0x1E&&url_focus){url_sel=1;url_cur=url_n;return;}
    }
    if((k->mods&MOD_ALT)){ if(k->sc==K_LEFT){back();return;} if(k->sc==K_RIGHT){forward();return;} }
    if(url_focus){
        if(k->sc==K_ESC){url_focus=0;scpy(urlb,cur_url,sizeof urlb);url_n=(int)strlen(urlb);return;}
        if(k->ch=='\n'){url_focus=0;if(urlb[0])go(urlb,1);return;}
        if(k->sc==K_LEFT){url_sel=0;if(url_cur>0)url_cur--;return;} if(k->sc==K_RIGHT){url_sel=0;if(url_cur<url_n)url_cur++;return;}
        if(k->sc==K_HOME){url_sel=0;url_cur=0;return;} if(k->sc==K_END){url_sel=0;url_cur=url_n;return;}
        if(k->sc==K_DEL){ if(url_sel){urlb[0]=0;url_n=url_cur=0;url_sel=0;} else if(url_cur<url_n){memmove(urlb+url_cur,urlb+url_cur+1,(u32)(url_n-url_cur));url_n--;} return; }
        if(k->ch==8){ if(url_sel){urlb[0]=0;url_n=url_cur=0;url_sel=0;} else if(url_cur>0){memmove(urlb+url_cur-1,urlb+url_cur,(u32)(url_n-url_cur+1));url_cur--;url_n--;} return; }
        if(k->ch>=32&&k->ch<127){
            if(url_sel){urlb[0]=0;url_n=url_cur=0;url_sel=0;}
            if(url_n<(int)sizeof urlb-2){memmove(urlb+url_cur+1,urlb+url_cur,(u32)(url_n-url_cur+1));urlb[url_cur++]=(char)k->ch;url_n++;}
        }
        return;
    }
    if(k->sc==K_ESC){if(loading){http_cancel(&http);loading=0;setstatus("Stopped");}return;}
    if(k->sc==K_DOWN)set_scroll(w,scroll+1);else if(k->sc==K_UP)set_scroll(w,scroll-1);
    else if(k->sc==K_PGDN||k->ch==' ')set_scroll(w,scroll+page);else if(k->sc==K_PGUP)set_scroll(w,scroll-page);
    else if(k->sc==K_HOME)set_scroll(w,0);else if(k->sc==K_END)set_scroll(w,100000);
    else if(k->ch==8)back();
    else if(k->ch=='/'||k->ch=='g'){focus_url();}
}
