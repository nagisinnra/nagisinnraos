#include "gfx.h"
#include "font5.h"
extern const unsigned char font_ascii[][16],font_lat1[][16],font_ext_g[][16],font_hk[][16],font_jp_g[][32];
extern const unsigned short font_ext_c[],font_jp_c[];
extern const int font_ext_n,font_jp_n;
u16 *drawbuf=BACKBUF;
u32 fb_phys=0xE0000000u,fb_pitch=SW*2;
static int cx0=0,cy0=0,cx1=SW,cy1=SH;

void gfx_init(void){
    u8 *mi=(u8*)0x90000;
    fb_phys=mi[0x28]|((u32)mi[0x29]<<8)|((u32)mi[0x2a]<<16)|((u32)mi[0x2b]<<24);
    fb_pitch=mi[0x10]|((u32)mi[0x11]<<8);
    if(!fb_phys||fb_pitch<SW*2){fb_phys=0xE0000000u;fb_pitch=SW*2;}
}
void set_clip(int x,int y,int w,int h){
    cx0=x<0?0:x;cy0=y<0?0:y;cx1=x+w>SW?SW:x+w;cy1=y+h>SH?SH:y+h;
}
void clip_reset(void){cx0=0;cy0=0;cx1=SW;cy1=SH;}
static inline void rowfill(u16 *d,int n,u16 c){
    u32 c32=(u32)c|((u32)c<<16);
    if(((u32)d&2)&&n>0){*d++=c;n--;}
    int n2=n>>1;
    __asm__ volatile("cld; rep stosl":"+D"(d),"+c"(n2):"a"(c32):"memory");
    if(n&1)*d=c;
}
void fill(int x,int y,int w,int h,u16 c){
    int x1=x+w,y1=y+h;
    if(x<cx0)x=cx0;if(y<cy0)y=cy0;if(x1>cx1)x1=cx1;if(y1>cy1)y1=cy1;
    if(x>=x1||y>=y1)return;
    int n=x1-x;
    for(int yy=y;yy<y1;yy++)rowfill(drawbuf+yy*SW+x,n,c);
}
void putp(int x,int y,u16 c){if(x>=cx0&&x<cx1&&y>=cy0&&y<cy1)drawbuf[y*SW+x]=c;}
void frame_rect(int x,int y,int w,int h,u16 c){fill(x,y,w,1,c);fill(x,y+h-1,w,1,c);fill(x,y,1,h,c);fill(x+w-1,y,1,h,c);}
void roundrect(int x,int y,int w,int h,int r,u16 c){
    if(r<1){fill(x,y,w,h,c);return;}
    if(r*2>w)r=w/2;if(r*2>h)r=h/2;
    fill(x+r,y,w-2*r,h,c);fill(x,y+r,r,h-2*r,c);fill(x+w-r,y+r,r,h-2*r,c);
    for(int yy=0;yy<r;yy++)for(int xx=0;xx<r;xx++){
        int dx=r-1-xx,dy=r-1-yy;
        if(dx*dx+dy*dy<r*r){putp(x+xx,y+yy,c);putp(x+w-1-xx,y+yy,c);putp(x+xx,y+h-1-yy,c);putp(x+w-1-xx,y+h-1-yy,c);}
    }
}
void copy_sky(void){
    u32 n=(u32)SW*SH/2;u32*d=(u32*)BACKBUF;const u32*s=(const u32*)SKYBUF;
    __asm__ volatile("cld; rep movsl":"+D"(d),"+S"(s),"+c"(n)::"memory");
}
void present(void){
    for(int y=0;y<SH;y++){
        u32 *d=(u32*)((u32)fb_phys+(u32)y*fb_pitch);const u32*s=(const u32*)(BACKBUF+y*SW);
        u32 n=SW/2;
        __asm__ volatile("cld; rep movsl":"+D"(d),"+S"(s),"+c"(n)::"memory");
    }
}
/* ---- legacy 5x7 ---- */
static const unsigned char *glyph5(char c){
    if(c>='a'&&c<='z')c=(char)(c-'a'+'A');
    for(unsigned i=0;i<sizeof(font5_chars)-1;i++)if(font5_chars[i]==c)return font5[i];
    return font5[36];
}
void text(int x,int y,const char *s,u16 c,int scale){
    while(*s){
        const unsigned char *g=glyph5(*s++);
        for(int r=0;r<7;r++)for(int b=0;b<5;b++)if(g[r]&(1u<<(4-b)))fill(x+b*scale,y+r*scale,scale,scale,c);
        x+=6*scale;
    }
}
/* ---- UTF-8 ---- */
u32 utf8_next(const char **ps){
    const u8 *s=(const u8*)*ps;u32 c=s[0];
    if(!c)return 0;
    if(c<0x80){*ps+=1;return c;}
    int n=0;u32 cp=0;
    if((c&0xE0)==0xC0){n=1;cp=c&0x1F;}else if((c&0xF0)==0xE0){n=2;cp=c&0x0F;}else if((c&0xF8)==0xF0){n=3;cp=c&0x07;}
    else {*ps+=1;return c;}                       /* stray byte: treat as Latin-1 */
    for(int i=1;i<=n;i++){ if((s[i]&0xC0)!=0x80){*ps+=1;return c;} cp=(cp<<6)|(s[i]&0x3F); }
    *ps+=n+1;
    return cp;
}
int utf8_encode(u32 cp,char *o){
    if(cp<0x80){o[0]=(char)cp;return 1;}
    if(cp<0x800){o[0]=(char)(0xC0|(cp>>6));o[1]=(char)(0x80|(cp&0x3F));return 2;}
    if(cp<0x10000){o[0]=(char)(0xE0|(cp>>12));o[1]=(char)(0x80|((cp>>6)&0x3F));o[2]=(char)(0x80|(cp&0x3F));return 3;}
    o[0]=(char)(0xF0|(cp>>18));o[1]=(char)(0x80|((cp>>12)&0x3F));o[2]=(char)(0x80|((cp>>6)&0x3F));o[3]=(char)(0x80|(cp&0x3F));return 4;
}
static const u8 *glyph16(u32 cp,int *wide){
    *wide=0;
    if(cp>=0x20&&cp<0x7F)return font_ascii[cp-0x20];
    if(cp>=0xA0&&cp<0x100)return font_lat1[cp-0xA0];
    if(cp>=0xFF61&&cp<=0xFF9F)return font_hk[cp-0xFF61];
    for(int i=0;i<font_ext_n;i++)if(font_ext_c[i]==cp)return font_ext_g[i];
    int lo=0,hi=font_jp_n-1;
    while(lo<=hi){int m=(lo+hi)>>1;u32 c=font_jp_c[m];if(c==cp){*wide=1;return font_jp_g[m];}if(c<cp)lo=m+1;else hi=m-1;}
    return NULL;
}
int cp_width(u32 cp){
    if(cp==0x09)return 8;
    int w;if(glyph16(cp,&w))return w?16:8;
    return 8;
}
int draw_cp(int x,int y,u32 cp,u16 fg,int flags){
    int wide;const u8 *g=glyph16(cp,&wide);
    int adv=wide?16:8;
    if(!g){ if(cp>=0x20){ frame_rect(x+1,y+2,6,11,fg);} return 8; }
    if(x>=cx1||x+adv<=cx0||y>=cy1||y+16<=cy0)return adv;
    int w=wide?16:8,inx=(x>=cx0&&x+adv<=cx1);
    for(int r=0;r<16;r++){
        int yy=y+r;if(yy<cy0||yy>=cy1)continue;
        u32 bits=wide?(((u32)g[r*2]<<8)|g[r*2+1]):g[r];
        if(!bits)continue;
        if(flags&TF_BOLD)bits|=bits>>1;
        u16 *row=drawbuf+yy*SW;
        if(inx){
            while(bits){int b;__asm__("bsrl %1,%0":"=r"(b):"r"(bits));bits&=~(1u<<b);row[x+(w-1-b)]=fg;}
        } else {
            for(int b=0;b<w;b++)if(bits&(1u<<(w-1-b))){int xx=x+b;if(xx>=cx0&&xx<cx1)row[xx]=fg;}
        }
    }
    if(flags&TF_UL)fill(x,y+15,adv,1,fg);
    return adv;
}
int text16n(int x,int y,const char *s,int n,u16 fg,int flags){
    int x0=x;const char *e=s+n;
    while(s<e&&*s){u32 cp=utf8_next(&s);x+=draw_cp(x,y,cp,fg,flags);}
    return x-x0;
}
int text16(int x,int y,const char *s,u16 fg){
    int x0=x;
    while(*s){u32 cp=utf8_next(&s);x+=draw_cp(x,y,cp,fg,0);}
    return x-x0;
}
int text16w(const char *s){int w=0;while(*s){u32 cp=utf8_next(&s);w+=cp_width(cp);}return w;}
