#include "gfx.h"
/* IDT for CPU exceptions: shows a panic screen instead of silently triple-faulting. */
typedef struct __attribute__((packed)){u16 lo,sel;u8 zero,type;u16 hi;}Gate;
typedef struct __attribute__((packed)){u16 limit;u32 base;}IdtPtr;
extern u32 exc_table[32];extern void irq_stub(void);
static Gate idt[48];
static const char *names[32]={"divide error","debug","NMI","breakpoint","overflow","bound range","invalid opcode","device not available","double fault","coprocessor overrun","invalid TSS","segment not present","stack fault","general protection","page fault","reserved","x87 FPU","alignment check","machine check","SIMD","virtualization","","","","","","","","","","security",""};
void idt_init(void){
    for(int i=0;i<48;i++){u32 a=i<32?exc_table[i]:(u32)irq_stub;idt[i].lo=(u16)a;idt[i].hi=(u16)(a>>16);idt[i].sel=0x08;idt[i].zero=0;idt[i].type=0x8E;}
    IdtPtr p;p.limit=sizeof idt-1;p.base=(u32)idt;
    __asm__ volatile("lidt %0"::"m"(p));
}
void exc_handler(u32 vec,u32 err,u32 eip){
    drawbuf=(u16*)fb_phys;clip_reset();
    fill(0,0,SW,SH,rgb(120,10,20));
    char b[120];
    text16(40,60,"NAGISINNRA OS - KERNEL PANIC",rgb(255,255,255));
    ksnprintf(b,sizeof b,"Exception #%d: %s",(int)vec,vec<32?names[vec]:"?");text16(40,100,b,rgb(255,230,230));
    ksnprintf(b,sizeof b,"EIP = %08x   error code = %08x",eip,err);text16(40,124,b,rgb(255,230,230));
    text16(40,170,"The system has stopped. Please reset or power-cycle the machine.",rgb(255,200,200));
    dbgf("PANIC #%d eip=%x err=%x\n",(int)vec,eip,err);
    for(;;)__asm__ volatile("hlt");
}
