#ifndef GFX_H
#define GFX_H
#include "nagi.h"
#define SW 800
#define SH 600
#define BACKBUF ((u16*)0x00400000)
#define SKYBUF  ((u16*)0x00500000)
extern u16 *drawbuf;
extern u32 fb_phys,fb_pitch;
static inline u16 rgb(u8 r,u8 g,u8 b){return (u16)(((r>>3)<<11)|((g>>2)<<5)|(b>>3));}
void gfx_init(void);
void present(void);
void set_clip(int x,int y,int w,int h);
void clip_reset(void);
void fill(int x,int y,int w,int h,u16 c);
void putp(int x,int y,u16 c);
void roundrect(int x,int y,int w,int h,int r,u16 c);
void frame_rect(int x,int y,int w,int h,u16 c);
void copy_sky(void);
void draw_sky(void);
/* legacy 5x7 uppercase font used by the game UIs */
void text(int x,int y,const char *s,u16 c,int scale);
/* 8x16 / 16x16 font: ASCII, Latin-1, Japanese */
#define TF_BOLD 1
#define TF_UL 2
u32 utf8_next(const char **s);
int draw_cp(int x,int y,u32 cp,u16 fg,int flags);
int text16(int x,int y,const char *s,u16 fg);
int text16n(int x,int y,const char *s,int n,u16 fg,int flags);
int cp_width(u32 cp);
int text16w(const char *s);
int utf8_encode(u32 cp,char *out);
#endif
