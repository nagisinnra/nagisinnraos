#include "input.h"
#define SW_ 800
#define SH_ 600
int mx=400,my=300,mbuttons,mwheel,mpress,mrelease,mpress_r,mouse_has_wheel;
static int mlast;
static Key kq[64];static int kqh,kqt;
static int shift,ctrl,alt,caps,e0;
static u8 mp[4];static int mpos,mlen=3;

static int wait_in(void){u32 t=ms_now();while(inb(0x64)&2){if(ms_now()-t>30)return 0;}return 1;}
static int rd_timeout(int ms){u32 t=ms_now();while(ms_now()-t<(u32)ms){if(inb(0x64)&1)return inb(0x60);}return -1;}
static int mouse_cmd(u8 c){
    if(!wait_in())return -1;outb(0x64,0xD4);if(!wait_in())return -1;outb(0x60,c);
    return rd_timeout(60);
}
void input_init(void){
    int guard=0;while((inb(0x64)&1)&&guard++<64)(void)inb(0x60);
    if(wait_in())outb(0x64,0xA8);                          /* enable aux port */
    mouse_cmd(0xF6);                                        /* defaults */
    /* IntelliMouse magic knock: 200,100,80 then read ID */
    mouse_cmd(0xF3);mouse_cmd(200);mouse_cmd(0xF3);mouse_cmd(100);mouse_cmd(0xF3);mouse_cmd(80);
    if(mouse_cmd(0xF2)==0xFA){int id=rd_timeout(60);if(id==3){mouse_has_wheel=1;mlen=4;}}
    mouse_cmd(0xF3);mouse_cmd(100);
    mouse_cmd(0xF4);                                        /* enable reporting */
    mpos=0;mx=400;my=300;mbuttons=mlast=mpress=mrelease=mpress_r=0;
}
static char keychar(u16 sc){
    static const char n[]="\0\0" "1234567890-=\b\tqwertyuiop[]\n\0asdfghjkl;'`\0\\zxcvbnm,./\0*\0 ";
    static const char s[]="\0\0" "!@#$%^&*()_+\b\tQWERTYUIOP{}\n\0ASDFGHJKL:\"~\0|ZXCVBNM<>?\0*\0 ";
    if(sc>0x39)return 0;
    char c=shift?s[sc]:n[sc];
    if(caps&&c>='a'&&c<='z')c=(char)(c-32);
    else if(caps&&shift&&c>='A'&&c<='Z')c=(char)(c+32);
    return c;
}
static void kpush(u16 sc){
    Key k;k.sc=sc;k.mods=(u8)((shift?MOD_SHIFT:0)|(ctrl?MOD_CTRL:0)|(alt?MOD_ALT:0));
    k.ch=(u8)((ctrl||alt)?0:keychar(sc));
    if(sc==K_BS)k.ch=8;else if(sc==K_ENTER)k.ch='\n';else if(sc==K_TAB)k.ch='\t';
    int n=(kqt+1)&63;if(n==kqh)return;kq[kqt]=k;kqt=n;
}
static void kbd_byte(u8 b){
    if(b==0xE0){e0=1;return;}
    if(b==0xE1||b==0xFA||b==0xFE)return;
    int rel=b&0x80;u16 sc=b&0x7F;
    int ext=e0;e0=0;
    if(ext&&(sc==0x2A||sc==0x36))return;                    /* fake shift around numpad/arrow keys */
    if(sc==0x2A||sc==0x36){shift=!rel;return;}
    if(sc==0x1D){ctrl=!rel;return;}
    if(sc==0x38){alt=!rel;return;}
    if(rel)return;
    if(sc==0x3A){caps=!caps;return;}
    if(ext){
        if(sc==0x1C)sc=K_ENTER;else if(sc==0x35)sc=0x35;
        else if(sc==0x48||sc==0x4B||sc==0x4D||sc==0x50)sc=sc;
        else sc|=0x100;
    } else {
        /* numpad keys with NumLock off behave like the navigation block */
        if(sc==0x47||sc==0x49||sc==0x4F||sc==0x51||sc==0x52||sc==0x53){ if(!shift)sc|=0x100; }
    }
    kpush(sc);
}
static void mouse_byte(u8 b){
    if(mpos==0&&!(b&8))return;                               /* resync */
    mp[mpos++]=b;
    if(mpos<mlen)return;
    mpos=0;
    if(mp[0]&0xC0)return;                                    /* overflow */
    int dx=(s8)mp[1],dy=(s8)mp[2];
    mx+=dx;my-=dy;if(mx<0)mx=0;if(mx>=SW_)mx=SW_-1;if(my<0)my=0;if(my>=SH_)my=SH_-1;
    mbuttons=mp[0]&7;
    if((mbuttons&1)&&!(mlast&1))mpress=1;
    if(!(mbuttons&1)&&(mlast&1))mrelease=1;
    if((mbuttons&2)&&!(mlast&2))mpress_r=1;
    mlast=mbuttons;
    if(mlen==4){int z=mp[3]&0x0F;if(z&8)z-=16;mwheel+=z;}
}
void input_poll(void){
    for(int guard=0;guard<64;guard++){
        u8 st=inb(0x64);if(!(st&1))break;
        u8 b=inb(0x60);
        if(st&0x20)mouse_byte(b);else kbd_byte(b);
    }
}
int key_get(Key *k){
    if(kqh==kqt)return 0;
    *k=kq[kqh];kqh=(kqh+1)&63;return 1;
}
