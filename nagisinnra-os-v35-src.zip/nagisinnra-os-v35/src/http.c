#include "nagi.h"
/* Non-blocking HTTP/1.1 client: DNS -> TCP -> request -> headers -> body.
   Handles Content-Length, chunked, and read-until-close bodies. */
const char*http_errstr(int e){
    switch(e){
    case HE_DNS:return "DNS lookup failed (host not found)";
    case HE_CONNECT:return "Connection refused";
    case HE_TIMEOUT:return "Timed out";
    case HE_RESET:return "Connection reset by peer";
    case HE_BADRESP:return "Invalid HTTP response";
    case HE_NONET:return "No network (NIC missing or not configured)";
    case HE_HTTPS:return "https:// is not supported (no TLS). Try an http:// site";
    case HE_BADURL:return "Bad URL";
    }
    return "";
}
static int other_scheme(const char*p){
    for(const char*q=p;*q&&*q!='/'&&*q!='?'&&*q!='#';q++)if(q[0]==':'&&q[1]=='/'&&q[2]=='/')return 1;
    return 0;
}
/* returns 1 ok, -1 https, 0 bad.  Fragment (#...) is dropped, path always starts with '/'. */
int url_split(const char*url,char*host,int hcap,u16*port,char*path,int pcap){
    const char*p=url;
    while(*p==' ')p++;
    if(!strnicmp(p,"https://",8))return -1;
    if(!strnicmp(p,"http://",7))p+=7;
    else if(other_scheme(p))return 0;
    int hn=0;
    while(*p&&*p!='/'&&*p!='?'&&*p!='#'){ if(hn<hcap-1)host[hn++]=*p; p++; }
    host[hn]=0;
    *port=80;
    char*c=strchr(host,':');
    if(c){ *port=(u16)katoi(c+1); *c=0; if(!*port)*port=80; }
    if(!host[0])return 0;
    int pn=0;
    if(*p!='/'){ path[pn++]='/'; }
    while(*p&&*p!='#'&&pn<pcap-1){ path[pn++]=(*p==' ')?'+':*p; p++; }
    if(pn==0)path[pn++]='/';
    path[pn]=0;
    return 1;
}
static void fail(Http*h,int e){
    if(h->id>=0){tcp_abort(h->id);h->id=-1;}
    h->err=e;h->state=HTTP_ERROR;
    dbgf("http: %s%s failed: %s\n",h->host,h->path,http_errstr(e));
}
static void finish(Http*h){
    if(h->id>=0){tcp_release(h->id);h->id=-1;}
    h->state=HTTP_DONE;
}
void http_get(Http*h,const char*host,u16 port,const char*path,u8*buf,int cap){
    memset(h,0,sizeof *h);
    scpy(h->host,host,sizeof h->host);scpy(h->path,path,sizeof h->path);h->port=port;
    h->buf=buf;h->cap=cap;h->id=-1;h->content_length=-1;h->started=ms_now();
    if(net_state==NET_DHCP){h->state=HTTP_WAITNET;h->deadline=ms_now()+15000;return;}
    if(net_state<NET_UP_DHCP){h->err=HE_NONET;h->state=HTTP_ERROR;return;}
    if(!dns_start(host)){h->err=HE_DNS;h->state=HTTP_ERROR;return;}
    h->state=HTTP_DNS;h->deadline=ms_now()+20000;
}
void http_cancel(Http*h){
    if(h->id>=0){tcp_abort(h->id);h->id=-1;}
    if(h->state!=HTTP_DONE&&h->state!=HTTP_ERROR)h->state=HTTP_IDLE;
}
static void body_bytes(Http*h,const u8*d,int n){
    int room=h->cap-1-h->len;
    if(n>room){n=room>0?room:0;h->truncated=1;}
    if(n>0){memcpy(h->buf+h->len,d,n);h->len+=n;}
}
/* feed body data; returns 1 when body complete */
static int body_feed(Http*h,const u8*d,int n){
    if(!h->chunked){
        int take=n;
        if(h->content_length>=0){
            int want=h->content_length-h->body_started;
            if(take>want)take=want;
        }
        body_bytes(h,d,take);h->body_started+=take;
        return h->content_length>=0&&h->body_started>=h->content_length;
    }
    for(int i=0;i<n;){
        if(h->chunk_state==0){                 /* chunk-size line */
            char c=(char)d[i++];
            if(c=='\n'){
                h->chunk_line[h->chunk_ll]=0;
                int v=0,any=0;
                for(int k=0;h->chunk_line[k];k++){
                    char x=h->chunk_line[k];int dv;
                    if(x>='0'&&x<='9')dv=x-'0';else if(x>='a'&&x<='f')dv=x-'a'+10;else if(x>='A'&&x<='F')dv=x-'A'+10;else break;
                    v=v*16+dv;any=1;
                }
                h->chunk_ll=0;
                if(!any)continue;                 /* stray blank line */
                if(v==0){h->chunk_state=3;return 1;}
                h->chunk_left=v;h->chunk_state=1;
            } else if(c!='\r'&&h->chunk_ll<(int)sizeof h->chunk_line-1)h->chunk_line[h->chunk_ll++]=c;
        } else if(h->chunk_state==1){
            int take=n-i;if(take>h->chunk_left)take=h->chunk_left;
            body_bytes(h,d+i,take);i+=take;h->chunk_left-=take;
            if(!h->chunk_left)h->chunk_state=2;
        } else if(h->chunk_state==2){            /* CRLF after data */
            char c=(char)d[i++];
            if(c=='\n')h->chunk_state=0;
        } else return 1;
    }
    return 0;
}
static int parse_headers(Http*h,int hdr_end){
    h->hdr[hdr_end]=0;
    char*s=h->hdr;
    if(strncmp(s,"HTTP/",5))return 0;
    char*sp=strchr(s,' ');if(!sp)return 0;
    h->status=katoi(sp+1);if(h->status<100)return 0;
    char*line=strchr(s,'\n');
    while(line){
        line++;
        char*e=strchr(line,'\n');
        if(!*line||*line=='\r'||*line=='\n')break;
        int ll=e?(int)(e-line):(int)strlen(line);
        if(ll>0&&line[ll-1]=='\r')ll--;
        char tmp[320];int tl=ll<(int)sizeof tmp-1?ll:(int)sizeof tmp-1;memcpy(tmp,line,tl);tmp[tl]=0;
        char*col=strchr(tmp,':');
        if(col){
            *col=0;char*v=col+1;while(*v==' '||*v=='\t')v++;
            if(!stricmp(tmp,"content-length"))h->content_length=katoi(v);
            else if(!stricmp(tmp,"transfer-encoding")){if(stristr(v,"chunked"))h->chunked=1;}
            else if(!stricmp(tmp,"location"))scpy(h->location,v,sizeof h->location);
            else if(!stricmp(tmp,"content-type"))scpy(h->ctype,v,sizeof h->ctype);
        }
        line=e;
    }
    return 1;
}
void http_poll(Http*h){
    u32 now=ms_now();
    switch(h->state){
    case HTTP_WAITNET:{
        if(net_state>=NET_UP_DHCP){
            if(!dns_start(h->host)){fail(h,HE_DNS);return;}
            h->state=HTTP_DNS;h->deadline=now+20000;
        } else if(net_state==NET_NONE||TIME_AFTER(now,h->deadline))fail(h,HE_NONET);
        return;
    }
    case HTTP_DNS:{
        u32 ip;int r=dns_poll(&ip);
        if(r<0){fail(h,HE_DNS);return;}
        if(r==1){
            h->ip=ip;h->id=tcp_open(ip,h->port);
            if(h->id<0){fail(h,HE_CONNECT);return;}
            h->state=HTTP_CONNECT;h->deadline=now+15000;
        } else if(TIME_AFTER(now,h->deadline))fail(h,HE_TIMEOUT);
        return;
    }
    case HTTP_CONNECT:{
        int st=tcp_state(h->id);
        if(st==TCP_ESTAB||st==TCP_CLOSE_WAIT){
            char req[700];
            const char*hp=h->port==80?"":"";(void)hp;
            if(h->port==80)ksnprintf(req,sizeof req,"GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: NagisinnraOS/" VERSION_STR "\r\nAccept: text/html,text/plain,*/*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n",h->path,h->host);
            else ksnprintf(req,sizeof req,"GET %s HTTP/1.1\r\nHost: %s:%d\r\nUser-Agent: NagisinnraOS/" VERSION_STR "\r\nAccept: text/html,text/plain,*/*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n",h->path,h->host,h->port);
            tcp_write(h->id,req,(int)strlen(req));
            h->state=HTTP_HEADERS;h->deadline=now+20000;
        } else if(st==TCP_CLOSED){
            int e=tcp_error(h->id);
            fail(h,e==TCPE_REFUSED?HE_CONNECT:e==TCPE_RESET?HE_RESET:HE_TIMEOUT);
        } else if(TIME_AFTER(now,h->deadline))fail(h,HE_TIMEOUT);
        return;
    }
    case HTTP_HEADERS:case HTTP_BODY:{
        u8 tmp[1024];int n,got=0;
        while((n=tcp_read(h->id,tmp,sizeof tmp))>0){
            got=1;
            int off=0;
            if(h->state==HTTP_HEADERS){
                for(;off<n;off++){
                    if(h->hlen<(int)sizeof h->hdr-1)h->hdr[h->hlen++]=(char)tmp[off];
                    else {fail(h,HE_BADRESP);return;}
                    int L=h->hlen;
                    if((L>=4&&!memcmp(h->hdr+L-4,"\r\n\r\n",4))||(L>=2&&!memcmp(h->hdr+L-2,"\n\n",2))){
                        off++;
                        if(!parse_headers(h,L)){fail(h,HE_BADRESP);return;}
                        if(h->status>=100&&h->status<200){h->hlen=0;h->status=0;continue;}   /* skip 1xx */
                        h->state=HTTP_BODY;break;
                    }
                }
            }
            if(h->state==HTTP_BODY&&off<n){
                if(h->status==204||h->status==304||(h->content_length==0&&!h->chunked)){finish(h);return;}
                if(body_feed(h,tmp+off,n-off)){finish(h);return;}
            } else if(h->state==HTTP_BODY&&(h->status==204||h->status==304||(h->content_length==0&&!h->chunked))){finish(h);return;}
            if(h->truncated&&h->len>=h->cap-1){finish(h);return;}
        }
        if(got)h->deadline=now+20000;
        if(h->state==HTTP_BODY&&h->content_length==0&&!h->chunked){finish(h);return;}
        if(tcp_eof(h->id)){
            if(h->state==HTTP_BODY)finish(h);
            else fail(h,tcp_error(h->id)==TCPE_RESET?HE_RESET:HE_BADRESP);
            return;
        }
        if(TIME_AFTER(now,h->deadline)){ if(h->state==HTTP_BODY&&h->len>0)finish(h); else fail(h,HE_TIMEOUT); }
        return;
    }
    default:return;
    }
}
