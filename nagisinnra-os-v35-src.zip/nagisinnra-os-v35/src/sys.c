#include "wm.h"
#include "fat12.h"
/* System info + task list. */
static const char *names[]={"Terminal","Files","Editor","Paint","System","Browser","Tetris","Snake","Mines","Breakout","Games","Game"};
static void btn(int x,int y,int w,const char *l,int hot){int hv=inside(x,y,w,24,mx,my);roundrect(x,y,w,24,5,hv?rgb(30,48,76):hot?rgb(60,34,40):rgb(14,22,38));text16(x+(w-text16w(l))/2,y+4,l,C_TEXT);}
void sys_draw(Window *w){
    int x=CONTENT_X(w)+6,y=CONTENT_Y(w)+6;
    set_clip(CONTENT_X(w),CONTENT_Y(w),CONTENT_W(w),CONTENT_H(w));
    char b[120];
    text16(x,y,"NAGISINNRA OS",C_GREEN);ksnprintf(b,sizeof b,"version %s   i386 / VBE 800x600",VERSION_STR);text16(x+120,y,b,C_DIM);y+=24;
    u32 s=ms_now()/1000;ksnprintf(b,sizeof b,"Uptime      %d min %02d s",(int)(s/60),(int)(s%60));text16(x,y,b,C_TEXT);y+=18;
    ksnprintf(b,sizeof b,"Memory      %d MB managed, %d MB free",(int)(mem_total_pages_count()*4/1024),(int)(mem_free_pages_count()*4/1024));text16(x,y,b,C_TEXT);y+=18;
    ksnprintf(b,sizeof b,"RAM disk    %d KB, %d KB free",(int)(fs_total_bytes()/1024),(int)(fs_free_bytes()/1024));text16(x,y,b,C_TEXT);y+=26;
    text16(x,y,"Network",C_ACC);y+=20;
    if(net_state==NET_NONE){text16(x,y,"No NE2000 adapter found",C_RED);y+=18;}
    else{
        char a[16],m[16],g[16],d[16];ip_str(net_ip,a);ip_str(net_mask,m);ip_str(net_gw,g);ip_str(net_dns,d);
        text16(x,y,nic_name,C_TEXT);y+=18;
        ksnprintf(b,sizeof b,"MAC  %02x:%02x:%02x:%02x:%02x:%02x",nic_mac[0],nic_mac[1],nic_mac[2],nic_mac[3],nic_mac[4],nic_mac[5]);text16(x,y,b,C_DIM);y+=18;
        ksnprintf(b,sizeof b,"IP   %s / %s",a,m);text16(x,y,b,C_TEXT);y+=18;
        ksnprintf(b,sizeof b,"GW   %s   DNS %s",g,d);text16(x,y,b,C_TEXT);y+=18;
        const char *st=net_state==NET_UP_DHCP?"up (DHCP)":net_state==NET_UP_STATIC?"up (static / fallback)":net_state==NET_DHCP?"configuring ...":"down";
        ksnprintf(b,sizeof b,"Link %s   rx %d  tx %d  drop %d",st,nic_rx_frames,nic_tx_frames,nic_rx_drops);
        text16(x,y,b,net_state>=NET_UP_DHCP?C_GREEN:C_YEL);y+=22;
    }
    btn(x,y,120,"Renew DHCP",0);btn(x+130,y,90,"Reboot",1);y+=36;
    text16(x,y,"Windows (click to focus)",C_ACC);y+=20;
    for(int i=0;i<NAPPS;i++)if(win[i].open){
        int hv=inside(x-4,y,CONTENT_W(w)-8,18,mx,my);if(hv)fill(x-4,y,CONTENT_W(w)-8,18,rgb(18,30,52));
        text16(x,y,names[i],i==active?C_GREEN:C_TEXT);y+=18;
    }
    clip_reset();
}
void sys_click(Window *w){
    int x=CONTENT_X(w)+6,y=CONTENT_Y(w)+6+106;
    y+=(net_state==NET_NONE)?18:94;
    if(inside(x,y,120,24,mx,my)){net_dhcp_start();return;}
    if(inside(x+130,y,90,24,mx,my)){do_reboot();return;}
    y+=36+20;
    for(int i=0;i<NAPPS;i++)if(win[i].open){
        if(inside(x-4,y,CONTENT_W(w)-8,18,mx,my)){active=i;raise_window(i);return;}
        y+=18;
    }
}
