#include "nagi.h"
/* Ethernet / ARP / IPv4 / ICMP / UDP / DHCP / DNS / TCP.  Polled, single threaded. */
u32 net_ip,net_mask,net_gw,net_dns; int net_state=NET_NONE;
static u8 txb[1600], rxb[1700];
static u16 ipid=0x1234;

static inline u16 g16(const u8*p){return (u16)((p[0]<<8)|p[1]);}
static inline u32 g32(const u8*p){return ((u32)p[0]<<24)|((u32)p[1]<<16)|((u32)p[2]<<8)|p[3];}
static inline void p16(u8*p,u16 v){p[0]=(u8)(v>>8);p[1]=(u8)v;}
static inline void p32(u8*p,u32 v){p[0]=(u8)(v>>24);p[1]=(u8)(v>>16);p[2]=(u8)(v>>8);p[3]=(u8)v;}
static u32 csum_add(u32 s,const u8*p,int n){while(n>1){s+=((u32)p[0]<<8)|p[1];p+=2;n-=2;}if(n)s+=(u32)p[0]<<8;return s;}
static u16 csum_fin(u32 s){while(s>>16)s=(s&0xffff)+(s>>16);return (u16)~s;}

int ip_parse(const char*s,u32*ip){
    u32 v=0;int parts=0;
    for(;;){
        if(*s<'0'||*s>'9')return 0;
        int n=0,d=0;while(*s>='0'&&*s<='9'){n=n*10+(*s-'0');s++;d++;if(n>255||d>3)return 0;}
        v=(v<<8)|(u32)n;parts++;
        if(*s=='.'){s++;continue;}
        break;
    }
    if(*s||parts!=4)return 0;
    *ip=v;return 1;
}
void ip_str(u32 ip,char*out){ksnprintf(out,16,"%d.%d.%d.%d",(ip>>24)&255,(ip>>16)&255,(ip>>8)&255,ip&255);}

/* ---------------- ARP ---------------- */
typedef struct{u32 ip;u8 mac[6];u32 t;u8 valid;}ArpEnt;
static ArpEnt arpc[8];
static u8 pend[1600];static int pendlen;static u32 pend_ip;
static u32 arp_last_req_ip,arp_last_req_t;
static ArpEnt*arp_find(u32 ip){for(int i=0;i<8;i++)if(arpc[i].valid&&arpc[i].ip==ip)return &arpc[i];return NULL;}
static void arp_learn(u32 ip,const u8*mac){
    ArpEnt*e=arp_find(ip);
    if(!e){
        int pick=-1;u32 best=0;
        for(int i=0;i<8;i++){ if(!arpc[i].valid){pick=i;break;} u32 age=ms_now()-arpc[i].t; if(pick<0||age>=best){best=age;pick=i;} }
        e=&arpc[pick];
    }
    e->ip=ip;memcpy(e->mac,mac,6);e->t=ms_now();e->valid=1;
}
static void arp_send(u16 op,const u8*dmac,u32 tip,const u8*tmac){
    u8 f[60];memset(f,0,sizeof f);
    memcpy(f,dmac,6);memcpy(f+6,nic_mac,6);p16(f+12,0x0806);
    p16(f+14,1);p16(f+16,0x0800);f[18]=6;f[19]=4;p16(f+20,op);
    memcpy(f+22,nic_mac,6);p32(f+28,net_ip);memcpy(f+32,tmac,6);p32(f+38,tip);
    nic_send(f,60);
}
static void arp_request(u32 ip){
    static const u8 bc[6]={255,255,255,255,255,255},z[6]={0};
    u32 now=ms_now();
    if(arp_last_req_ip==ip&&now-arp_last_req_t<150)return;
    arp_last_req_ip=ip;arp_last_req_t=now;
    arp_send(1,bc,ip,z);
}
static void arp_input(const u8*f,int n){
    if(n<42||g16(f+14)!=1||g16(f+16)!=0x0800)return;
    u16 op=g16(f+20);u32 spa=g32(f+28),tpa=g32(f+38);const u8*sha=f+22;
    if(spa){
        arp_learn(spa,sha);
        if(pendlen&&pend_ip==spa){memcpy(pend,sha,6);nic_send(pend,pendlen);pendlen=0;}
    }
    if(op==1&&net_ip&&tpa==net_ip)arp_send(2,sha,spa,sha);
}

/* ---------------- IP out ---------------- */
static int ip_out(u32 src,u32 dst,u8 proto,const u8*pl,int plen){
    if(plen>1480||net_state<NET_DHCP)return 0;
    u8*f=txb,*ip=f+14;
    ip[0]=0x45;ip[1]=0;p16(ip+2,(u16)(20+plen));p16(ip+4,ipid++);p16(ip+6,0x4000);ip[8]=64;ip[9]=proto;p16(ip+10,0);p32(ip+12,src);p32(ip+16,dst);
    p16(ip+10,csum_fin(csum_add(0,ip,20)));
    memcpy(ip+20,pl,plen);
    memcpy(f+6,nic_mac,6);p16(f+12,0x0800);
    int total=14+20+plen;
    if(dst==0xffffffffu||(net_mask&&net_ip&&dst==(net_ip|~net_mask))){memset(f,0xff,6);return nic_send(f,total);}
    u32 nh=(((dst^net_ip)&net_mask)==0)?dst:net_gw;
    if(!nh)return 0;
    ArpEnt*e=arp_find(nh);
    if(e){memcpy(f,e->mac,6);return nic_send(f,total);}
    memcpy(pend,f,total);pendlen=total;pend_ip=nh;
    arp_request(nh);
    return 1;
}
static u16 udp_port_ctr=49152;
static int udp_out(u32 src,u32 dst,u16 sp,u16 dp,const u8*d,int n){
    u8 b[1500];if(n>1400)return 0;
    p16(b,sp);p16(b+2,dp);p16(b+4,(u16)(8+n));p16(b+6,0);memcpy(b+8,d,n);
    u32 s=0;s+=(src>>16)+(src&0xffff)+(dst>>16)+(dst&0xffff)+17+(8+n);
    s=csum_add(s,b,8+n);u16 c=csum_fin(s);if(!c)c=0xffff;p16(b+6,c);
    return ip_out(src,dst,17,b,8+n);
}

/* ---------------- ICMP ping ---------------- */
static u8 ping_have;static u32 ping_from,ping_rtt;static int ping_seqv;
int ping_send(u32 ip,int seq){
    u8 b[40];memset(b,0,sizeof b);b[0]=8;b[1]=0;p16(b+4,0x4e47);p16(b+6,(u16)seq);p32(b+8,ms_now());
    for(int i=12;i<40;i++)b[i]=(u8)('a'+i%23);
    p16(b+2,csum_fin(csum_add(0,b,40)));
    return ip_out(net_ip,ip,1,b,40);
}
int ping_poll(u32*from,int*seq,u32*rtt){
    if(!ping_have)return 0;ping_have=0;*from=ping_from;*seq=ping_seqv;*rtt=ping_rtt;return 1;
}
static void icmp_input(u32 src,const u8*p,int n){
    if(n<8)return;
    if(p[0]==8){
        u8 b[1500];if(n>1400)return;memcpy(b,p,n);b[0]=0;p16(b+2,0);p16(b+2,csum_fin(csum_add(0,b,n)));
        ip_out(net_ip,src,1,b,n);
    } else if(p[0]==0&&g16(p+4)==0x4e47){
        ping_have=1;ping_from=src;ping_seqv=g16(p+6);ping_rtt=n>=12?ms_now()-g32(p+8):0;
    }
}

/* ---------------- DHCP ---------------- */
static int dh_state;static u32 dh_xid,dh_deadline,dh_offer,dh_server;static int dh_tries;
static void dhcp_send(int type){
    u8 b[320];memset(b,0,sizeof b);
    b[0]=1;b[1]=1;b[2]=6;p32(b+4,dh_xid);p16(b+10,0x8000);memcpy(b+28,nic_mac,6);
    p32(b+236,0x63825363u);u8*o=b+240;
    *o++=53;*o++=1;*o++=(u8)type;
    *o++=61;*o++=7;*o++=1;memcpy(o,nic_mac,6);o+=6;
    if(type==3){*o++=50;*o++=4;p32(o,dh_offer);o+=4;*o++=54;*o++=4;p32(o,dh_server);o+=4;}
    *o++=12;*o++=7;memcpy(o,"nagi-os",7);o+=7;
    *o++=55;*o++=4;*o++=1;*o++=3;*o++=6;*o++=15;
    *o++=255;
    int n=(int)(o-b);if(n<300)n=300;
    net_state=NET_DHCP;
    u32 sv=net_ip;net_ip=0;
    udp_out(0,0xffffffffu,68,67,b,n);
    net_ip=sv;
}
void net_set_static(u32 ip,u32 m,u32 gw,u32 dns){dbgf("net: static/fallback ip=%x gw=%x\n",ip,gw);net_ip=ip;net_mask=m;net_gw=gw;net_dns=dns;net_state=NET_UP_STATIC;dh_state=0;}
void net_dhcp_start(void){
    if(net_state==NET_NONE)return;
    net_ip=0;net_mask=0;net_gw=0;net_dns=0;
    for(int i=0;i<8;i++)arpc[i].valid=0;pendlen=0;
    dh_xid=ms_now()*2654435761u+0x1234567u;dh_tries=0;dh_state=1;dh_deadline=ms_now()+1500;
    net_state=NET_DHCP;dhcp_send(1);
}
static void dhcp_input(const u8*d,int n){
    if(n<241||d[0]!=2||g32(d+4)!=dh_xid||g32(d+236)!=0x63825363u||memcmp(d+28,nic_mac,6))return;
    int type=0;u32 mask=0,gw=0,dns=0,srv=0;
    for(int i=240;i<n;){
        u8 c=d[i];if(c==255)break;if(c==0){i++;continue;}
        if(i+1>=n)break;u8 l=d[i+1];if(i+2+l>n)break;const u8*v=d+i+2;
        if(c==53&&l>=1)type=v[0];else if(c==1&&l>=4)mask=g32(v);else if(c==3&&l>=4)gw=g32(v);
        else if(c==6&&l>=4)dns=g32(v);else if(c==54&&l>=4)srv=g32(v);
        i+=2+l;
    }
    u32 yi=g32(d+16);
    if(dh_state==1&&type==2){dh_offer=yi;dh_server=srv;dh_state=2;dh_tries=0;dh_deadline=ms_now()+1500;dhcp_send(3);}
    else if(dh_state==2&&type==5){
        net_ip=yi;net_mask=mask?mask:IP4(255,255,255,0);net_gw=gw;net_dns=dns?dns:gw;
        net_state=NET_UP_DHCP;dh_state=0;
        dbgf("dhcp: ack ip=%x mask=%x gw=%x dns=%x\n",net_ip,net_mask,net_gw,net_dns);
        static const u8 z[6]={0};(void)z;
    } else if(type==6){dh_state=1;dh_tries=0;dh_xid+=1;dh_deadline=ms_now()+500;}
}
static void dhcp_poll(void){
    if(!dh_state||!TIME_AFTER(ms_now(),dh_deadline))return;
    if(++dh_tries>=4){net_set_static(IP4(192,168,86,100),IP4(255,255,255,0),IP4(192,168,86,1),IP4(192,168,86,1));return;}
    dh_deadline=ms_now()+2000;
    if(dh_state==1)dhcp_send(1);else{dh_state=1;dhcp_send(1);}
}

/* ---------------- DNS ---------------- */
typedef struct{char name[80];u32 ip;u32 t;u8 valid;}DnsEnt;
static DnsEnt dcache[8];static int dcache_n;
static char dq_name[80];static u16 dq_id,dq_port;static int dq_state;static u32 dq_ip,dq_deadline;static int dq_tries,dq_depth;
static void dns_send(void){
    u8 q[160];memset(q,0,sizeof q);p16(q,dq_id);p16(q+2,0x0100);p16(q+4,1);
    int pos=12,start=0;const char*h=dq_name;
    for(int i=0;;i++){
        if(h[i]=='.'||h[i]==0){int l=i-start;if(l<1||l>63){dq_state=3;return;}q[pos++]=(u8)l;for(int j=start;j<i;j++)q[pos++]=(u8)h[j];start=i+1;if(!h[i])break;}
    }
    q[pos++]=0;p16(q+pos,1);pos+=2;p16(q+pos,1);pos+=2;
    udp_out(net_ip,net_dns,dq_port,53,q,pos);
}
int dns_start(const char*name){
    u32 ip;
    dq_state=0;
    if(ip_parse(name,&ip)){dq_ip=ip;dq_state=2;return 1;}
    for(int i=0;i<8;i++)if(dcache[i].valid&&!stricmp(dcache[i].name,name)&&ms_now()-dcache[i].t<300000u){dq_ip=dcache[i].ip;dq_state=2;return 1;}
    if(!net_dns||net_state<NET_UP_DHCP){dq_state=3;return 0;}
    scpy(dq_name,name,sizeof dq_name);
    dq_id=(u16)(ms_now()*7+0x4321);dq_port=udp_port_ctr++;if(udp_port_ctr>60000)udp_port_ctr=49152;
    dq_tries=0;dq_depth=0;dq_state=1;dq_deadline=ms_now()+1500;dns_send();return 1;
}
static int dns_name(const u8*p,int n,int pos,char*out,int cap){
    int o=0,jumped=0,ret=-1,guard=0;
    while(pos<n&&guard++<64){
        u8 l=p[pos];
        if(l==0){pos++;break;}
        if((l&0xc0)==0xc0){if(pos+1>=n)return -1;if(!jumped)ret=pos+2;jumped=1;pos=((l&0x3f)<<8)|p[pos+1];continue;}
        pos++;if(pos+l>n)return -1;
        if(o&&o<cap-1)out[o++]='.';
        for(int i=0;i<l&&o<cap-1;i++)out[o++]=(char)p[pos+i];
        pos+=l;
    }
    out[o]=0;
    return jumped?ret:pos;
}
static void dns_input(const u8*d,int n){
    if(dq_state!=1||n<12||g16(d)!=dq_id)return;
    int rc=g16(d+2)&15,an=g16(d+6),qd=g16(d+4);
    if(rc!=0){dq_state=3;return;}
    int pos=12;char nm[80];
    for(int i=0;i<qd;i++){pos=dns_name(d,n,pos,nm,sizeof nm);if(pos<0)return;pos+=4;}
    char cname[80];cname[0]=0;
    for(int i=0;i<an&&pos<n;i++){
        pos=dns_name(d,n,pos,nm,sizeof nm);if(pos<0||pos+10>n)break;
        u16 type=g16(d+pos),rl=g16(d+pos+8);pos+=10;if(pos+rl>n)break;
        if(type==1&&rl==4){
            dq_ip=g32(d+pos);dq_state=2;
            DnsEnt*e=&dcache[dcache_n++&7];scpy(e->name,dq_name,sizeof e->name);e->ip=dq_ip;e->t=ms_now();e->valid=1;
            return;
        } else if(type==5){dns_name(d,n,pos,cname,sizeof cname);}
        pos+=rl;
    }
    if(cname[0]&&dq_depth<4){dq_depth++;scpy(dq_name,cname,sizeof dq_name);dq_id++;dq_tries=0;dq_deadline=ms_now()+1500;dns_send();return;}
    dq_state=3;
}
int dns_poll(u32*ip){
    if(dq_state==2){*ip=dq_ip;return 1;}
    if(dq_state==3)return -1;
    if(dq_state==1&&TIME_AFTER(ms_now(),dq_deadline)){
        if(++dq_tries>=4){dq_state=3;return -1;}
        dq_deadline=ms_now()+1500;dns_send();
    }
    return 0;
}

/* ---------------- TCP ---------------- */
#define TCPN 2
#define RB 16384
#define SB 1600
typedef struct{
    u8 used,state,err,fin_rcvd,fin_sent,want_close,rel;
    u32 rip;u16 rport,lport;
    u32 iss,snd_una,snd_nxt,snd_wnd,irs,rcv_nxt,fin_seq;
    u16 mss,sl;u8 sbuf[SB];
    u32 rhead,rcount;u8 rbuf[RB];
    u32 rto_at,rto;u8 retries,timer;u16 adv;u32 rel_t;
}Tcb;
static Tcb tcb[TCPN];
static u16 tcp_port_ctr=50000;static u32 iss_ctr=0x1000;
#define SEQ_LT(a,b) ((s32)((a)-(b))<0)
#define SEQ_LE(a,b) ((s32)((a)-(b))<=0)
#define SEQ_GT(a,b) ((s32)((a)-(b))>0)

static void tcp_raw(u32 dst,u16 sp,u16 dp,u32 seq,u32 ack,u8 fl,u16 win,const u8*d,int n,int mss){
    u8 b[1500];int hl=mss?24:20;if(n>1400)n=1400;
    p16(b,sp);p16(b+2,dp);p32(b+4,seq);p32(b+8,ack);b[12]=(u8)((hl/4)<<4);b[13]=fl;p16(b+14,win);p16(b+16,0);p16(b+18,0);
    if(mss){b[20]=2;b[21]=4;p16(b+22,(u16)mss);}
    memcpy(b+hl,d,n);
    u32 s=0;s+=(net_ip>>16)+(net_ip&0xffff)+(dst>>16)+(dst&0xffff)+6+(hl+n);
    s=csum_add(s,b,hl+n);p16(b+16,csum_fin(s));
    ip_out(net_ip,dst,6,b,hl+n);
}
/* Advertise at most ~6 full frames: the NE2000 ring only holds ~9 and we poll between redraws. */
static u16 tcp_win(Tcb*t){u32 w=RB-t->rcount;if(w>8760)w=8760;return (u16)w;}
static void tcp_seg(Tcb*t,u8 fl,u32 seq,const u8*d,int n,int mss){
    t->adv=tcp_win(t);
    tcp_raw(t->rip,t->lport,t->rport,seq,(fl&0x10)?t->rcv_nxt:0,fl,t->adv,d,n,mss);
}
static void tcp_ack(Tcb*t){tcp_seg(t,0x10,t->snd_nxt,0,0,0);}
static void arm(Tcb*t){t->timer=1;t->rto_at=ms_now()+t->rto;}
static void tcb_free(Tcb*t){memset(t,0,sizeof *t);}

static Tcb*tcb_of(int id){return (id>=0&&id<TCPN&&tcb[id].used)?&tcb[id]:NULL;}
static void tcp_flush(Tcb*t){
    if(t->state!=TCP_ESTAB&&t->state!=TCP_CLOSE_WAIT)return;
    for(;;){
        u32 infl=t->snd_nxt-t->snd_una;
        u32 dinfl=t->fin_sent?(t->fin_seq-t->snd_una):infl;
        int avail=(int)t->sl-(int)dinfl;
        if(avail>0){
            u32 wnd=t->snd_wnd>infl?t->snd_wnd-infl:0;if(!wnd)break;
            int n=avail;if(n>t->mss)n=t->mss;if((u32)n>wnd)n=(int)wnd;
            tcp_seg(t,0x18,t->snd_nxt,t->sbuf+dinfl,n,0);
            t->snd_nxt+=(u32)n;if(!t->timer)arm(t);
            continue;
        }
        if(t->want_close&&!t->fin_sent){
            t->fin_seq=t->snd_nxt;tcp_seg(t,0x11,t->fin_seq,0,0,0);t->snd_nxt++;t->fin_sent=1;
            t->state=(t->state==TCP_ESTAB)?TCP_FIN_WAIT1:TCP_LAST_ACK;
            if(!t->timer)arm(t);
        }
        break;
    }
}
int tcp_open(u32 ip,u16 port){
    int id=-1;for(int i=0;i<TCPN;i++)if(!tcb[i].used){id=i;break;}
    if(id<0)return -1;
    Tcb*t=&tcb[id];tcb_free(t);
    t->used=1;t->rip=ip;t->rport=port;t->lport=tcp_port_ctr++;if(tcp_port_ctr>60000)tcp_port_ctr=50000;
    iss_ctr+=0x10000+ms_now()*64;t->iss=iss_ctr;t->snd_una=t->iss;t->snd_nxt=t->iss+1;
    t->mss=536;t->rto=1000;t->snd_wnd=0;t->state=TCP_SYN_SENT;
    tcp_seg(t,0x02,t->iss,0,0,1460);arm(t);
    return id;
}
int tcp_state(int id){Tcb*t=tcb_of(id);return t?t->state:TCP_CLOSED;}
int tcp_error(int id){Tcb*t=tcb_of(id);return t?t->err:0;}
int tcp_write(int id,const void*d,int n){
    Tcb*t=tcb_of(id);if(!t||(t->state!=TCP_ESTAB&&t->state!=TCP_CLOSE_WAIT)||t->want_close)return 0;
    int room=SB-t->sl;if(n>room)n=room;
    memcpy(t->sbuf+t->sl,d,n);t->sl=(u16)(t->sl+n);tcp_flush(t);return n;
}
int tcp_avail(int id){Tcb*t=tcb_of(id);return t?(int)t->rcount:0;}
int tcp_read(int id,void*d,int max){
    Tcb*t=tcb_of(id);if(!t)return 0;
    int n=(int)t->rcount;if(n>max)n=max;u8*o=d;
    for(int i=0;i<n;i++){o[i]=t->rbuf[t->rhead];t->rhead=(t->rhead+1)%RB;}
    int was_small=tcp_win(t)<t->mss*2u||t->adv<t->mss;
    t->rcount-=(u32)n;
    if(n&&was_small&&(t->state==TCP_ESTAB||t->state==TCP_CLOSE_WAIT||t->state==TCP_FIN_WAIT2)&&tcp_win(t)>=t->mss)tcp_ack(t);
    return n;
}
int tcp_eof(int id){Tcb*t=tcb_of(id);if(!t)return 1;return t->rcount==0&&(t->fin_rcvd||t->state==TCP_CLOSED);}
void tcp_close(int id){Tcb*t=tcb_of(id);if(!t)return;if(t->state==TCP_SYN_SENT){tcb_free(t);return;}t->want_close=1;tcp_flush(t);}
void tcp_abort(int id){
    Tcb*t=tcb_of(id);if(!t)return;
    if(t->state!=TCP_CLOSED&&t->state!=TCP_SYN_SENT)tcp_seg(t,0x14,t->snd_nxt,0,0,0);
    tcb_free(t);
}
void tcp_release(int id){
    Tcb*t=tcb_of(id);if(!t)return;
    if(t->state==TCP_CLOSED||t->state==TCP_SYN_SENT){tcb_free(t);return;}
    t->rel=1;t->rel_t=ms_now();t->want_close=1;t->rcount=0;tcp_flush(t);
}
static void tcp_input(u32 src,const u8*s,int n){
    if(n<20)return;
    u16 sp=g16(s),dp=g16(s+2);u32 seq=g32(s+4),ack=g32(s+8);int hl=(s[12]>>4)*4;u8 fl=s[13];u16 win=g16(s+14);
    if(hl<20||hl>n)return;
    const u8*pl=s+hl;int len=n-hl;
    Tcb*t=NULL;for(int i=0;i<TCPN;i++)if(tcb[i].used&&tcb[i].rip==src&&tcb[i].rport==sp&&tcb[i].lport==dp){t=&tcb[i];break;}
    if(!t){
        if(fl&0x04)return;
        if(fl&0x10)tcp_raw(src,dp,sp,ack,0,0x04,0,0,0,0);
        else tcp_raw(src,dp,sp,0,seq+(u32)len+((fl&3)?1:0),0x14,0,0,0,0);
        return;
    }
    if(t->state==TCP_SYN_SENT){
        if(fl&0x04){if(fl&0x10&&ack==t->iss+1){t->state=TCP_CLOSED;t->err=TCPE_REFUSED;t->timer=0;}return;}
        if((fl&0x12)==0x12&&ack==t->iss+1){
            t->irs=seq;t->rcv_nxt=seq+1;t->snd_una=ack;t->snd_wnd=win;t->timer=0;t->retries=0;t->rto=1000;
            for(int i=20;i<hl;){u8 k=s[i];if(k==0)break;if(k==1){i++;continue;}if(i+1>=hl)break;u8 l=s[i+1];if(l<2)break;if(k==2&&l==4){u16 m=g16(s+i+2);if(m>=64&&m<=1460)t->mss=m;}i+=l;}
            if(t->mss==536){/* peer sent no MSS option: stay conservative */}
            t->state=TCP_ESTAB;tcp_ack(t);tcp_flush(t);
        }
        return;
    }
    if(fl&0x04){if(SEQ_LE(t->rcv_nxt,seq+1)||seq==t->rcv_nxt){t->state=TCP_CLOSED;t->err=TCPE_RESET;t->timer=0;}return;}
    if(fl&0x10){
        if(SEQ_GT(ack,t->snd_una)&&SEQ_LE(ack,t->snd_nxt)){
            u32 acked=ack-t->snd_una;
            int fin_acked=t->fin_sent&&SEQ_GT(ack,t->fin_seq);
            u32 dacked=fin_acked?acked-1:acked;if(dacked>t->sl)dacked=t->sl;
            if(dacked){memmove(t->sbuf,t->sbuf+dacked,t->sl-dacked);t->sl=(u16)(t->sl-dacked);}
            t->snd_una=ack;t->retries=0;t->rto=1000;
            if(t->snd_una==t->snd_nxt)t->timer=0;else arm(t);
            if(fin_acked){
                if(t->state==TCP_FIN_WAIT1)t->state=t->fin_rcvd?TCP_CLOSED:TCP_FIN_WAIT2;
                else if(t->state==TCP_LAST_ACK||t->state==TCP_CLOSING)t->state=TCP_CLOSED;
            }
        }
        if(SEQ_LE(t->snd_una,ack)&&SEQ_LE(ack,t->snd_nxt))t->snd_wnd=win;
    }
    if(len>0||(fl&0x01)){
        if(SEQ_LT(seq,t->rcv_nxt)){
            u32 skip=t->rcv_nxt-seq;
            if(skip>(u32)len+((fl&1)?1u:0u)||(skip==(u32)len&&!(fl&1))||(skip==(u32)len+1)){tcp_ack(t);return;}
            if(skip<=(u32)len){pl+=skip;len-=(int)skip;seq=t->rcv_nxt;}
        }
        if(seq!=t->rcv_nxt){tcp_ack(t);return;}
        int room=(int)(RB-t->rcount);int take=len;int trunc=0;
        if(take>room){take=room;trunc=1;}
        for(int i=0;i<take;i++)t->rbuf[(t->rhead+t->rcount+i)%RB]=pl[i];
        t->rcount+=(u32)take;t->rcv_nxt+=(u32)take;
        if((fl&1)&&!trunc&&!t->fin_rcvd){
            t->rcv_nxt++;t->fin_rcvd=1;
            if(t->state==TCP_ESTAB)t->state=TCP_CLOSE_WAIT;
            else if(t->state==TCP_FIN_WAIT1)t->state=TCP_CLOSING;
            else if(t->state==TCP_FIN_WAIT2)t->state=TCP_CLOSED;
        }
        tcp_ack(t);
        if(t->state==TCP_CLOSED&&t->fin_rcvd){t->timer=0;}
    }
    tcp_flush(t);
}
static void tcp_poll(void){
    u32 now=ms_now();
    for(int i=0;i<TCPN;i++){
        Tcb*t=&tcb[i];if(!t->used)continue;
        if(t->rel){
            if(t->state==TCP_CLOSED||ms_now()-t->rel_t>4000){if(t->state!=TCP_CLOSED)tcp_seg(t,0x14,t->snd_nxt,0,0,0);tcb_free(t);continue;}
        }
        if(t->state==TCP_CLOSED||!t->timer||!TIME_AFTER(now,t->rto_at))continue;
        if(++t->retries>7){t->err=TCPE_TIMEOUT;t->state=TCP_CLOSED;t->timer=0;continue;}
        t->rto*=2;if(t->rto>8000)t->rto=8000;
        if(t->state==TCP_SYN_SENT){tcp_seg(t,0x02,t->iss,0,0,1460);}
        else{
            u32 dun=t->fin_sent?(t->fin_seq-t->snd_una):(t->snd_nxt-t->snd_una);
            if(dun>0){int n=(int)dun;if(n>t->mss)n=t->mss;tcp_seg(t,0x18,t->snd_una,t->sbuf,n,0);}
            else if(t->fin_sent)tcp_seg(t,0x11,t->fin_seq,0,0,0);
        }
        arm(t);
    }
}

/* ---------------- input dispatch ---------------- */
static void ip_input(const u8*f,int n){
    if(n<34)return;const u8*ip=f+14;
    if((ip[0]>>4)!=4)return;int ihl=(ip[0]&15)*4;if(ihl<20)return;
    int tl=g16(ip+2);if(tl<ihl||14+tl>n)return;
    if(g16(ip+6)&0x3fff)return;                       /* fragments unsupported */
    u32 src=g32(ip+12),dst=g32(ip+16);
    if(!(dst==net_ip||dst==0xffffffffu||(net_ip&&net_mask&&dst==(net_ip|~net_mask))||net_ip==0))return;
    const u8*p=ip+ihl;int pl=tl-ihl;
    if(ip[9]==1)icmp_input(src,p,pl);
    else if(ip[9]==17&&pl>=8){
        u16 dp=g16(p+2);int ul=g16(p+4)-8;if(ul<0||ul>pl-8)return;
        if(dp==68)dhcp_input(p+8,ul);else if(dp==dq_port)dns_input(p+8,ul);
    }
    else if(ip[9]==6&&dst==net_ip)tcp_input(src,p,pl);
}
void net_init(void){
    net_state=NET_NONE;
    if(!nic_init())return;
    net_state=NET_NOIP;
    net_dhcp_start();
}
void net_poll(void){
    if(net_state==NET_NONE)return;
    for(int k=0;k<12;k++){
        int n=nic_recv(rxb,sizeof rxb);if(n<=0)break;
        if(n<14)continue;
        u16 et=g16(rxb+12);
        if(et==0x0806)arp_input(rxb,n);else if(et==0x0800)ip_input(rxb,n);
    }
    dhcp_poll();tcp_poll();
}
