#include "wm.h"
#include "fat12.h"
/* Paint: pen/eraser/fill, 16 colours, 3 brush sizes, save as 24-bit BMP. */
#define PW 460
#define PH 250
static u16 *cv;static int color=14,brush=1,tool=0,last_x=-1,last_y=-1;   /* tool: 0 pen 1 eraser 2 fill */
static char pmsg[80];static u32 pmsg_t;
static const u8 pal[16][3]={{0,0,0},{255,255,255},{128,128,128},{192,192,192},{200,30,30},{255,120,100},{230,140,30},{255,214,60},{60,180,70},{120,230,140},{30,130,230},{100,200,255},{130,70,200},{220,120,220},{20,200,200},{110,70,40}};
static void clear(void){for(int i=0;i<PW*PH;i++)cv[i]=rgb(8,9,16);}
void paint_init(void){cv=mem_alloc_pages((PW*PH*2+4095)/4096);if(cv)clear();}
static u16 pc(int i){return rgb(pal[i][0],pal[i][1],pal[i][2]);}
static void stamp(int x,int y,u16 c){
    int r=brush;for(int dy=-r;dy<=r;dy++)for(int dx=-r;dx<=r;dx++){
        if(dx*dx+dy*dy>r*r+r/2)continue;int px=x+dx,py=y+dy;if(px>=0&&px<PW&&py>=0&&py<PH)cv[py*PW+px]=c;}
}
static void line(int x0,int y0,int x1,int y1,u16 c){
    int dx=x1>x0?x1-x0:x0-x1,dy=y1>y0?y1-y0:y0-y1,sx=x0<x1?1:-1,sy=y0<y1?1:-1,e=dx-dy;
    for(int g=0;g<2000;g++){stamp(x0,y0,c);if(x0==x1&&y0==y1)break;int e2=2*e;if(e2>-dy){e-=dy;x0+=sx;}if(e2<dx){e+=dx;y0+=sy;}}
}
static void flood(int x,int y,u16 nc){
    if(x<0||y<0||x>=PW||y>=PH)return;u16 old=cv[y*PW+x];if(old==nc)return;
    static short st[6000][2];int sp=0;st[sp][0]=(short)x;st[sp][1]=(short)y;sp++;
    while(sp>0){
        sp--;int cx=st[sp][0],cy=st[sp][1];
        int l=cx;while(l>0&&cv[cy*PW+l-1]==old)l--;
        int r=cx;while(r<PW-1&&cv[cy*PW+r+1]==old)r++;
        for(int i=l;i<=r;i++)cv[cy*PW+i]=nc;
        for(int d=-1;d<=1;d+=2){int ny=cy+d;if(ny<0||ny>=PH)continue;int in=0;
            for(int i=l;i<=r;i++){if(cv[ny*PW+i]==old){if(!in&&sp<5990){st[sp][0]=(short)i;st[sp][1]=(short)ny;sp++;}in=1;}else in=0;}}
    }
}
static void save_bmp(void){
    u32 rowb=(u32)PW*3;rowb=(rowb+3)&~3u;u32 size=54+rowb*PH;
    u8 *b=mem_alloc_pages((size+4095)/4096);if(!b){scpy(pmsg,"Out of memory",sizeof pmsg);pmsg_t=ms_now();return;}
    memset(b,0,54);b[0]='B';b[1]='M';
    #define W32(o,v) do{b[o]=(u8)(v);b[o+1]=(u8)((v)>>8);b[o+2]=(u8)((v)>>16);b[o+3]=(u8)((v)>>24);}while(0)
    W32(2,size);W32(10,54);W32(14,40);W32(18,PW);W32(22,PH);b[26]=1;b[28]=24;W32(34,rowb*PH);
    for(int y=0;y<PH;y++){u8 *r=b+54+(u32)(PH-1-y)*rowb;for(int x=0;x<PW;x++){u16 p=cv[y*PW+x];r[x*3]=(u8)((p&31)<<3);r[x*3+1]=(u8)(((p>>5)&63)<<2);r[x*3+2]=(u8)((p>>11)<<3);}}
    char name[16];scpy(name,"PAINT.BMP",sizeof name);
    for(int i=1;i<100&&fs_find(term_cwd(),name,NULL);i++)ksnprintf(name,sizeof name,"PAINT%d.BMP",i);
    int r=fs_write(term_cwd(),name,b,size);
    if(r)ksnprintf(pmsg,sizeof pmsg,"Save failed: %s",fs_errstr(r));else ksnprintf(pmsg,sizeof pmsg,"Saved %s (%d KB)",name,(int)(size/1024));
    pmsg_t=ms_now();mem_free_pages(b,(size+4095)/4096);
}
static void btn(int x,int y,int w,const char *l,int on){int hv=inside(x,y,w,22,mx,my);roundrect(x,y,w,22,5,on?rgb(34,70,110):hv?rgb(30,48,76):rgb(14,22,38));text16(x+(w-text16w(l))/2,y+3,l,C_TEXT);}
void paint_draw(Window *w){
    window_bg(w);titlebar(w);
    int cx=w->x+10,cy=w->y+68;
    set_clip(w->x,w->y,w->w,w->h);
    int bx=w->x+10,by=w->y+36;
    btn(bx,by,50,"Pen",tool==0);btn(bx+54,by,64,"Eraser",tool==1);btn(bx+122,by,50,"Fill",tool==2);
    btn(bx+186,by,26,"1",brush==1);btn(bx+216,by,26,"3",brush==3);btn(bx+246,by,26,"6",brush==6);
    btn(bx+286,by,56,"Clear",0);btn(bx+346,by,64,"Save BMP",0);
    if(cv){for(int y=0;y<PH;y++)memcpy(drawbuf+(cy+y)*SW+cx,cv+y*PW,PW*2);}
    frame_rect(cx-1,cy-1,PW+2,PH+2,C_LINE);
    for(int i=0;i<16;i++){int x=cx+i*28,y=cy+PH+8;fill(x,y,24,18,pc(i));if(i==color)frame_rect(x-2,y-2,28,22,C_TEXT);}
    if(pmsg[0]&&ms_now()-pmsg_t<4000)text16(cx,cy+PH+30,pmsg,C_YEL);
    clip_reset();
}
static void apply(Window *w,int first){
    int cx=w->x+10,cy=w->y+68,x=mx-cx,y=my-cy;
    if(!cv)return;
    u16 c=tool==1?rgb(8,9,16):pc(color);
    if(tool==2){if(first)flood(x,y,pc(color));return;}
    if(!first&&last_x>=0)line(last_x,last_y,x,y,c);else stamp(x,y,c);
    last_x=x;last_y=y;ui_dirty=1;
}
void paint_click(Window *w){
    int cx=w->x+10,cy=w->y+68,bx=w->x+10,by=w->y+36;
    last_x=-1;
    if(inside(bx,by,50,22,mx,my)){tool=0;return;} if(inside(bx+54,by,64,22,mx,my)){tool=1;return;} if(inside(bx+122,by,50,22,mx,my)){tool=2;return;}
    if(inside(bx+186,by,26,22,mx,my)){brush=1;return;} if(inside(bx+216,by,26,22,mx,my)){brush=3;return;} if(inside(bx+246,by,26,22,mx,my)){brush=6;return;}
    if(inside(bx+286,by,56,22,mx,my)){if(cv)clear();return;}
    if(inside(bx+346,by,64,22,mx,my)){save_bmp();return;}
    for(int i=0;i<16;i++)if(inside(cx+i*28,cy+PH+8,24,18,mx,my)){color=i;if(tool==1)tool=0;return;}
    if(inside(cx,cy,PW,PH,mx,my))apply(w,1);
}
void paint_drag(Window *w){
    int cx=w->x+10,cy=w->y+68;
    if(!(mbuttons&1)){last_x=-1;return;}
    if(tool!=2&&inside(cx,cy,PW,PH,mx,my))apply(w,0);
}
