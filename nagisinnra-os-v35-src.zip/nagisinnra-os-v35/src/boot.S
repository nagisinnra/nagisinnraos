/* Nagisinnra OS boot sector.
   - reads <hdr_total> sectors starting at LBA 1 to 0x1000:0000 (INT13h ext read, CHS fallback)
   - detects RAM (E801 / 88h), sets VBE mode 0x114 (800x600x16 LFB), opens A20, enters 32-bit PM
   - jumps to 0x10000 (kernel).  BootInfo lives at 0x500:
       +0 'NAG5'  +4 KB above 1MB  +8 boot drive  +12 loaded sectors  +16 fs prefix sectors  +20 VBE info ptr */
.code16
.section .text
.global _start
_start:
 jmp boot_start
 nop
 .ascii "NAGIOS35"
 .word 512
 .byte 1
 .word 1
 .byte 2
 .word 224
 .word 2880
 .byte 0xF0
 .word 9
 .word 18
 .word 2
 .long 0
 .long 0
 .byte 0,0,0x29
 .long 0x35353535
 .ascii "NAGISINNRA "
 .ascii "FAT12   "
boot_start:
 cli
 xorw %ax,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%ss
 movw $0x7C00,%sp
 sti
 cld
 movw %dx,drive
 /* clear BootInfo */
 movw $0x500,%di
 movw $16,%cx
 rep stosw
 /* ---- RAM size: KB above 1 MiB -> 0x504 ---- */
 movw $0xE801,%ax
 int $0x15
 jc  1f
 testw %ax,%ax
 jnz 2f
 movw %cx,%ax
 movw %dx,%bx
2: movzwl %ax,%eax
 movzwl %bx,%ebx
 shll $6,%ebx
 addl %ebx,%eax
 jmp 3f
1: movb $0x88,%ah
 int $0x15
 movzwl %ax,%eax
 jnc 3f
 movl $15360,%eax
3: movl %eax,0x504
 /* ---- load kernel + fs prefix ---- */
 movw hdr_total,%cx
 movw $1,%bp
 movw $0x1000,%bx
load_loop:
 pushw %cx
 call read_one
 jc  disk_err
 popw %cx
 incw %bp
 addw $0x20,%bx
 loop load_loop
 /* ---- VBE 0x114 ---- */
 movw $0x9000,%ax
 movw %ax,%es
 xorw %di,%di
 movw $0x4F01,%ax
 movw $0x114,%cx
 int $0x10
 cmpw $0x004F,%ax
 jne vbe_err
 movw $0x4F02,%ax
 movw $0x4114,%bx
 int $0x10
 cmpw $0x004F,%ax
 jne vbe_err
 xorw %ax,%ax
 movw %ax,%es
 /* ---- BootInfo ---- */
 movl $0x3547414E,0x500
 movzbl drive,%eax
 movl %eax,0x508
 movzwl hdr_total,%eax
 movl %eax,0x50C
 movzwl hdr_fs,%eax
 movl %eax,0x510
 movl $0x90000,0x514
 /* ---- protected mode ---- */
 cli
 inb $0x92,%al
 orb $2,%al
 andb $0xFE,%al
 outb %al,$0x92
 lgdt gdt_desc
 movl %cr0,%eax
 orb $1,%al
 movl %eax,%cr0
 ljmp $0x08,$pm_entry

/* read LBA bp into bx:0000, CF=1 on failure */
read_one:
 movw $0x600,%si
 movw $0x0010,(%si)
 movw $1,2(%si)
 movw $0,4(%si)
 movw %bx,6(%si)
 movw %bp,8(%si)
 movl $0,10(%si)
 movw $0,14(%si)
 movb drive,%dl
 movb $0x42,%ah
 int $0x13
 jnc 9f
 /* CHS fallback (1.44 MB floppy geometry) */
 pushw %bx
 movw %bp,%ax
 xorw %dx,%dx
 movw $36,%cx
 divw %cx                 /* ax = cylinder, dx = rem */
 movb %al,%ch
 movw %dx,%ax
 movb $18,%cl
 divb %cl                 /* al = head, ah = sector-1 */
 movb %al,%dh
 movb %ah,%cl
 incb %cl
 movb drive,%dl
 movw %bx,%es
 xorw %bx,%bx
 movw $0x0201,%ax
 int $0x13
 pushf
 xorw %ax,%ax
 movw %ax,%es
 popf
 popw %bx
9: ret

disk_err:
 movb $'D',%al
 jmp fail
vbe_err:
 movb $'V',%al
fail:
 movb $0x0E,%ah
 xorw %bx,%bx
 int $0x10
 cli
1: hlt
 jmp 1b

.align 4
gdt:
 .quad 0
 .word 0xFFFF,0
 .byte 0,0x9A,0xCF,0
 .word 0xFFFF,0
 .byte 0,0x92,0xCF,0
gdt_desc:
 .word 23
 .long gdt
drive: .word 0
.code32
pm_entry:
 movw $0x10,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%fs
 movw %ax,%gs
 movw %ax,%ss
 movl $0x9F000,%esp
 movl $0x10000,%eax
 jmp *%eax
.org 0x1F0
hdr_total: .word 0
hdr_fs:    .word 0
.org 510
 .word 0xAA55
