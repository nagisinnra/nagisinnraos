#include "wm.h"
Window win[NAPPS];
int active=0,start_menu=0,zorder[NAPPS];
int ui_dirty;
static int zseq;

static void setw(int id,int x,int y,int w,int h,const char *title,int resizable,int minw,int minh){
    Window *p=&win[id];memset(p,0,sizeof *p);
    p->x=x;p->y=y;p->w=w;p->h=h;p->app=(u8)id;scpy(p->title,title,sizeof p->title);
    p->resizable=resizable;p->minw=minw;p->minh=minh;
}
void wm_init(void){
    zseq=0;for(int i=0;i<NAPPS;i++)zorder[i]=i;
    setw(APP_TERM,36,56,660,420,"Terminal",1,320,200);
    setw(APP_FILES,150,80,560,400,"Files",1,380,240);
    setw(APP_EDIT,110,50,620,460,"Editor",1,360,220);
    setw(APP_PAINT,180,70,500,400,"Paint",0,0,0);
    setw(APP_TASKS,230,90,440,400,"System",1,380,300);
    setw(APP_BROWSER,16,30,768,544,"Browser",1,420,260);
    setw(APP_TETRIS,335,105,300,420,"Tetris",0,0,0);
    setw(APP_SNAKE,55,85,350,430,"Snake",0,0,0);
    setw(APP_MINES,190,70,420,470,"Mines",0,0,0);
    setw(APP_BREAKOUT,150,85,500,430,"Breakout",0,0,0);
    setw(APP_GAMES,145,72,510,500,"Games",0,0,0);
    setw(APP_ARCADE,145,72,510,500,"Game",0,0,0);
    win[APP_TERM].open=1;active=APP_TERM;
}
void raise_window(int id){ if(id>=0&&id<NAPPS)zorder[id]=++zseq; }
void open_app(int id){
    win[id].open=1;active=id;raise_window(id);start_menu=0;
    if(id==APP_BROWSER)browser_home();
}
int top_at(int x,int y){
    int best=-1,bz=-1;
    for(int i=0;i<NAPPS;i++)if(win[i].open&&inside(win[i].x,win[i].y,win[i].w,win[i].h,x,y)&&zorder[i]>bz){bz=zorder[i];best=i;}
    return best;
}
void toggle_max(int id){
    Window *w=&win[id];if(!w->resizable)return;
    if(!w->max){w->sx=w->x;w->sy=w->y;w->sw=w->w;w->sh=w->h;w->x=0;w->y=0;w->w=SW;w->h=578;w->max=1;}
    else{w->x=w->sx;w->y=w->sy;w->w=w->sw;w->h=w->sh;w->max=0;}
    if(id==APP_BROWSER)browser_resized(w);
}
void titlebar(Window *w){
    int on=(&win[active]==w)&&active>=0;
    u16 bar=on?rgb(18,28,52):rgb(13,18,34);
    roundrect(w->x,w->y,w->w,30,7,bar);
    fill(w->x+7,w->y,w->w-14,15,bar);
    fill(w->x+10,w->y+27,w->w-20,2,on?rgb(55,180,220):rgb(40,70,96));
    set_clip(w->x+10,w->y,w->w-80,30);
    text16n(w->x+14,w->y+6,w->title,(int)strlen(w->title),on?C_TEXT:C_DIM,TF_BOLD*0);
    set_clip(w->x-2,w->y-2,w->w+4,w->h+4);
    roundrect(w->x+w->w-58,w->y+9,10,10,5,w->resizable?rgb(70,110,90):rgb(55,65,88));
    roundrect(w->x+w->w-40,w->y+9,10,10,5,w->resizable?rgb(110,150,230):rgb(75,90,118));
    roundrect(w->x+w->w-22,w->y+7,14,14,5,rgb(220,48,64));
    fill(w->x+w->w-19,w->y+10,2,8,rgb(255,255,255));
    fill(w->x+w->w-19,w->y+10,8,2,rgb(255,255,255));
}
void window_bg(Window *w){
    roundrect(w->x,w->y+25,w->w,w->h-25,8,rgb(9,13,24));
    fill(w->x+7,w->y+30,w->w-14,w->h-37,C_BG0);
    fill(w->x,w->y+31,1,w->h-38,C_LINE);
    fill(w->x+w->w-1,w->y+31,1,w->h-38,C_LINE);
    if(w->resizable){ for(int i=0;i<3;i++)fill(w->x+w->w-5-i*4,w->y+w->h-5,2,2,rgb(70,90,120)),fill(w->x+w->w-5,w->y+w->h-5-i*4,2,2,rgb(70,90,120)); }
}
static void draw_one(Window *w){
    set_clip(w->x-2,w->y-2,w->w+4,w->h+4);
    if(w->app<=APP_BROWSER){window_bg(w);titlebar(w);}
    switch(w->app){
    case APP_TERM:term_draw(w);break;case APP_FILES:files_draw(w);break;case APP_EDIT:editor_draw(w);break;
    case APP_PAINT:paint_draw(w);break;case APP_TASKS:sys_draw(w);break;case APP_BROWSER:browser_draw(w);break;
    case APP_TETRIS:draw_tetris(w);break;case APP_SNAKE:draw_snake(w);break;case APP_MINES:draw_mines(w);break;
    case APP_BREAKOUT:draw_breakout(w);break;case APP_GAMES:draw_games(w);break;case APP_ARCADE:draw_arcade(w);break;
    }
    clip_reset();
}
/* ---------- taskbar ---------- */
static int clock_h=-1,clock_m,clock_ms_last;
static const char *tb_names[]={"Term","Files","Edit","Paint","System","Web","Games"};
static const int tb_ids[]={0,1,2,3,4,5,10};
static const int tb_w[]={48,52,46,52,62,44,56};
void taskbar_draw(void){
    fill(0,578,SW,22,rgb(6,9,18));fill(0,578,SW,1,rgb(48,65,92));
    roundrect(10,580,28,18,5,start_menu?rgb(34,54,82):rgb(17,28,47));
    text(19,586,"N",start_menu?rgb(120,235,255):rgb(90,210,255),1);
    int x=42;
    for(int k=0;k<7;k++){
        int id=tb_ids[k],ww=tb_w[k];int on=(active==id&&win[id].open);
        roundrect(x,580,ww,18,5,on?rgb(30,46,72):rgb(8,11,20));
        if(on)fill(x+6,580,ww-12,2,rgb(65,200,235));
        if(win[id].open&&!on)fill(x+ww/2-3,596,6,1,rgb(90,120,150));
        text(x+8,586,tb_names[k],on?rgb(242,246,255):rgb(155,170,198),1);
        x+=ww+4;
    }
    /* network indicator + clock */
    u32 now=ms_now();
    if(clock_h<0||now-(u32)clock_ms_last>=1000){int y,mo,d,s;rtc_read(&y,&mo,&d,&clock_h,&clock_m,&s);clock_ms_last=(int)now;}
    u16 nc=net_state>=NET_UP_DHCP?rgb(105,225,170):net_state==NET_DHCP?rgb(240,200,90):rgb(230,90,100);
    roundrect(660,580,128,18,5,rgb(8,11,20));
    roundrect(668,586,7,7,3,nc);
    text(680,586,net_state>=NET_UP_DHCP?"NET":net_state==NET_DHCP?"DHCP":"NO NET",rgb(150,165,195),1);
    char t[8];ksnprintf(t,sizeof t,"%02d:%02d",clock_h,clock_m);
    text(738,586,t,rgb(215,225,245),1);
}
int taskbar_click(void){
    if(my<578)return 0;
    if(mx>=10&&mx<38){start_menu=!start_menu;return 1;}
    int x=42;
    for(int k=0;k<7;k++){
        int ww=tb_w[k];
        if(mx>=x&&mx<x+ww){
            int id=tb_ids[k];start_menu=0;
            if(win[id].open&&active==id){win[id].open=0;active=-1;  /* minimise */
                int best=-1,bz=-1;for(int i=0;i<NAPPS;i++)if(win[i].open&&zorder[i]>bz){bz=zorder[i];best=i;}active=best;}
            else open_app(id);
            return 1;
        }
        x+=ww+4;
    }
    return 1;
}
/* ---------- start menu ---------- */
static const char *sm_names[]={"TERMINAL","FILES","EDITOR","PAINT","SYSTEM","BROWSER","GAMES"};
static const char *sm_icons[]={"T","F","E","P","S","W","G"};
static void start_menu_draw(void){
    if(!start_menu)return;
    roundrect(10,258,340,310,10,rgb(8,12,23));
    fill(18,266,324,2,rgb(55,180,220));
    text(28,278,"NAGISINNRA",rgb(238,242,252),1);
    text(28,292,"START",rgb(100,255,180),1);
    for(int i=0;i<7;i++){
        int col=(i<6)?(i&1):0,row=(i<6)?(i>>1):3;
        int x=22+col*158,y=312+row*45,ww=(i<6)?150:316;
        int hover=inside(x,y,ww,36,mx,my);
        roundrect(x,y,ww,36,6,hover?rgb(25,42,65):rgb(10,15,28));
        roundrect(x+8,y+7,22,22,5,hover?rgb(38,68,96):rgb(18,28,43));
        text(x+15,y+13,sm_icons[i],hover?rgb(245,248,255):rgb(120,210,235),1);
        text(x+40,y+13,sm_names[i],hover?rgb(245,248,255):rgb(170,185,210),1);
    }
    fill(22,508,316,1,rgb(30,42,62));
    char v[40];ksnprintf(v,sizeof v,"NAGISINNRA OS V%s",VERSION_STR);
    text(28,522,v,rgb(120,150,190),1);
    int hv=inside(236,534,102,24,mx,my);
    roundrect(236,534,102,24,6,hv?rgb(90,40,52):rgb(40,22,30));
    text(252,542,"RESTART",hv?rgb(255,230,235):rgb(230,150,165),1);
    text(28,542,"F1-F6 APPS",rgb(90,110,140),1);
}
int start_menu_click(void){
    if(!start_menu)return 0;
    if(inside(236,534,102,24,mx,my)){do_reboot();return 1;}
    if(mx>=20&&mx<338&&my>=312&&my<447){
        int col=(mx>=180)?1:0,row=(my-312)/45,k=row*2+col;
        if(row>=0&&row<3&&k<6){static const int ids[]={0,1,2,3,4,5};open_app(ids[k]);return 1;}
    }
    if(mx>=20&&mx<338&&my>=447&&my<483){open_app(APP_GAMES);return 1;}
    if(!(mx>=10&&mx<350&&my>=258&&my<568)){start_menu=0;return 1;}
    return 1;
}
static const u16 cur_mask[16]={0x8000,0xC000,0xE000,0xF000,0xF800,0xFC00,0xFE00,0xFF00,0xF800,0xD800,0xCC00,0xC600,0xC300,0x0180,0x0180,0x0000};
static int cur_ox=-100,cur_oy=-100;          /* where the cursor is currently painted on the LFB */
static inline u16 *fbrow(int y){return (u16*)((u32)fb_phys+(u32)y*fb_pitch);}
static void cursor_restore(void){
    if(cur_ox<-50)return;
    for(int y=cur_oy-1;y<cur_oy+17;y++){
        if(y<0||y>=SH)continue;
        int x0=cur_ox-1,x1=cur_ox+17;if(x0<0)x0=0;if(x1>SW)x1=SW;
        if(x1>x0)memcpy(fbrow(y)+x0,BACKBUF+y*SW+x0,(u32)(x1-x0)*2);
    }
    cur_ox=-100;
}
static void cursor_paint(void){
    u16 dark=rgb(5,8,16),light=rgb(245,249,255);
    for(int y=0;y<16;y++){
        int yy=my+y;if(yy<0||yy>=SH)continue;u16 *row=fbrow(yy);
        for(int x=0;x<16;x++)if(cur_mask[y]&(0x8000u>>x)){
            int xx=mx+x;
            if(xx>0&&xx-1<SW&&!(x>0&&(cur_mask[y]&(0x8000u>>(x-1)))))row[xx-1]=dark;
            if(xx<SW&&xx>=0)row[xx]=light;
        }
    }
    cur_ox=mx;cur_oy=my;
}
void cursor_move_fast(void){ if(mx==cur_ox&&my==cur_oy)return; cursor_restore(); cursor_paint(); }
void cursor_draw(void){ cursor_restore(); cursor_paint(); }
void redraw(void){
    drawbuf=BACKBUF;clip_reset();
    copy_sky();
    text(20,18,"NAGISINNRA",rgb(225,231,248),1);
    char v[8];ksnprintf(v,sizeof v,"V%s",VERSION_STR);text(752,18,v,rgb(135,160,205),1);
    int drawn[NAPPS];memset(drawn,0,sizeof drawn);
    for(int rank=0;rank<NAPPS;rank++){
        int best=-1,bz=0x7fffffff;
        for(int i=0;i<NAPPS;i++)if(win[i].open&&!drawn[i]&&zorder[i]<bz){bz=zorder[i];best=i;}
        if(best<0)break;drawn[best]=1;draw_one(&win[best]);
    }
    taskbar_draw();start_menu_draw();
    present();cur_ox=-100;cursor_paint();
}
void do_reboot(void){
    outb(0x64,0xFE);
    for(volatile int i=0;i<1000000;i++);
    outb(0xCF9,0x06);
    for(;;)__asm__ volatile("hlt");
}
