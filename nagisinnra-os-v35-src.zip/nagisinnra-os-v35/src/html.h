#ifndef HTML_H
#define HTML_H
#include "nagi.h"
#define ST_BOLD 1
#define ST_LINK 2
#define ST_HEAD 4
#define ST_DIM 8
#define ST_CODE 16
typedef struct {
    u16 *cp; u16 *lk; u8 *st; u32 ncells,ccap;
    u32 *ls; u16 *ll; u32 nlines,lcap;
    char *pool; u32 pool_len,pool_cap;
    u32 *lkoff; u32 nlinks,lkcap;
    char title[80]; int truncated;
} Page;
enum {CS_UTF8=0,CS_LATIN1,CS_SJIS,CS_EUC};
void page_reset(Page *p);
int html_charset(const u8 *src,int len,const char *ctype);
void page_layout(Page *p,const u8 *src,int len,int cols,int is_html,int charset);
const char *page_link(Page *p,int lk);              /* lk is 1-based id from a cell */
#endif
