#include "html.h"
#include "gfx.h"
extern const unsigned short font_jis_uni[40][94];
typedef struct { const char *name; u16 cp; } Ent;
static const Ent ents[]={
{"amp",'&'},{"lt",'<'},{"gt",'>'},{"quot",'"'},{"apos",'\''},{"nbsp",0xA0},{"copy",0xA9},{"reg",0xAE},{"hellip",0x2026},
{"mdash",0x2014},{"ndash",0x2013},{"laquo",0xAB},{"raquo",0xBB},{"bull",0x2022},{"middot",0xB7},{"lsquo",0x2018},{"rsquo",0x2019},
{"ldquo",0x201C},{"rdquo",0x201D},{"yen",0xA5},{"euro",0x20AC},{"larr",0x2190},{"uarr",0x2191},{"rarr",0x2192},{"darr",0x2193},
{"times",0xD7},{"deg",0xB0},{"trade",0x2122},{"para",0xB6},{"sect",0xA7},{"pound",0xA3},{"cent",0xA2},{"plusmn",0xB1},{"frac12",0xBD},
{"agrave",0xE0},{"aacute",0xE1},{"acirc",0xE2},{"atilde",0xE3},{"auml",0xE4},{"aring",0xE5},{"ccedil",0xE7},{"egrave",0xE8},{"eacute",0xE9},
{"ecirc",0xEA},{"euml",0xEB},{"igrave",0xEC},{"iacute",0xED},{"icirc",0xEE},{"iuml",0xEF},{"ntilde",0xF1},{"ograve",0xF2},{"oacute",0xF3},
{"ocirc",0xF4},{"otilde",0xF5},{"ouml",0xF6},{"ugrave",0xF9},{"uacute",0xFA},{"ucirc",0xFB},{"uuml",0xFC},{"szlig",0xDF},{"Auml",0xC4},
{"Ouml",0xD6},{"Uuml",0xDC},{"Eacute",0xC9},{"iexcl",0xA1},{"iquest",0xBF},{"hearts",0x2665},{"check",0x2713},
{0,0}};

void page_reset(Page *p){p->ncells=0;p->nlines=0;p->pool_len=0;p->nlinks=0;p->title[0]=0;p->truncated=0;}
const char *page_link(Page *p,int lk){ if(lk<1||(u32)lk>p->nlinks)return NULL; return p->pool+p->lkoff[lk-1]; }

/* ---------- charset ---------- */
static int cs_from_name(const char *n){
    if(!strnicmp(n,"utf-8",5)||!strnicmp(n,"utf8",4))return CS_UTF8;
    if(!strnicmp(n,"shift_jis",9)||!strnicmp(n,"shift-jis",9)||!strnicmp(n,"x-sjis",6)||!strnicmp(n,"sjis",4)||!strnicmp(n,"windows-31j",11)||!strnicmp(n,"cp932",5)||!strnicmp(n,"ms932",5))return CS_SJIS;
    if(!strnicmp(n,"euc-jp",6)||!strnicmp(n,"x-euc-jp",8)||!strnicmp(n,"eucjp",5))return CS_EUC;
    if(!strnicmp(n,"iso-8859",8)||!strnicmp(n,"windows-125",11)||!strnicmp(n,"latin",5)||!strnicmp(n,"us-ascii",8))return CS_LATIN1;
    return -1;
}
int html_charset(const u8 *src,int len,const char *ctype){
    const char *c=ctype?stristr(ctype,"charset="):NULL;
    if(c){int r=cs_from_name(c+8+(c[8]=='"'?1:0));if(r>=0)return r;}
    int n=len<3000?len:3000;
    for(int i=0;i+8<n;i++){
        if(!strnicmp((const char*)src+i,"charset=",8)){
            const char *q=(const char*)src+i+8;while(*q=='"'||*q=='\''||*q==' ')q++;
            int r=cs_from_name(q);if(r>=0)return r;
        }
    }
    /* sniff: valid UTF-8 multibyte sequences => UTF-8, else Latin-1 */
    int multi=0,bad=0;
    for(int i=0;i<len&&i<4000;i++){
        u8 b=src[i];if(b<0x80)continue;
        int need=(b&0xE0)==0xC0?1:(b&0xF0)==0xE0?2:(b&0xF8)==0xF0?3:-1;
        if(need<0){bad=1;break;}
        for(int k=1;k<=need;k++)if(i+k>=len||(src[i+k]&0xC0)!=0x80){bad=1;break;}
        if(bad)break;multi++;i+=need;
    }
    return bad?CS_LATIN1:CS_UTF8;
}
static u32 jis2uni(int row,int col){
    int ri=(row>=1&&row<=8)?row-1:(row>=16&&row<=47)?row-16+8:-1;
    if(ri<0||col<1||col>94)return '?';
    u32 u=font_jis_uni[ri][col-1];return u?u:0x3013;
}
/* decode one code point from s[*i..n) */
static u32 dec(const u8 *s,int n,int *i,int cs){
    u32 b=s[*i];
    if(cs==CS_UTF8){
        if(b<0x80){(*i)++;return b;}
        const char *p=(const char*)s+*i;
        /* utf8_next reads up to 3 more bytes: make sure they exist */
        if(*i+3>=n){(*i)++;return b;}
        const char *q=p;u32 cp=utf8_next(&q);*i+=(int)(q-p);return cp;
    }
    if(cs==CS_LATIN1){(*i)++;
        if(b>=0x80&&b<0xA0){static const u16 w[32]={0x20AC,'?',0x201A,0x192,0x201E,0x2026,0x2020,0x2021,0x2C6,0x2030,0x160,0x2039,0x152,'?',0x17D,'?','?',0x2018,0x2019,0x201C,0x201D,0x2022,0x2013,0x2014,0x2DC,0x2122,0x161,0x203A,0x153,'?',0x17E,0x178};return w[b-0x80];}
        return b;}
    if(cs==CS_EUC){
        if(b==0x8E&&*i+1<n){u32 c=s[*i+1];*i+=2;return (c>=0xA1&&c<=0xDF)?0xFF61+(c-0xA1):'?';}
        if(b>=0xA1&&b<=0xFE&&*i+1<n){u32 c=s[*i+1];*i+=2;return jis2uni((int)b-0xA0,(int)c-0xA0);}
        (*i)++;return b<0x80?b:'?';
    }
    /* Shift_JIS */
    if(b<0x80){(*i)++;return b==0x5C?0x5C:b;}
    if(b>=0xA1&&b<=0xDF){(*i)++;return 0xFF61+(b-0xA1);}
    if(((b>=0x81&&b<=0x9F)||(b>=0xE0&&b<=0xFC))&&*i+1<n){
        int c1=(int)b,c2=s[*i+1];*i+=2;
        c1-=(c1<=0x9F)?0x71:0xB1;c1=c1*2+1;
        if(c2>0x7F)c2--;
        if(c2>=0x9E){c2-=0x7D;c1++;}else c2-=0x1F;
        return jis2uni(c1-0x20,c2-0x20);
    }
    (*i)++;return '?';
}

/* ---------- layout state ---------- */
typedef struct { u16 cp; u16 lk; u8 st; u8 w; } WCell;
static Page *P;
static int cols,indent,col,line_len,pending_space,want_blank,last_blank,pre,li_pending;
static char li_marker[8];
static int wn,ww;static WCell word[120];
static u8 cur_st;static u16 cur_lk;
static int ol_n[8],ol_type[8];  /* ol_type 0=ul 1=ol */
static int lstack;
static int in_title,td_first;

static int room(void){return P->ncells+250<P->ccap&&P->nlines+4<P->lcap;}
static void put_cell(u16 cp,u8 st,u16 lk){
    if(P->ncells>=P->ccap){P->truncated=1;return;}
    P->cp[P->ncells]=cp;P->st[P->ncells]=st;P->lk[P->ncells]=lk;P->ncells++;line_len++;
}
static void end_line(void){
    if(P->nlines>=P->lcap){P->truncated=1;return;}
    u32 start=P->ncells-(u32)line_len;
    P->ls[P->nlines]=start;P->ll[P->nlines]=(u16)line_len;P->nlines++;
    last_blank=(line_len==0);
    line_len=0;col=0;
}
static void start_line(void){
    /* called before first cell of a line */
    for(int i=0;i<indent;i++)put_cell(' ',0,0);
    col=indent;
    if(li_pending){
        int ml=(int)strlen(li_marker);
        u32 base=P->ncells-(u32)line_len;
        if(indent>=ml&&P->ncells>=base+ (u32)indent){
            for(int k=0;k<ml;k++){u32 pos=base+(u32)(indent-ml+k);
                const char*m=li_marker;u32 cp=(u8)m[k];if(cp==1)cp=0x2022;
                P->cp[pos]=(u16)cp;P->st[pos]=ST_DIM;}
        }
        li_pending=0;
    }
}
static void flush_word(void){
    if(!wn)return;
    if(!room()){P->truncated=1;wn=0;ww=0;return;}
    if(line_len==0){
        if(want_blank){ if(P->nlines>0&&!last_blank)end_line(); want_blank=0; }
        start_line();
    }
    int sp=(pending_space&&col>indent)?1:0;
    if(col+sp+ww>cols&&col>indent){end_line();start_line();sp=0;}
    if(sp){u16 lkp=(line_len>0&&P->lk[P->ncells-1]==word[0].lk)?word[0].lk:0;put_cell(' ',lkp?word[0].st:0,lkp);col++;}
    pending_space=0;
    for(int i=0;i<wn;i++){
        if(col+word[i].w>cols&&col>indent){end_line();start_line();}
        put_cell(word[i].cp,word[i].st,word[i].lk);col+=word[i].w;
    }
    wn=0;ww=0;
}
static void block_break(int blank){
    flush_word();pending_space=0;
    if(line_len>0)end_line();
    if(blank)want_blank=1;
}
static void hard_newline(void){
    flush_word();pending_space=0;
    if(line_len==0){ if(want_blank){ if(P->nlines>0&&!last_blank)end_line(); want_blank=0;} start_line(); }
    end_line();
}
static void add_word_cell(u32 cp){
    int w=cp_width(cp)>8?2:1;
    if(cp>0xFFFF)cp='?';
    if(wn>=118)flush_word();
    word[wn].cp=(u16)cp;word[wn].st=cur_st;word[wn].lk=cur_lk;word[wn].w=(u8)w;wn++;ww+=w;
}
static void text_cp(u32 cp){
    if(in_title){int l=(int)strlen(P->title);if(l<76&&cp>=0x20){char b[4];int n=utf8_encode(cp,b);if(l+n<78){memcpy(P->title+l,b,n);P->title[l+n]=0;}}return;}
    if(pre){
        if(cp=='\r')return;
        if(cp=='\n'){hard_newline();return;}
        if(cp=='\t'){int n=8-((col-indent)&7);for(int i=0;i<n;i++){flush_word();if(line_len==0){if(want_blank){if(P->nlines>0&&!last_blank)end_line();want_blank=0;}start_line();}
            if(col+1>cols){end_line();start_line();}put_cell(' ',cur_st,0);col++;}return;}
        if(line_len==0){ if(want_blank){ if(P->nlines>0&&!last_blank)end_line(); want_blank=0;} start_line(); }
        int w=cp_width(cp)>8?2:1;if(col+w>cols){end_line();start_line();}
        if(!room())return;
        put_cell((u16)(cp>0xFFFF?'?':cp),cur_st|ST_CODE,cur_lk);col+=w;return;
    }
    if(cp==' '||cp=='\t'||cp=='\n'||cp=='\r'||cp=='\f'||cp==0x3000){flush_word();pending_space=1;return;}
    if(cp==0xA0)cp=' ',cur_st|=0;
    if(cp>=0x2E80){ /* CJK: may break anywhere, no spaces between */
        int ps=pending_space;flush_word();pending_space=ps;
        add_word_cell(cp);flush_word();return;
    }
    add_word_cell(cp);
}
static void text_str(const char *s){while(*s)text_cp((u8)*s++);}

/* ---------- tags ---------- */
static int add_link(const char *href){
    if(P->nlinks>=P->lkcap||P->pool_len+strlen(href)+2>=P->pool_cap)return 0;
    P->lkoff[P->nlinks]=P->pool_len;
    scpy(P->pool+P->pool_len,href,(int)(P->pool_cap-P->pool_len));
    P->pool_len+=(u32)strlen(href)+1;P->nlinks++;return (int)P->nlinks;
}
static u32 ent_decode(const u8 *s,int n,int *i){   /* s[*i]=='&' */
    int j=*i+1;
    if(j<n&&s[j]=='#'){
        j++;u32 v=0;int hex=0;
        if(j<n&&(s[j]=='x'||s[j]=='X')){hex=1;j++;}
        int any=0;
        while(j<n){u8 c=s[j];int d;
            if(c>='0'&&c<='9')d=c-'0';else if(hex&&c>='a'&&c<='f')d=c-'a'+10;else if(hex&&c>='A'&&c<='F')d=c-'A'+10;else break;
            v=v*(hex?16:10)+(u32)d;any=1;j++;if(v>0x10FFFF)break;}
        if(any){if(j<n&&s[j]==';')j++;*i=j;return v?v:'?';}
        return 0;
    }
    char nm[12];int k=0;
    while(j<n&&k<10&&((s[j]>='a'&&s[j]<='z')||(s[j]>='A'&&s[j]<='Z')||(s[j]>='0'&&s[j]<='9'))){nm[k++]=(char)s[j++];}
    nm[k]=0;
    if(!k)return 0;
    for(const Ent *e=ents;e->name;e++)if(!strcmp(e->name,nm)){if(j<n&&s[j]==';')j++;*i=j;return e->cp;}
    return 0;
}
static void attr_get(const char *tag,const char *name,char *out,int cap){
    out[0]=0;int nl=(int)strlen(name);const char *p=tag;
    while(*p){
        while(*p&&(*p==' '||*p=='\t'||*p=='\n'||*p=='\r'||*p=='/'))p++;
        const char *ns=p;while(*p&&*p!='='&&*p!=' '&&*p!='>'&&*p!='\n'&&*p!='\t'&&*p!='/')p++;
        int len=(int)(p-ns);
        while(*p==' ')p++;
        char val[320];int vl=0;
        if(*p=='='){
            p++;while(*p==' ')p++;
            if(*p=='"'||*p=='\''){char q=*p++;while(*p&&*p!=q){if(vl<(int)sizeof val-1)val[vl++]=*p;p++;}if(*p)p++;}
            else while(*p&&*p!=' '&&*p!='>'&&*p!='\n'&&*p!='\t'){if(vl<(int)sizeof val-1)val[vl++]=*p;p++;}
        }
        val[vl]=0;
        if(len==nl&&!strnicmp(ns,name,(u32)nl)){
            /* decode entities in-place (&amp; mostly) */
            int o=0;for(int k=0;val[k]&&o<cap-1;){
                if(val[k]=='&'){int ii=0;u32 cp=ent_decode((const u8*)val+k,(int)strlen(val+k),&ii);if(cp&&cp<0x80){out[o++]=(char)cp;k+=ii;continue;}}
                out[o++]=val[k++];}
            out[o]=0;return;
        }
        if(!len)p++;
    }
}
static void ensure_marker(int ordered,int n){
    if(ordered)ksnprintf(li_marker,sizeof li_marker,"%d. ",n);else scpy(li_marker,"\x01 ",sizeof li_marker);
}
static void do_tag(const char *name,int closing,const char *attrs){
    #define IS(x) (!strcmp(name,x))
    char tmp[320];
    if(IS("br")){hard_newline();return;}
    if(IS("p")||IS("div")||IS("section")||IS("article")||IS("header")||IS("footer")||IS("main")||IS("nav")||IS("aside")||IS("form")||IS("center")||IS("address")||IS("figure")||IS("fieldset")){
        block_break(IS("p")&&!closing);return;}
    if(name[0]=='h'&&name[1]>='1'&&name[1]<='6'&&!name[2]){
        block_break(1);
        if(!closing){cur_st|=ST_BOLD|ST_HEAD;}else{cur_st&=(u8)~(ST_BOLD|ST_HEAD);}
        return;}
    if(IS("b")||IS("strong")||IS("th")){ if(IS("th")){ if(!closing){ if(!td_first){text_cp(' ');text_cp(' ');} td_first=0; cur_st|=ST_BOLD;} else cur_st&=(u8)~ST_BOLD; return;} if(closing)cur_st&=(u8)~ST_BOLD;else cur_st|=ST_BOLD;return;}
    if(IS("i")||IS("em")||IS("cite")||IS("u")||IS("small")||IS("big")||IS("span")||IS("font")||IS("abbr")||IS("sup")||IS("sub")||IS("label")||IS("mark"))return;
    if(IS("code")||IS("tt")||IS("kbd")||IS("samp")||IS("var")){return;}
    if(IS("a")){
        if(closing){cur_lk=0;cur_st&=(u8)~ST_LINK;return;}
        attr_get(attrs,"href",tmp,sizeof tmp);
        if(tmp[0]){int id=add_link(tmp);cur_lk=(u16)id;if(id)cur_st|=ST_LINK;}
        return;}
    if(IS("ul")||IS("ol")||IS("menu")||IS("dir")){
        block_break(!closing&&lstack==0);
        if(!closing){if(lstack<7){lstack++;ol_type[lstack]=IS("ol");ol_n[lstack]=1;indent+=4;}}
        else if(lstack>0){lstack--;indent-=4;if(indent<0)indent=0;}
        if(closing&&lstack==0)want_blank=1;
        return;}
    if(IS("li")){
        if(closing)return;
        block_break(0);
        if(lstack>0){ensure_marker(ol_type[lstack],ol_n[lstack]);ol_n[lstack]++;}else scpy(li_marker,"\x01 ",sizeof li_marker);
        li_pending=1;return;}
    if(IS("dl")){block_break(!closing);return;}
    if(IS("dt")){block_break(0);if(!closing)cur_st|=ST_BOLD;else cur_st&=(u8)~ST_BOLD;return;}
    if(IS("dd")){block_break(0);if(!closing)indent+=4;else{indent-=4;if(indent<0)indent=0;}return;}
    if(IS("blockquote")){block_break(1);if(!closing)indent+=4;else{indent-=4;if(indent<0)indent=0;}return;}
    if(IS("pre")||IS("listing")||IS("xmp")||IS("plaintext")){block_break(1);pre=!closing;if(closing)want_blank=1;return;}
    if(IS("hr")){
        block_break(0);
        if(line_len==0){start_line();}
        int n=cols-indent;u8 sv=cur_st;cur_st=ST_DIM;
        for(int i=0;i<n&&room();i++){put_cell('-',ST_DIM,0);col++;}
        cur_st=sv;end_line();want_blank=1;return;}
    if(IS("table")){block_break(1);return;}
    if(IS("tr")){block_break(0);td_first=1;return;}
    if(IS("td")){ if(!closing){ if(!td_first){flush_word();text_cp(' ');text_cp(' ');} td_first=0; } return;}
    if(IS("caption")){block_break(0);return;}
    if(IS("img")){
        if(closing)return;
        attr_get(attrs,"alt",tmp,sizeof tmp);
        u8 sv=cur_st;cur_st|=ST_DIM;
        text_cp('[');if(tmp[0])text_str(tmp);else text_str("img");text_cp(']');
        cur_st=sv;pending_space=1;return;}
    if(IS("input")||IS("button")){
        if(closing)return;
        char ty[24];attr_get(attrs,"type",ty,sizeof ty);
        if(!stricmp(ty,"hidden"))return;
        attr_get(attrs,"value",tmp,sizeof tmp);
        u8 sv=cur_st;cur_st|=ST_DIM;
        text_cp('[');
        if(!stricmp(ty,"submit")||!stricmp(ty,"button")||IS("button")){text_str(tmp[0]?tmp:"OK");}
        else text_str(tmp[0]?tmp:"____");
        text_cp(']');cur_st=sv;pending_space=1;return;}
    if(IS("title")){in_title=!closing;return;}
    #undef IS
}
void page_layout(Page *pg,const u8 *src,int n,int ncols,int is_html,int cs){
    P=pg;page_reset(pg);
    cols=ncols<10?10:ncols;indent=0;col=0;line_len=0;pending_space=0;want_blank=0;last_blank=1;pre=0;li_pending=0;
    wn=0;ww=0;cur_st=0;cur_lk=0;lstack=0;in_title=0;td_first=1;
    int i=0;
    if(!is_html){
        pre=1;
        while(i<n&&room()){u32 cp=dec(src,n,&i,cs);text_cp(cp);}
        flush_word();if(line_len>0)end_line();
        return;
    }
    while(i<n&&room()){
        u8 b=src[i];
        if(b=='<'&&i+1<n){
            u8 c=src[i+1];
            if(c=='!'){
                if(i+3<n&&src[i+2]=='-'&&src[i+3]=='-'){int j=i+4;while(j+2<n&&!(src[j]=='-'&&src[j+1]=='-'&&src[j+2]=='>'))j++;i=j+3;continue;}
                int j=i+2;while(j<n&&src[j]!='>')j++;i=j+1;continue;
            }
            if(c=='?'){int j=i+2;while(j<n&&src[j]!='>')j++;i=j+1;continue;}
            int closing=(c=='/');int j=i+1+closing;
            if((src[j]>='a'&&src[j]<='z')||(src[j]>='A'&&src[j]<='Z')){
                char name[16];int k=0;
                while(j<n&&k<15&&((src[j]>='a'&&src[j]<='z')||(src[j]>='A'&&src[j]<='Z')||(src[j]>='0'&&src[j]<='9'))){name[k++]=(char)ktolower(src[j]);j++;}
                name[k]=0;
                char attrs[400];int al=0;char q=0;
                while(j<n){
                    u8 ch=src[j];
                    if(q){if(ch==(u8)q)q=0;}else if(ch=='"'||ch=='\'')q=(char)ch;else if(ch=='>')break;
                    if(al<(int)sizeof attrs-1)attrs[al++]=(char)ch;j++;
                }
                attrs[al]=0;i=j+1;
                if(!closing&&(!strcmp(name,"script")||!strcmp(name,"style")||!strcmp(name,"svg")||!strcmp(name,"iframe")||!strcmp(name,"select")||!strcmp(name,"textarea")||!strcmp(name,"object")||!strcmp(name,"noembed"))){
                    char endt[16];ksnprintf(endt,sizeof endt,"</%s",name);
                    int el=(int)strlen(endt);
                    while(i<n&&strnicmp((const char*)src+i,endt,(u32)el))i++;
                    while(i<n&&src[i]!='>')i++;i++;continue;
                }
                do_tag(name,closing,attrs);
                continue;
            }
        }
        if(b=='&'){
            int ii=i;u32 cp=ent_decode(src,n,&ii);
            if(cp){i=ii;text_cp(cp);continue;}
        }
        u32 cp=dec(src,n,&i,cs);
        text_cp(cp);
    }
    flush_word();if(line_len>0)end_line();
}
