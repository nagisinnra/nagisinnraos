#include "nagi.h"
/* Physical page allocator over [MEM_BASE, top). Bitmap lives in BSS. */
#define MEM_BASE 0x00600000u
#define PAGE 4096u
#define MAXPAGES 15360u            /* up to 60 MiB managed */
static u8 bitmap[MAXPAGES/8];
static u32 npages, used;
void mem_init(u32 top){
    if(top<0x01000000u)top=0x01000000u;
    if(top>MEM_BASE+MAXPAGES*PAGE)top=MEM_BASE+MAXPAGES*PAGE;
    npages=(top-MEM_BASE)/PAGE; used=0; memset(bitmap,0,sizeof bitmap);
}
static int pg(u32 i){return (bitmap[i>>3]>>(i&7))&1;}
static void setpg(u32 i,int v){ if(v)bitmap[i>>3]|=(u8)(1u<<(i&7)); else bitmap[i>>3]&=(u8)~(1u<<(i&7)); }
void *mem_alloc_pages(u32 count){
    if(!count||count>npages)return NULL;
    u32 run=0,start=0;
    for(u32 i=0;i<npages;i++){
        if(!pg(i)){ if(!run)start=i; if(++run==count){ for(u32 j=start;j<start+count;j++)setpg(j,1); used+=count; return (void*)(MEM_BASE+start*PAGE);} }
        else run=0;
    }
    return NULL;
}
void mem_free_pages(void *p,u32 count){
    u32 a=(u32)p; if(!count||a<MEM_BASE||(a-MEM_BASE)%PAGE)return;
    u32 s=(a-MEM_BASE)/PAGE; if(s+count>npages)return;
    for(u32 i=s;i<s+count;i++) if(pg(i)){setpg(i,0);used--;}
}
u32 mem_free_pages_count(void){return npages-used;}
u32 mem_total_pages_count(void){return npages;}
