#include <stdint.h>
#include "wm.h"
#define W 800
#define H 600
#define backbuf BACKBUF
static int arcade_game=0;
static int games_paused=0;
static uint8_t tboard[200];
static int tx=3,ty=0,trot=0,tpiece=0,tscore=0,tlines=0,timer=0,tgame=0;
static const uint8_t tshapes[7][4][4]={
 {{0,0,0,0},{1,1,1,1},{0,0,0,0},{0,0,0,0}},
 {{1,0,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
 {{0,0,1,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
 {{1,1,0,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
 {{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
 {{0,1,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
 {{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}}};
static uint16_t tcols[8];
static uint32_t trng=0x12345678u;
static uint32_t trand(void){trng^=trng<<13;trng^=trng>>17;trng^=trng<<5;return trng;}

/* Games Center: 1000 lightweight playable entries built on reusable arcade engines. */
static int games_page=0, selected_game=0, arcade_variant=0;
static int pong_l=100,pong_r=100,pong_x=190,pong_y=110,pong_dx=2,pong_dy=1,pong_score_l=0,pong_score_r=0,pong_run=0,pong_tick=0;
static int dodger_x=190,dodger_y=350,dodger_score=0,dodger_run=0,dodger_tick=0;
static int flap_y=150,flap_v=0,flap_score=0,flap_run=0,flap_tick=0,flap_gap=100,flap_px=250;
static int react_wait=0,react_ready=0,react_done=0,react_score=0,react_tick=0;
static int maze_x=1,maze_y=1,maze_won=0;
static uint8_t maze_map[12][16]={
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
 {1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},
 {1,0,1,0,1,0,1,1,1,0,1,0,1,1,0,1},
 {1,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1},
 {1,0,1,1,1,1,1,0,1,1,1,0,1,0,1,1},
 {1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
 {1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,1},
 {1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,1},
 {1,0,1,0,1,1,1,0,1,1,1,1,0,1,0,1},
 {1,0,1,0,0,0,0,0,0,0,0,1,0,0,0,1},
 {1,0,0,0,1,1,1,1,1,1,0,1,1,1,0,1},
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
static uint8_t g2048[16]; static int g2048_score=0,g2048_run=0;
static uint32_t g_rng=0x72a51b3du;
static uint32_t g_rand(void){g_rng^=g_rng<<13;g_rng^=g_rng>>17;g_rng^=g_rng<<5;return g_rng;}
static void g2048_add(void){int freei[16],n=0;for(int i=0;i<16;i++)if(!g2048[i])freei[n++]=i;if(!n)return;g2048[freei[g_rand()%n]]=(g_rand()%10==0)?2:1;}
static void g2048_new(void){for(int i=0;i<16;i++)g2048[i]=0;g2048_score=0;g2048_run=1;g2048_add();g2048_add();}
static int g2048_move(int dir){uint8_t old[16];for(int i=0;i<16;i++)old[i]=g2048[i];
 for(int line=0;line<4;line++){uint8_t a[4]={0},b[4]={0};int k=0;
  for(int j=0;j<4;j++){int idx=(dir==0?j*4+line:dir==1?line*4+(3-j):dir==2?(3-j)*4+line:line*4+j);if(g2048[idx])a[k++]=g2048[idx];}
  int z=0;for(int j=0;j<k;j++){if(j+1<k&&a[j]==a[j+1]){b[z++]=(uint8_t)(a[j]+1);g2048_score+=(1<<b[z-1]);j++;}else b[z++]=a[j];}
  while(z<4)b[z++]=0;for(int j=0;j<4;j++){int idx=(dir==0?j*4+line:dir==1?line*4+(3-j):dir==2?(3-j)*4+line:line*4+j);g2048[idx]=b[j];}}
 int changed=0;for(int i=0;i<16;i++)if(old[i]!=g2048[i])changed=1;if(changed)g2048_add();return changed;}
static void pong_new(void){int sp=2+(arcade_variant%3);pong_l=pong_r=95;pong_x=235;pong_y=135;pong_dx=sp;pong_dy=1+(arcade_variant%2);pong_score_l=pong_score_r=0;pong_tick=0;pong_run=1;}
static void pong_step(void){if(!pong_run)return;pong_x+=pong_dx;pong_y+=pong_dy;if(pong_y<10||pong_y>260)pong_dy=-pong_dy;if(pong_x<30&&pong_x>20&&pong_y>=pong_l-12&&pong_y<=pong_l+50)pong_dx=2+(arcade_variant%3);if(pong_x>440&&pong_x<450&&pong_y>=pong_r-12&&pong_y<=pong_r+50)pong_dx=-(2+(arcade_variant%3));if(pong_x<0){pong_score_r++;pong_x=235;pong_y=135;pong_dx=2+(arcade_variant%3);}if(pong_x>470){pong_score_l++;pong_x=235;pong_y=135;pong_dx=-(2+(arcade_variant%3));}if(pong_r+25<pong_y)pong_r+=2;if(pong_r+25>pong_y+8)pong_r-=2;if(pong_l+25<pong_y)pong_l+=2;if(pong_l+25>pong_y+8)pong_l-=2;}
static void dodger_new(void){dodger_x=235;dodger_y=270;dodger_score=0;dodger_tick=0;dodger_run=1;}
static void dodger_step(void){if(!dodger_run)return;dodger_tick++;if((dodger_tick%(14+(arcade_variant%18)))==0)dodger_score++;}
static void flap_new(void){flap_y=150;flap_v=0;flap_score=0;flap_gap=100;flap_px=250;flap_tick=0;flap_run=1;}
static void flap_step(void){if(!flap_run)return;flap_v++;flap_y+=flap_v/3;if(flap_y<5){flap_y=5;flap_v=0;}if(flap_y>285)flap_run=0;flap_tick++;if(flap_tick%(35+(arcade_variant%40))==0){flap_gap=65+(int)(g_rand()%140);flap_score++;}}
static void react_new(void){react_wait=35+(int)(g_rand()%(80+(arcade_variant%80)));react_ready=0;react_done=0;react_score=0;react_tick=0;}
static void maze_new(void){maze_x=1;maze_y=1;maze_won=0;}
static const char* game_families[100]={
"TETRIS","SNAKE","MINES","BREAKOUT","PONG","2048","DODGER","FLAPPY","REACTION","MAZE",
"BLOCK DROP","APPLE RUN","BOMB FIELD","BRICK BLAST","PADDLE WAR","NUMBER MERGE","LASER DODGE","SKY HOP","QUICK TAP","LABYRINTH",
"NEON BLOCKS","GREEN SNAKE","SAFE MINE","PIXEL BREAK","TWIN PONG","TILE MERGE","METEOR DODGE","CLOUD HOP","FLASH TEST","MICRO MAZE",
"ICE BLOCKS","JUNGLE RUN","MINE SWEEP","PIXEL WALL","PONG DUEL","NUMBER RUSH","ROCKET DODGE","MOON FLAP","REACTION PRO","DARK MAZE",
"RETRO BLOCKS","GLOW SNAKE","BOMB HUNT","WALL BREAK","NEON PONG","TILE RUSH","STAR DODGE","BIRD RUN","COLOR TAP","WALL MAZE",
"CYBER BLOCKS","CYBER SNAKE","CYBER MINES","CYBER BREAK","CYBER PONG","CYBER MERGE","CYBER DODGE","CYBER FLAP","CYBER TAP","CYBER MAZE",
"STAR BLOCKS","STAR SNAKE","STAR MINES","STAR BREAK","STAR PONG","STAR MERGE","STAR DODGE","STAR FLAP","STAR REACTION","STAR MAZE",
"NAGI BLOCKS","NAGI SNAKE","NAGI MINES","NAGI BREAK","NAGI PONG","NAGI MERGE","NAGI DODGE","NAGI FLAP","NAGI REACTION","NAGI MAZE",
"NIGHT RUNNER","PIXEL RACER","VOID HOPPER","LASER GRID","ASTRO BALL","TINY TANKS","CIRCUIT RUN","MATRIX MAZE","NOVA TAP","ORBIT DODGE",
"SPEED GRID","BYTE BREAKER","NEON RUN","COSMIC DROP","DATA MAZE","VECTOR PONG","STAR RACER","DIGITAL MINES","NEX SNAKE","NEX BLOCKS"};
static char game_name_buf[32];
static void game_name(int g){const char*base=game_families[g/10];int v=(g%10)+1;int n=0;while(base[n]&&n<23){game_name_buf[n]=base[n];n++;}game_name_buf[n++]=' ';game_name_buf[n++]='0'+(v/10);game_name_buf[n++]='0'+(v%10);game_name_buf[n]=0;}
static int game_engine(int g){return g%6;}
static void arcade_new(int g){arcade_variant=selected_game;arcade_game=game_engine(g);if(arcade_game==0)pong_new();else if(arcade_game==1)g2048_new();else if(arcade_game==2)dodger_new();else if(arcade_game==3)flap_new();else if(arcade_game==4)react_new();else if(arcade_game==5)maze_new();}
void draw_games(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"GAMES CENTER",rgb(100,255,160),1);text(w->x+370,w->y+40,"1000 GAMES",rgb(160,180,220),1);
 int base=games_page*8;for(int i=0;i<8;i++){int g=base+i;if(g>=1000)break;game_name(g);int col=i%2,row=i/2,x=w->x+18+col*190,y=w->y+72+row*52;roundrect(x,y,175,42,7,rgb(10,14,27));text(x+9,y+7,game_name_buf,rgb(235,240,255),1);text(x+9,y+23,"PLAYABLE VARIANT",rgb(120,150,190),1);text(x+136,y+15,"PLAY",rgb(80,220,255),1);}char pg[16];int p=games_page+1,n=0;pg[n++]='P';pg[n++]='A';pg[n++]='G';pg[n++]='E';pg[n++]=' ';if(p>=100)pg[n++]='0'+p/100; if(p>=10)pg[n++]='0'+(p/10)%10;pg[n++]='0'+p%10;pg[n]=0;text(w->x+205,w->y+300,pg,rgb(160,180,220),1);roundrect(w->x+70,w->y+330,100,28,6,rgb(20,28,48));text(w->x+93,w->y+339,"PREV",rgb(220,230,245),1);roundrect(w->x+230,w->y+330,100,28,6,rgb(20,28,48));text(w->x+253,w->y+339,"NEXT",rgb(220,230,245),1);text(w->x+130,w->y+385,"1000 PLAYABLE ENTRIES",rgb(100,255,180),1);}

void draw_arcade(Window*w){window_bg(w);titlebar(w);game_name(selected_game);text(w->x+18,w->y+40,game_name_buf,rgb(100,255,160),1);text(w->x+w->w-100,w->y+40,"ESC BACK",rgb(160,180,220),1);
 if(arcade_game==0){roundrect(w->x+15,w->y+58,470,300,5,rgb(3,6,13));fill(w->x+25,w->y+58+pong_l,7,50,rgb(80,220,255));fill(w->x+463,w->y+58+pong_r,7,50,rgb(255,130,100));roundrect(w->x+15+pong_x,w->y+58+pong_y,8,8,4,rgb(245,245,255));char z[24];z[0]='0'+pong_score_l;z[1]=':';z[2]='0'+pong_score_r;z[3]=0;text(w->x+230,w->y+72,z,rgb(235,240,255),2);text(w->x+120,w->y+380,"W/S  LEFT   UP/DOWN  RIGHT",rgb(170,190,220),1);text(w->x+175,w->y+400,"SPACE START",rgb(255,180,100),1);}
 else if(arcade_game==1){for(int y=0;y<4;y++)for(int x=0;x<4;x++){int v=g2048[y*4+x];roundrect(w->x+40+x*78,w->y+65+y*78,70,70,8,v?rgb(40+v*12,45+v*10,75+v*8):rgb(10,14,27));if(v){char z[8];int val=1<<v,n=0;if(val>=1000){z[n++]='0'+val/1000;z[n++]='0'+(val/100)%10;z[n++]='0'+(val/10)%10;z[n++]='0'+val%10;}else if(val>=100){z[n++]='0'+val/100;z[n++]='0'+(val/10)%10;z[n++]='0'+val%10;}else if(val>=10){z[n++]='0'+val/10;z[n++]='0'+val%10;}else z[n++]='2';z[n]=0;text(w->x+63+x*78,w->y+92+y*78,z,rgb(240,245,255),2);}}text(w->x+40,w->y+390,"ARROWS MOVE   SPACE NEW",rgb(170,190,220),1);}
 else if(arcade_game==2){roundrect(w->x+20,w->y+60,470,300,5,rgb(4,7,14));roundrect(w->x+dodger_x,w->y+dodger_y,30,30,6,rgb(80,220,255));for(int i=0;i<8;i++){int bx=30+(i*61+(dodger_score*7)%61)%430;int by=75+(i*31+(dodger_score*11)%240)%260;roundrect(w->x+bx,w->y+by,18,18,5,rgb(255,90,110));}text(w->x+20,w->y+390,"LEFT / RIGHT   SPACE START",rgb(170,190,220),1);}
 else if(arcade_game==3){roundrect(w->x+20,w->y+60,470,300,5,rgb(4,7,14));fill(w->x+flap_px,w->y+flap_gap-55,28,55,rgb(80,220,170));fill(w->x+flap_px,w->y+flap_gap+65,28,180,rgb(80,220,170));roundrect(w->x+90,w->y+flap_y,22,22,10,rgb(255,210,70));text(w->x+20,w->y+390,"SPACE FLAP   SCORE",rgb(170,190,220),1);}
 else if(arcade_game==4){roundrect(w->x+70,w->y+80,350,190,12,react_ready?rgb(55,180,120):rgb(18,24,40));if(react_done)text(w->x+130,w->y+160,"RESULT",rgb(240,245,255),2);else text(w->x+125,w->y+160,react_ready?"CLICK!":"WAIT...",rgb(240,245,255),2);text(w->x+120,w->y+300,"MOUSE CLICK   SPACE NEW",rgb(170,190,220),1);}
 else {int ox=w->x+60,oy=w->y+60,cell=25;for(int y=0;y<12;y++)for(int x=0;x<16;x++){uint16_t c=maze_map[y][x]?rgb(16,22,38):rgb(5,8,15);fill(ox+x*cell,oy+y*cell,24,24,c);}roundrect(ox+maze_x*cell+5,oy+maze_y*cell+5,14,14,5,rgb(80,220,255));roundrect(ox+14*cell+5,oy+10*cell+5,14,14,5,rgb(100,255,160));text(w->x+20,w->y+380,"ARROWS MOVE   REACH GREEN",rgb(170,190,220),1);if(maze_won)text(w->x+190,w->y+380,"CLEAR!",rgb(100,255,170),1);}}

static int tshape_cell(int piece,int rot,int x,int y){
 int sx=x,sy=y;
 /* rotations around a 4x4 box */
 for(int i=0;i<rot;i++){int nx=3-sy,ny=sx;sx=nx;sy=ny;}
 return tshapes[piece][sy][sx];
}
static int tvalid(int nx,int ny,int piece,int rot){
 for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(tshape_cell(piece,rot,x,y)){int bx=nx+x,by=ny+y;if(bx<0||bx>=10||by<0||by>=20||tboard[by*10+bx])return 0;}
 return 1;
}
static void tclear_lines(void){
 for(int y=19;y>=0;y--){int full=1;for(int x=0;x<10;x++)if(!tboard[y*10+x]){full=0;break;}
  if(full){for(int yy=y;yy>0;yy--)for(int x=0;x<10;x++)tboard[yy*10+x]=tboard[(yy-1)*10+x];for(int x=0;x<10;x++)tboard[x]=0;tlines++;tscore+=100;y++;}
 }
}
static void tspawn(void){tpiece=(int)(trand()%7);tx=3;ty=0;trot=0;if(!tvalid(tx,ty,tpiece,trot))tgame=0;}
static void tlock(void){for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(tshape_cell(tpiece,trot,x,y)){int bx=tx+x,by=ty+y;if(bx>=0&&bx<10&&by>=0&&by<20)tboard[by*10+bx]=tpiece+1;}tclear_lines();tspawn();}
static void tstep(void){if(!tgame)return;if(tvalid(tx,ty+1,tpiece,trot))ty++;else tlock();}
static void tnew(void){for(int i=0;i<200;i++)tboard[i]=0;tscore=0;tlines=0;timer=0;tgame=1;tspawn();}
static uint8_t snake_x[180],snake_y[180];
static int snake_len=5,snake_dir=1,snake_next=1,snake_fx=12,snake_fy=10,snake_score=0,snake_game=0,snake_tick=0;
static uint32_t snake_rng=0x91a72b31u;
static uint32_t snake_rand(void){snake_rng^=snake_rng<<13;snake_rng^=snake_rng>>17;snake_rng^=snake_rng<<5;return snake_rng;}
static void snake_spawn_food(void){for(int tries=0;tries<500;tries++){int x=(int)(snake_rand()%20),y=(int)(snake_rand()%20);int ok=1;for(int i=0;i<snake_len;i++)if(snake_x[i]==x&&snake_y[i]==y)ok=0;if(ok){snake_fx=x;snake_fy=y;return;}}}
static void snake_new(void){snake_len=5;snake_dir=1;snake_next=1;snake_score=0;snake_tick=0;snake_game=1;for(int i=0;i<snake_len;i++){snake_x[i]=(uint8_t)(9-i);snake_y[i]=10;}snake_spawn_food();}
static void snake_step(void){if(!snake_game)return;snake_dir=snake_next;int nx=snake_x[0],ny=snake_y[0];if(snake_dir==0)ny--;else if(snake_dir==1)nx++;else if(snake_dir==2)ny++;else nx--;if(nx<0||nx>=20||ny<0||ny>=20){snake_game=0;return;}for(int i=0;i<snake_len;i++)if(snake_x[i]==nx&&snake_y[i]==ny){snake_game=0;return;}int eat=(nx==snake_fx&&ny==snake_fy);int lim=snake_len+(eat?1:0);if(lim>179)lim=179;for(int i=lim-1;i>0;i--){snake_x[i]=snake_x[i-1];snake_y[i]=snake_y[i-1];}snake_x[0]=nx;snake_y[0]=ny;if(eat){snake_len=lim;snake_score+=10;snake_spawn_food();}}
void draw_snake(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"SNAKE",rgb(100,255,160),1);int ox=w->x+20,oy=w->y+62,cell=15;roundrect(ox,oy,302,302,5,rgb(5,8,15));for(int i=0;i<snake_len;i++)roundrect(ox+2+snake_x[i]*cell,oy+2+snake_y[i]*cell,12,12,3,i==0?rgb(80,240,180):rgb(35,150,120));roundrect(ox+2+snake_fx*cell,oy+2+snake_fy*cell,12,12,5,rgb(255,90,100));char n[16];int v=snake_score,k=0;if(!v)n[k++]='0';else{char q[12];int z=0;while(v&&z<11){q[z++]=(char)('0'+v%10);v/=10;}while(z)n[k++]=q[--z];}n[k]=0;text(w->x+20,w->y+380,"SCORE",rgb(150,170,205),1);text(w->x+62,w->y+380,n,rgb(100,255,180),1);text(w->x+150,w->y+380,"ARROWS / SPACE   P PAUSE",rgb(180,195,220),1);if(!snake_game)text(w->x+100,w->y+402,"SPACE START",rgb(255,170,100),1);}
static uint8_t mine_cell[81],mine_reveal[81],mine_flag[81];
static int mine_x=0,mine_y=0,mine_left=10,mine_game=0,mine_over=0,mine_won=0;
static uint32_t mine_rng=0x47a1cc29u;
static uint32_t mine_rand(void){mine_rng^=mine_rng<<13;mine_rng^=mine_rng>>17;mine_rng^=mine_rng<<5;return mine_rng;}
static int mine_adj(int x,int y){int n=0;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if(dx||dy){int a=x+dx,b=y+dy;if(a>=0&&a<9&&b>=0&&b<9&&mine_cell[b*9+a])n++;}return n;}
static void mine_flood(int x,int y){if(x<0||x>=9||y<0||y>=9)return;int i=y*9+x;if(mine_reveal[i]||mine_flag[i])return;mine_reveal[i]=1;if(mine_adj(x,y)==0)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if(dx||dy)mine_flood(x+dx,y+dy);}
static void mine_new(void){for(int i=0;i<81;i++){mine_cell[i]=mine_reveal[i]=mine_flag[i]=0;}for(int m=0;m<10;){int i=(int)(mine_rand()%81);if(!mine_cell[i]){mine_cell[i]=1;m++;}}mine_x=mine_y=0;mine_left=10;mine_game=1;mine_over=mine_won=0;}
static void mine_reveal_at(void){if(!mine_game||mine_flag[mine_y*9+mine_x])return;int i=mine_y*9+mine_x;if(mine_cell[i]){mine_over=1;mine_game=0;for(int j=0;j<81;j++)if(mine_cell[j])mine_reveal[j]=1;return;}mine_flood(mine_x,mine_y);int safe=0;for(int j=0;j<81;j++)if(!mine_cell[j]&&!mine_reveal[j])safe=1;if(!safe){mine_won=1;mine_game=0;}}
static void mine_flag_at(void){if(!mine_game)return;int i=mine_y*9+mine_x;if(mine_reveal[i])return;if(mine_flag[i]){mine_flag[i]=0;mine_left++;}else if(mine_left>0){mine_flag[i]=1;mine_left--;}}
void draw_mines(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"MINES",rgb(100,255,160),1);int ox=w->x+25,oy=w->y+62,cell=34;for(int y=0;y<9;y++)for(int x=0;x<9;x++){int i=y*9+x;uint16_t c=mine_reveal[i]?rgb(34,40,55):rgb(12,16,28);if(mine_flag[i])c=rgb(75,45,70);roundrect(ox+x*cell,oy+y*cell,32,32,4,c);if(mine_reveal[i]){if(mine_cell[i])text(ox+x*cell+11,oy+y*cell+8,"*",rgb(255,100,100),2);else{int a=mine_adj(x,y);if(a){char z[2]={(char)('0'+a),0};text(ox+x*cell+11,oy+y*cell+8,z,rgb(90,210,255),2);}}}else if(mine_flag[i])text(ox+x*cell+11,oy+y*cell+8,"F",rgb(255,180,100),2);if(x==mine_x&&y==mine_y)roundrect(ox+x*cell,oy+y*cell,32,32,4,rgb(70,210,255));}text(w->x+25,w->y+382,"ARROWS MOVE  ENTER OPEN  F FLAG",rgb(175,190,215),1);char z[16];z[0]='0'+(mine_left/10);z[1]='0'+(mine_left%10);z[2]=0;text(w->x+25,w->y+402,"MINES:",rgb(180,195,220),1);text(w->x+67,w->y+402,z,rgb(255,170,100),1);if(mine_over)text(w->x+150,w->y+402,"BOOM - SPACE",rgb(255,100,100),1);else if(mine_won)text(w->x+150,w->y+402,"CLEAR! - SPACE",rgb(100,255,170),1);}
static int br_x=235,br_y=360,br_dx=2,br_dy=-2,br_pad=65,br_score=0,br_game=0,br_tick=0;
static uint8_t br_bricks[40];
static void br_new(void){for(int i=0;i<40;i++)br_bricks[i]=1;br_x=245;br_y=360;br_dx=2;br_dy=-2;br_pad=65;br_score=0;br_tick=0;br_game=1;}
static void br_step(void){if(!br_game)return;br_x+=br_dx;br_y+=br_dy;if(br_x<8){br_x=8;br_dx=-br_dx;}if(br_x>472){br_x=472;br_dx=-br_dx;}if(br_y<40){br_y=40;br_dy=-br_dy;}int py=370;if(br_y>=350&&br_y<=380&&br_x>=br_pad&&br_x<=br_pad+70){br_dy=-2;br_dx += (br_x-(br_pad+35))/18;if(br_dx>4)br_dx=4;if(br_dx<-4)br_dx=-4;}if(br_y>405){br_game=0;return;}for(int r=0;r<4;r++)for(int c=0;c<10;c++)if(br_bricks[r*10+c]){int bx=10+c*47,by=55+r*22;if(br_x+8>=bx&&br_x<=bx+43&&br_y+8>=by&&br_y<=by+17){br_bricks[r*10+c]=0;br_dy=-br_dy;br_score+=10;return;}}}
void draw_breakout(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"BREAKOUT",rgb(100,255,160),1);int ox=w->x+15,oy=w->y+58;roundrect(ox,oy,470,320,5,rgb(4,7,14));for(int r=0;r<4;r++)for(int c=0;c<10;c++)if(br_bricks[r*10+c])roundrect(ox+10+c*47,oy+10+r*22,43,17,3,(r==0)?rgb(255,100,120):(r==1?rgb(255,190,80):(r==2?rgb(100,190,255):rgb(110,240,170))));roundrect(ox+br_x,oy+br_y,9,9,4,rgb(245,245,255));roundrect(ox+br_pad,oy+292,70,9,4,rgb(90,220,255));char z[16];int v=br_score,k=0;if(!v)z[k++]='0';else{char q[12];int n=0;while(v&&n<11){q[n++]=(char)('0'+v%10);v/=10;}while(n)z[k++]=q[--n];}z[k]=0;text(w->x+20,w->y+390,"SCORE",rgb(150,170,205),1);text(w->x+62,w->y+390,z,rgb(100,255,180),1);text(w->x+150,w->y+390,"LEFT / RIGHT   P PAUSE",rgb(180,195,220),1);if(!br_game)text(w->x+315,w->y+390,"SPACE START",rgb(255,170,100),1); if(games_paused)text(w->x+315,w->y+410,"PAUSED",rgb(255,170,100),1);}
void draw_tetris(Window*w){
 window_bg(w);titlebar(w);
 int ox=w->x+18,oy=w->y+42,cell=16;
 roundrect(ox,oy,10*cell+2,20*cell+2,3,rgb(5,7,14));
 for(int y=0;y<20;y++)for(int x=0;x<10;x++){uint8_t v=tboard[y*10+x];if(v){uint8_t r=(v==1)?80:(v==2?255:(v==3?80:(v==4?220:(v==5?80:(v==6?255:180)))));uint8_t g=(v==1)?220:(v==2?150:(v==3?120:(v==4?210:(v==5?80:(v==6?90:80)))));uint8_t b=(v==1)?255:(v==2?60:(v==3?220:(v==4?80:(v==5?220:(v==6?220:255)))));roundrect(ox+1+x*cell,oy+1+y*cell,14,14,2,rgb(r,g,b));}}
 if(tgame)for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(tshape_cell(tpiece,trot,x,y)){int bx=tx+x,by=ty+y;if(bx>=0&&bx<10&&by>=0&&by<20)roundrect(ox+1+bx*cell,oy+1+by*cell,14,14,2,tcols[tpiece+1]);}
 text(w->x+188,w->y+55,"TETRIS",rgb(225,231,248),1);
 text(w->x+188,w->y+82,"SCORE",rgb(150,170,205),1);char num[16];int n=tscore,di=0;if(n==0)num[di++]='0';else{char rev[12];int k=0;while(n&&k<11){rev[k++]=(char)('0'+n%10);n/=10;}while(k)num[di++]=rev[--k];}num[di]=0;text(w->x+188,w->y+98,num,rgb(100,255,180),1);
 text(w->x+188,w->y+124,"ARROWS MOVE",rgb(180,195,220),1);text(w->x+188,w->y+140,"UP ROTATE",rgb(180,195,220),1);text(w->x+188,w->y+156,"DOWN DROP",rgb(180,195,220),1);text(w->x+188,w->y+172,"SPACE START",rgb(180,195,220),1);
 if(!tgame)text(w->x+188,w->y+205,"PRESS SPACE",rgb(255,170,100),1);
}

/* ======== glue: new input/timing API for the legacy games ======== */
void games_init(void){
    tcols[1]=rgb(80,220,255);tcols[2]=rgb(255,120,80);tcols[3]=rgb(90,140,255);tcols[4]=rgb(240,220,80);tcols[5]=rgb(80,220,120);tcols[6]=rgb(190,100,255);tcols[7]=rgb(255,100,180);
    tgame=0;tnew();tgame=0;snake_game=0;mine_game=0;mine_over=mine_won=0;br_game=0;
}
static int due(u32 *t,u32 now,u32 period){ if(!TIME_AFTER(now,*t+period))return 0; *t=now; return 1; }
int games_tick(u32 now){
    static u32 t_tet,t_snk,t_br,t_pong,t_dodge,t_flap,t_react;
    int ch=0;
    if(games_paused)return 0;
    if(active==APP_TETRIS&&win[APP_TETRIS].open&&tgame&&due(&t_tet,now,450)){tstep();ch=1;}
    if(active==APP_SNAKE&&win[APP_SNAKE].open&&snake_game&&due(&t_snk,now,140)){snake_step();ch=1;}
    if(active==APP_BREAKOUT&&win[APP_BREAKOUT].open&&br_game&&due(&t_br,now,18)){br_step();ch=1;}
    if(active==APP_ARCADE&&win[APP_ARCADE].open){
        if(arcade_game==0&&pong_run&&due(&t_pong,now,16)){pong_step();ch=1;}
        if(arcade_game==2&&dodger_run&&due(&t_dodge,now,16)){dodger_step();ch=1;}
        if(arcade_game==3&&flap_run&&due(&t_flap,now,18)){flap_step();ch=1;}
        if(arcade_game==4&&!react_done&&due(&t_react,now,33)){if(react_wait>0){react_wait--;if(react_wait==0)react_ready=1;react_tick++;ch=1;}}
    }
    return ch;
}
int games_key(Key *k){
    uint8_t s=(k->sc<0x100)?(uint8_t)k->sc:0;char c=(char)k->ch;
    if(k->mods&MOD_CTRL)return 0;
    if(active==APP_TETRIS&&win[APP_TETRIS].open){
        if(c=='p'||c=='P'){games_paused=!games_paused;return 1;}
        if(s==0x48){if(!tgame)tnew();else if(tvalid(tx,ty,tpiece,(trot+1)&3))trot=(trot+1)&3;return 1;}
        if(s==0x4b){if(!tgame)tnew();else if(tvalid(tx-1,ty,tpiece,trot))tx--;return 1;}
        if(s==0x4d){if(!tgame)tnew();else if(tvalid(tx+1,ty,tpiece,trot))tx++;return 1;}
        if(s==0x50){if(!tgame)tnew();else while(tvalid(tx,ty+1,tpiece,trot))ty++;return 1;}
        if(c==' '){tnew();return 1;}
        return 1;
    }
    if(active==APP_SNAKE&&win[APP_SNAKE].open){
        if(c=='p'||c=='P'){games_paused=!games_paused;return 1;}
        if(c==' '){snake_new();return 1;}
        if(s==0x48&&snake_dir!=2)snake_next=0;if(s==0x4d&&snake_dir!=3)snake_next=1;if(s==0x50&&snake_dir!=0)snake_next=2;if(s==0x4b&&snake_dir!=1)snake_next=3;
        return 1;
    }
    if(active==APP_MINES&&win[APP_MINES].open){
        if(c==' '){mine_new();return 1;}
        if(s==0x48&&mine_y>0)mine_y--;if(s==0x50&&mine_y<8)mine_y++;if(s==0x4b&&mine_x>0)mine_x--;if(s==0x4d&&mine_x<8)mine_x++;
        if(c=='\n')mine_reveal_at();if(c=='f'||c=='F')mine_flag_at();
        return 1;
    }
    if(active==APP_BREAKOUT&&win[APP_BREAKOUT].open){
        if(c=='p'||c=='P'){games_paused=!games_paused;return 1;}
        if(c==' '){br_new();return 1;}
        if(s==0x4b&&br_pad>18)br_pad-=8;if(s==0x4d&&br_pad<395)br_pad+=8;
        return 1;
    }
    if(active==APP_ARCADE&&win[APP_ARCADE].open){
        if(c=='p'||c=='P'){games_paused=!games_paused;return 1;}
        if(s==0x01){win[APP_ARCADE].open=0;win[APP_GAMES].open=1;active=APP_GAMES;return 1;}
        if(arcade_game==0){if(c==' '){pong_new();return 1;}if(s==0x11&&pong_l>5)pong_l-=8;if(s==0x1f&&pong_l<230)pong_l+=8;if(s==0x48&&pong_r>5)pong_r-=8;if(s==0x50&&pong_r<230)pong_r+=8;}
        else if(arcade_game==1){if(c==' '){g2048_new();return 1;}if(s==0x48)g2048_move(0);else if(s==0x4d)g2048_move(1);else if(s==0x50)g2048_move(2);else if(s==0x4b)g2048_move(3);}
        else if(arcade_game==2){if(c==' '){dodger_new();return 1;}if(s==0x4b&&dodger_x>25)dodger_x-=8;if(s==0x4d&&dodger_x<455)dodger_x+=8;}
        else if(arcade_game==3){if(c==' '){flap_new();flap_v=-5;return 1;}}
        else if(arcade_game==4){if(c==' '){react_new();return 1;}}
        else if(arcade_game==5){if(c==' '){maze_new();return 1;}int nx=maze_x,ny=maze_y;if(s==0x48)ny--;if(s==0x50)ny++;if(s==0x4b)nx--;if(s==0x4d)nx++;if(nx>=0&&nx<16&&ny>=0&&ny<12&&!maze_map[ny][nx]){maze_x=nx;maze_y=ny;if(nx==14&&ny==10)maze_won=1;}}
        return 1;
    }
    return 0;
}
void games_click(int id,Window *w){
    if(id==APP_TETRIS){active=APP_TETRIS;if(inside(w->x+188,w->y+190,95,30,mx,my))tnew();}
    if(id==APP_GAMES){
        int gx=w->x+18,gy=w->y+72;
        if(inside(w->x+70,w->y+330,100,28,mx,my)){if(games_page>0)games_page--;return;}
        if(inside(w->x+230,w->y+330,100,28,mx,my)){if(games_page<124)games_page++;return;}
        for(int i=0;i<8;i++){
            int g=games_page*8+i;if(g>=1000)break;
            int col=i%2,row=i/2,bx=gx+col*190,by=gy+row*52;
            if(inside(bx,by,175,42,mx,my)){
                selected_game=g;for(int j=6;j<=11;j++)win[j].open=0;
                if(g==0){win[APP_TETRIS].open=1;active=APP_TETRIS;tnew();}
                else if(g==1){win[APP_SNAKE].open=1;active=APP_SNAKE;snake_new();}
                else if(g==2){win[APP_MINES].open=1;active=APP_MINES;mine_new();}
                else if(g==3){win[APP_BREAKOUT].open=1;active=APP_BREAKOUT;br_new();}
                else{win[APP_ARCADE].open=1;active=APP_ARCADE;arcade_new(g);}
                return;
            }
        }
    }
    if(id==APP_ARCADE){
        if(inside(w->x+w->w-115,w->y,w->w,22,mx,my)){win[APP_ARCADE].open=0;active=APP_GAMES;return;}
        if(arcade_game==4&&inside(w->x+70,w->y+80,350,190,mx,my)&&react_ready&&!react_done){react_done=1;react_score=react_tick;return;}
    }
}
