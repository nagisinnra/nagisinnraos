#ifndef FAT12_H
#define FAT12_H
#include "nagi.h"
#define ATTR_RO 0x01
#define ATTR_DIR 0x10
typedef struct { char name[13]; u8 attr; u32 size; u16 cluster; u16 date,time; u16 dir; int idx; } FsEnt;
extern int fs_ok;
extern u32 fs_gen;                /* bumped on every modification */
int fs_init(u8 *base);
int fs_list(u16 dir,FsEnt *out,int max);
int fs_find(u16 dir,const char *name,FsEnt *e);
int fs_read(const FsEnt *e,u8 *buf,int cap);
int fs_write(u16 dir,const char *name,const u8 *data,u32 len);   /* 0 ok */
int fs_mkdir(u16 dir,const char *name);
int fs_delete(u16 dir,const char *name);
int fs_rename(u16 dir,const char *oldn,const char *newn);
int fs_resolve(const char *path,u16 cwd,u16 *dir,char *leaf);    /* dir + leaf name ("" if path names a directory) */
int fs_chdir(const char *path,u16 cwd,u16 *out);
void fs_path(u16 dir,char *out,int cap);
u32 fs_free_bytes(void);
u32 fs_total_bytes(void);
#define FSE_NAME -1
#define FSE_FULL -2
#define FSE_DIRFULL -3
#define FSE_ISDIR -4
#define FSE_NOTEMPTY -5
#define FSE_EXISTS -6
#define FSE_NOTFOUND -7
const char *fs_errstr(int e);
#endif
