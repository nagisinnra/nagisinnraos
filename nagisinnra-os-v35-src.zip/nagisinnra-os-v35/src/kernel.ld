ENTRY(_start)
SECTIONS {
 . = 0x10000;
 .text : { *(.text.entry) *(.text .text.*) }
 .rodata : { *(.rodata .rodata.*) }
 .data : { *(.data .data.*) }
 . = ALIGN(512);
 __image_end = .;
 __bss_start = .;
 .bss : { *(.bss .bss.*) *(COMMON) }
 __bss_end = .;
 /DISCARD/ : { *(.eh_frame) *(.note*) *(.comment) }
}
