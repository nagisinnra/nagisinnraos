#include "wm.h"
#include "fat12.h"
/* File manager: browse, open, new folder/file, rename, delete. */
static u32 seen_gen;static u16 fdir;static FsEnt ents[160];static int fn,fsel=-1,fscroll;
static int fprompt;static char pbuf[40];static int pn;   /* 1 mkdir, 2 newfile, 3 rename */
static char fmsg[100];static u32 fmsg_t,last_clk;static int last_row=-1;
static void say(const char *s){scpy(fmsg,s,sizeof fmsg);fmsg_t=ms_now();ui_dirty=1;}
static void refresh(void){
    int n=fs_list(fdir,ents,160);
    for(int i=1;i<n;i++){FsEnt t=ents[i];int j=i-1;
        while(j>=0&&(((ents[j].attr&ATTR_DIR)<(t.attr&ATTR_DIR))||(((ents[j].attr&ATTR_DIR)==(t.attr&ATTR_DIR))&&stricmp(ents[j].name,t.name)>0))){ents[j+1]=ents[j];j--;}
        ents[j+1]=t;}
    fn=n;if(fsel>=fn)fsel=fn-1;seen_gen=fs_gen;ui_dirty=1;
}
void files_init(void){fdir=0;fsel=-1;fscroll=0;fprompt=0;refresh();}
static int has_ext(const char *name,const char *ext){int l=(int)strlen(name),e=(int)strlen(ext);return l>=e&&!stricmp(name+l-e,ext);}
static void open_entry(int i){
    if(i<0||i>=fn)return;FsEnt *e=&ents[i];
    if(e->attr&ATTR_DIR){fdir=e->cluster;fsel=-1;fscroll=0;refresh();return;}
    if(has_ext(e->name,".HTM")||has_ext(e->name,".HTML")){
        char p[128],u[160];fs_path(fdir,p,sizeof p);
        for(char *c=p;*c;c++)if(*c=='\\')*c='/';
        ksnprintf(u,sizeof u,"file:%s%s%s",p,p[1]?"/":"",e->name);
        open_app(APP_BROWSER);browser_open_url(u);return;
    }
    if(has_ext(e->name,".COM")){say("Use the terminal: run <file>");return;}
    editor_open_file(fdir,e->name);open_app(APP_EDIT);
}
static void geo(Window *w,int *lx,int *ly,int *lw,int *lh){*lx=CONTENT_X(w);*ly=CONTENT_Y(w)+62;*lw=CONTENT_W(w);*lh=CONTENT_H(w)-62-24;}
static void btn(int x,int y,int w,const char *l,int en){int hv=en&&inside(x,y,w,24,mx,my);roundrect(x,y,w,24,5,hv?rgb(30,48,76):rgb(14,22,38));text16(x+(w-text16w(l))/2,y+4,l,en?C_TEXT:rgb(70,82,105));}
void files_draw(Window *w){
    if(seen_gen!=fs_gen)refresh();
    int lx,ly,lw,lh;geo(w,&lx,&ly,&lw,&lh);int bx=CONTENT_X(w),by=CONTENT_Y(w)+2;
    set_clip(CONTENT_X(w),CONTENT_Y(w),CONTENT_W(w),CONTENT_H(w));
    btn(bx,by,40,"Up",fdir!=0);btn(bx+44,by,86,"New Dir",1);btn(bx+134,by,86,"New File",1);btn(bx+224,by,70,"Rename",fsel>=0);btn(bx+298,by,70,"Delete",fsel>=0);
    char p[128];fs_path(fdir,p,sizeof p);
    fill(bx,by+28,lw,20,C_FIELD);text16(bx+6,by+30,p,C_ACC);
    fill(lx,ly-14,lw,14,rgb(10,16,30));
    text16(lx+26,ly-16,"Name",C_DIM);text16(lx+lw-250,ly-16,"Size",C_DIM);text16(lx+lw-150,ly-16,"Modified",C_DIM);
    int rows=lh/18;
    for(int r=0;r<rows;r++){
        int i=fscroll+r;if(i>=fn)break;int y=ly+r*18;FsEnt *e=&ents[i];
        int hv=inside(lx,y,lw,18,mx,my);
        if(i==fsel)fill(lx,y,lw,18,rgb(24,50,86));else if(hv)fill(lx,y,lw,18,rgb(14,24,42));
        int dir=e->attr&ATTR_DIR;
        text16(lx+4,y+1,dir?"\xE2\x96\xA0":"\xC2\xB7",dir?C_YEL:C_DIM);
        text16(lx+26,y+1,e->name,dir?C_YEL:C_TEXT);
        char sz[16],dt[24];
        if(dir)scpy(sz,"<DIR>",sizeof sz);else ksnprintf(sz,sizeof sz,"%d",e->size);
        text16(lx+lw-250+ (8-(int)strlen(sz))*8*0,y+1,sz,C_DIM);
        if(e->date)ksnprintf(dt,sizeof dt,"%d-%02d-%02d %02d:%02d",1980+(e->date>>9),(e->date>>5)&15,e->date&31,e->time>>11,(e->time>>5)&63);else dt[0]=0;
        text16(lx+lw-150,y+1,dt,C_DIM);
    }
    int sy=ly+lh+4;char st[100];ksnprintf(st,sizeof st,"%d item(s)   %d KB free",fn,(int)(fs_free_bytes()/1024));
    text16(lx,sy,st,C_DIM);
    if(fmsg[0]&&ms_now()-fmsg_t<4000)text16(lx+lw-text16w(fmsg)-6,sy,fmsg,C_YEL);
    if(fprompt){
        int pw=340,px=w->x+(w->w-pw)/2,py=w->y+w->h/2-40;
        roundrect(px,py,pw,80,8,rgb(14,22,40));frame_rect(px,py,pw,80,C_ACC);
        text16(px+14,py+10,fprompt==1?"New folder name:":fprompt==2?"New file name:":"Rename to:",C_TEXT);
        fill(px+14,py+34,pw-28,24,C_FIELD);text16(px+20,py+38,pbuf,C_TEXT);
        if((ms_now()/500)&1)fill(px+20+text16w(pbuf),py+38,2,16,C_ACC);
        text16(px+14,py+62,"Enter = OK   Esc = cancel",C_DIM);
    }
    clip_reset();
}
static void do_prompt_ok(void){
    int kind=fprompt;fprompt=0;if(!pn)return;int r=0;
    if(kind==1)r=fs_mkdir(fdir,pbuf);
    else if(kind==2){FsEnt t;if(fs_find(fdir,pbuf,&t))r=FSE_EXISTS;else r=fs_write(fdir,pbuf,(const u8*)"",0);if(!r){editor_open_file(fdir,pbuf);open_app(APP_EDIT);}}
    else if(kind==3&&fsel>=0)r=fs_rename(fdir,ents[fsel].name,pbuf);
    if(r)say(fs_errstr(r));refresh();
}
void files_key(Key *k){
    ui_dirty=1;
    if(fprompt){
        if(k->sc==K_ESC){fprompt=0;return;}
        if(k->ch=='\n'){do_prompt_ok();return;}
        if(k->ch==8){if(pn>0)pbuf[--pn]=0;return;}
        if(k->ch>=32&&k->ch<127&&pn<12){pbuf[pn++]=(char)k->ch;pbuf[pn]=0;}
        return;
    }
    if(k->sc==K_DOWN){if(fsel<fn-1)fsel++;}else if(k->sc==K_UP){if(fsel>0)fsel--;}
    else if(k->ch=='\n'){open_entry(fsel);return;}
    else if(k->ch==8){if(fdir){FsEnt up;(void)up;u16 d;if(!fs_chdir("..",fdir,&d)){fdir=d;fsel=-1;fscroll=0;refresh();}}return;}
    else if(k->sc==K_DEL&&fsel>=0){int r=fs_delete(fdir,ents[fsel].name);if(r)say(fs_errstr(r));refresh();return;}
    else if(k->sc==K_F2&&fsel>=0){fprompt=3;scpy(pbuf,ents[fsel].name,sizeof pbuf);pn=(int)strlen(pbuf);return;}
    else return;
    int rows=24;if(fsel<fscroll)fscroll=fsel;if(fsel>=fscroll+rows)fscroll=fsel-rows+1;
}
void files_click(Window *w){
    if(fprompt)return;
    int lx,ly,lw,lh;geo(w,&lx,&ly,&lw,&lh);int bx=CONTENT_X(w),by=CONTENT_Y(w)+2;
    if(inside(bx,by,40,24,mx,my)){if(fdir){u16 d;if(!fs_chdir("..",fdir,&d)){fdir=d;fsel=-1;fscroll=0;refresh();}}return;}
    if(inside(bx+44,by,86,24,mx,my)){fprompt=1;pbuf[0]=0;pn=0;return;}
    if(inside(bx+134,by,86,24,mx,my)){fprompt=2;pbuf[0]=0;pn=0;return;}
    if(inside(bx+224,by,70,24,mx,my)&&fsel>=0){fprompt=3;scpy(pbuf,ents[fsel].name,sizeof pbuf);pn=(int)strlen(pbuf);return;}
    if(inside(bx+298,by,70,24,mx,my)&&fsel>=0){int r=fs_delete(fdir,ents[fsel].name);if(r)say(fs_errstr(r));else fsel=-1;refresh();return;}
    if(inside(lx,ly,lw,lh,mx,my)){
        int row=(my-ly)/18;int i=fscroll+row;
        if(i<fn){
            u32 now=ms_now();
            if(i==last_row&&now-last_clk<450){open_entry(i);last_row=-1;}
            else{fsel=i;last_row=i;last_clk=now;}
        } else fsel=-1;
    }
}
void files_wheel(int dz){fscroll+=dz*3;if(fscroll<0)fscroll=0;if(fscroll>fn-1)fscroll=fn>0?fn-1:0;ui_dirty=1;}
