#include "wm.h"
#include "fat12.h"
/* Text editor (UTF-8 aware cursor, 64 KB buffer, Save/Save As/Open). */
#define EDCAP 65536
static char *buf;static int n,cur,top,left,want_col,modified;
static u16 edir;static char ename[16];
static char msg[96];static u32 msg_t;
static int prompt;static char pbuf[64];static int pn;     /* 1 = save as, 2 = open */
static void say(const char *s){scpy(msg,s,sizeof msg);msg_t=ms_now();ui_dirty=1;}
static int alloc(void){if(!buf){buf=mem_alloc_pages(EDCAP/4096);}return buf!=NULL;}
void editor_init(void){alloc();n=cur=top=left=modified=0;ename[0]=0;edir=0;msg[0]=0;prompt=0;}
void editor_new(void){if(!alloc())return;n=cur=top=left=modified=0;buf[0]=0;ename[0]=0;edir=term_cwd();say("New file");}
int editor_open_file(u16 dir,const char *name){
    if(!alloc())return 0;
    FsEnt e;if(!fs_find(dir,name,&e)||(e.attr&ATTR_DIR))return 0;
    int len=fs_read(&e,(u8*)buf,EDCAP-1);buf[len]=0;n=len;cur=top=left=0;modified=0;
    scpy(ename,e.name,sizeof ename);edir=dir;want_col=0;
    say(e.size>EDCAP-1?"File truncated to 64 KB":"Opened");return 1;
}
static int save_to(u16 d,const char *name){
    int r=fs_write(d,name,(u8*)buf,(u32)n);
    if(r){char m[96];ksnprintf(m,sizeof m,"Save failed: %s",fs_errstr(r));say(m);return 0;}
    FsEnt e;if(fs_find(d,name,&e))scpy(ename,e.name,sizeof ename);edir=d;modified=0;say("Saved");return 1;
}
static void do_save(void){ if(ename[0])save_to(edir,ename); else {prompt=1;pbuf[0]=0;pn=0;} }
/* ---- cursor helpers ---- */
static int ls_of(int p){while(p>0&&buf[p-1]!='\n')p--;return p;}
static int le_of(int p){while(p<n&&buf[p]!='\n')p++;return p;}
static int is_cont(int p){return p<n&&(((u8)buf[p])&0xC0)==0x80;}
static int col_of(int p){int s=ls_of(p),c=0;for(int i=s;i<p;i++)if(!is_cont(i))c++;return c;}
static int pos_at_col(int s,int col){int p=s,c=0;while(p<n&&buf[p]!='\n'&&c<col){p++;while(is_cont(p))p++;c++;}return p;}
static void ins(const char *s,int l){
    if(n+l>=EDCAP)return;
    memmove(buf+cur+l,buf+cur,(u32)(n-cur+1));memcpy(buf+cur,s,(u32)l);n+=l;cur+=l;modified=1;want_col=col_of(cur);
}
static void del_back(void){
    if(cur<=0)return;int p=cur-1;while(p>0&&is_cont(p))p--;
    memmove(buf+p,buf+cur,(u32)(n-cur+1));n-=cur-p;cur=p;modified=1;want_col=col_of(cur);
}
static void del_fwd(void){
    if(cur>=n)return;int p=cur+1;while(is_cont(p))p++;
    memmove(buf+cur,buf+p,(u32)(n-p+1));n-=p-cur;modified=1;
}
static void move_lines(int d){
    int col=want_col;
    for(;d>0;d--){int e=le_of(cur);if(e>=n)break;cur=e+1;cur=pos_at_col(cur,col);}
    for(;d<0;d++){int s=ls_of(cur);if(s==0)break;int ps=ls_of(s-1);cur=pos_at_col(ps,col);}
}
void editor_key(Key *k){
    ui_dirty=1;if(!alloc())return;
    if(prompt){
        if(k->sc==K_ESC){prompt=0;return;}
        if(k->ch=='\n'){
            int kind=prompt;prompt=0;if(!pn)return;
            u16 d;char leaf[16];
            if(fs_resolve(pbuf,edir,&d,leaf)||!leaf[0]){say("Bad file name");return;}
            if(kind==1)save_to(d,leaf);else if(!editor_open_file(d,leaf))say("File not found");
            return;
        }
        if(k->ch==8){if(pn>0)pbuf[--pn]=0;return;}
        if(k->ch>=32&&k->ch<127&&pn<(int)sizeof pbuf-2){pbuf[pn++]=(char)k->ch;pbuf[pn]=0;}
        return;
    }
    if(k->mods&MOD_CTRL){
        if(k->sc==0x1F){do_save();return;}                                   /* Ctrl+S */
        if(k->sc==0x31){editor_new();return;}                                /* Ctrl+N */
        if(k->sc==0x18){prompt=2;pbuf[0]=0;pn=0;return;}                     /* Ctrl+O */
        return;
    }
    if(k->sc==K_LEFT){if(cur>0){cur--;while(cur>0&&is_cont(cur))cur--;}want_col=col_of(cur);return;}
    if(k->sc==K_RIGHT){if(cur<n){cur++;while(is_cont(cur))cur++;}want_col=col_of(cur);return;}
    if(k->sc==K_UP){move_lines(-1);return;} if(k->sc==K_DOWN){move_lines(1);return;}
    if(k->sc==K_PGUP){move_lines(-20);return;} if(k->sc==K_PGDN){move_lines(20);return;}
    if(k->sc==K_HOME){cur=ls_of(cur);want_col=0;return;} if(k->sc==K_END){cur=le_of(cur);want_col=col_of(cur);return;}
    if(k->sc==K_DEL){del_fwd();return;}
    if(k->ch==8){del_back();return;}
    if(k->ch=='\n'){ins("\n",1);return;}
    if(k->ch=='\t'){ins("    ",4);return;}
    if(k->ch>=32&&k->ch<127){char c=(char)k->ch;ins(&c,1);}
}

static int last_cur=-1;
static int line_off(int line){int p=0;while(line>0&&p<n){if(buf[p]=='\n')line--;p++;}return p;}
static void geo(Window *w,int *tx,int *ty,int *tw,int *th){*tx=CONTENT_X(w);*ty=CONTENT_Y(w)+30;*tw=CONTENT_W(w);*th=CONTENT_H(w)-30-22;}
static void btn(int x,int y,int w,int h,const char *l){int hv=inside(x,y,w,h,mx,my);roundrect(x,y,w,h,5,hv?rgb(30,48,76):rgb(14,22,38));text16(x+(w-text16w(l))/2,y+(h-16)/2,l,C_TEXT);}
void editor_draw(Window *w){
    if(!alloc())return;
    int tx,ty,tw,th;geo(w,&tx,&ty,&tw,&th);
    char t[48];ksnprintf(t,sizeof t,"Editor - %s%s",ename[0]?ename:"untitled",modified?" *":"");scpy(w->title,t,sizeof w->title);
    int bx=CONTENT_X(w),by=CONTENT_Y(w)+2;
    btn(bx,by,50,24,"New");btn(bx+54,by,56,24,"Open");btn(bx+114,by,56,24,"Save");btn(bx+174,by,80,24,"Save As");
    set_clip(CONTENT_X(w),CONTENT_Y(w),CONTENT_W(w),CONTENT_H(w));
    fill(tx,ty,tw,th,rgb(6,10,20));
    int gut=48,rows=th/16,cols=(tw-gut-8)/8;if(rows<1)rows=1;if(cols<4)cols=4;
    int cl=0;for(int i=0;i<cur;i++)if(buf[i]=='\n')cl++;
    int cc=col_of(cur);
    if(cur!=last_cur){
        if(cl<top)top=cl;if(cl>=top+rows)top=cl-rows+1;
        if(cc<left)left=cc;if(cc>=left+cols)left=cc-cols+1;
        last_cur=cur;
    }
    if(top<0)top=0;
    int p=line_off(top);
    for(int r=0;r<rows;r++){
        int y=ty+r*16;
        if(p>n)break;
        char ln[8];ksnprintf(ln,sizeof ln,"%4d",top+r+1);
        text16(tx+2,y,ln,top+r==cl?C_ACC:rgb(70,86,115));
        int q=p,skip=left,x=tx+gut;
        while(q<n&&buf[q]!='\n'&&skip>0){q++;while(is_cont(q))q++;skip--;}
        set_clip(tx+gut,ty,tw-gut,th);
        while(q<n&&buf[q]!='\n'&&x<tx+tw){
            const char *s=buf+q;u32 cp=utf8_next(&s);int adv=(int)(s-(buf+q));
            if(cp=='\r'){q+=adv;continue;}
            x+=draw_cp(x,y,cp,C_TEXT,0);q+=adv;
        }
        set_clip(CONTENT_X(w),CONTENT_Y(w),CONTENT_W(w),CONTENT_H(w));
        if(top+r==cl&&active==APP_EDIT&&!prompt){
            int cx=tx+gut;int qq=p;int sk=left;while(qq<n&&buf[qq]!='\n'&&sk>0){qq++;while(is_cont(qq))qq++;sk--;}
            while(qq<cur){const char *s=buf+qq;u32 cp=utf8_next(&s);cx+=cp_width(cp);qq+=(int)(s-(buf+qq));}
            if((ms_now()/500)&1)fill(cx,y,2,16,C_ACC);else fill(cx,y+14,8,2,C_ACC);
        }
        while(p<n&&buf[p]!='\n')p++;p++;
    }
    fill(tx+gut-4,ty,1,th,rgb(26,36,56));
    /* status line */
    int sy=ty+th+3;
    char st[120];ksnprintf(st,sizeof st,"Ln %d  Col %d   %d bytes   Ctrl+S save  Ctrl+O open  Ctrl+N new",cl+1,cc+1,n);
    text16(tx,sy,st,C_DIM);
    if(msg[0]&&ms_now()-msg_t<4000){int mw=text16w(msg);text16(tx+tw-mw-6,sy,msg,C_YEL);}
    if(prompt){
        int pw=360,px=w->x+(w->w-pw)/2,py=w->y+w->h/2-40;
        roundrect(px,py,pw,80,8,rgb(14,22,40));frame_rect(px,py,pw,80,C_ACC);
        text16(px+14,py+10,prompt==1?"Save as (file name or path):":"Open file:",C_TEXT);
        fill(px+14,py+34,pw-28,24,C_FIELD);text16(px+20,py+38,pbuf,C_TEXT);
        if((ms_now()/500)&1)fill(px+20+text16w(pbuf),py+38,2,16,C_ACC);
        text16(px+14,py+62,"Enter = OK   Esc = cancel",C_DIM);
    }
    clip_reset();
}
void editor_click(Window *w){
    if(!alloc()||prompt)return;
    int tx,ty,tw,th;geo(w,&tx,&ty,&tw,&th);
    int bx=CONTENT_X(w),by=CONTENT_Y(w)+2;
    if(inside(bx,by,50,24,mx,my)){editor_new();return;}
    if(inside(bx+54,by,56,24,mx,my)){prompt=2;pbuf[0]=0;pn=0;return;}
    if(inside(bx+114,by,56,24,mx,my)){do_save();return;}
    if(inside(bx+174,by,80,24,mx,my)){prompt=1;scpy(pbuf,ename,sizeof pbuf);pn=(int)strlen(pbuf);return;}
    if(inside(tx+48,ty,tw-48,th,mx,my)){
        int row=(my-ty)/16;int p=line_off(top+row);
        int q=p,skip=left,x=tx+48;
        while(q<n&&buf[q]!='\n'&&skip>0){q++;while(is_cont(q))q++;skip--;}
        while(q<n&&buf[q]!='\n'){const char *s=buf+q;u32 cp=utf8_next(&s);int cw=cp_width(cp);if(mx<x+cw/2)break;x+=cw;q+=(int)(s-(buf+q));}
        cur=q;want_col=col_of(cur);last_cur=-1;
    }
}
void editor_wheel(int dz){
    int lines=0;for(int i=0;i<n;i++)if(buf[i]=='\n')lines++;
    top+=dz*3;if(top<0)top=0;if(top>lines)top=lines;last_cur=cur;ui_dirty=1;
}
