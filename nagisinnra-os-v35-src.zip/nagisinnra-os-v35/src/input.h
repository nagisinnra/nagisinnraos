#ifndef INPUT_H
#define INPUT_H
#include "nagi.h"
/* Key codes = set-1 make code; extended keys are 0x100|code except arrows/enter which are normalised. */
#define K_ESC 0x01
#define K_BS 0x0E
#define K_TAB 0x0F
#define K_ENTER 0x1C
#define K_SPACE 0x39
#define K_UP 0x48
#define K_LEFT 0x4B
#define K_RIGHT 0x4D
#define K_DOWN 0x50
#define K_HOME 0x147
#define K_PGUP 0x149
#define K_END 0x14F
#define K_PGDN 0x151
#define K_INS 0x152
#define K_DEL 0x153
#define K_F1 0x3B
#define K_F2 0x3C
#define K_F3 0x3D
#define K_F4 0x3E
#define K_F5 0x3F
#define K_F6 0x40
#define K_F7 0x41
#define K_F8 0x42
#define K_F9 0x43
#define K_F10 0x44
#define K_F11 0x57
#define K_F12 0x58
#define MOD_SHIFT 1
#define MOD_CTRL 2
#define MOD_ALT 4
typedef struct { u16 sc; u8 ch; u8 mods; } Key;
extern int mx,my,mbuttons,mwheel;
extern int mpress,mrelease,mpress_r;     /* edge flags, cleared by consumer */
void input_init(void);
void input_poll(void);                    /* drain PS/2 controller */
int key_get(Key *k);
extern int mouse_has_wheel;
#endif
