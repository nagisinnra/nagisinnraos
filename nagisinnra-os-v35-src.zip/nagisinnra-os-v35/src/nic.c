#include "nagi.h"
/* NE2000 / DP8390 driver (polling).  Follows the classic Linux 8390 flow so
   it works on real cards, QEMU (ne2k_isa / ne2k_pci) and v86.
   - 8-bit remote DMA (DCR=0x48) with byte accesses to the data port
   - MAC read from the PROM (handles NE2000 "doubled byte" layout)
   - RX decided by BNRY/CURR ring pointers, not by ISR bits
   - ring wrap handled with two reads                                   */
#define CR 0x00
#define PSTART 0x01
#define PSTOP 0x02
#define BNRY 0x03
#define TPSR 0x04
#define TBCR0 0x05
#define TBCR1 0x06
#define ISR 0x07
#define RSAR0 0x08
#define RSAR1 0x09
#define RBCR0 0x0A
#define RBCR1 0x0B
#define RCR 0x0C
#define TCR 0x0D
#define DCR 0x0E
#define IMR 0x0F
#define CURR 0x07       /* page 1 */
#define PAR0 0x01       /* page 1 */
#define MAR0 0x08       /* page 1 */
#define DATA 0x10
#define RESETP 0x1F
#define TX_PAGE 0x40
#define RX_START 0x46
#define RX_STOP 0x80

static u16 base;
u8 nic_mac[6]; char nic_name[32];
u32 nic_rx_frames,nic_tx_frames,nic_rx_drops;
static int nic_ok;

static inline void o(int r,u8 v){outb(base+r,v);}
static inline u8 i_(int r){return inb(base+r);}

static void dma_read(u8 *dst,int n,u16 addr){
    o(RBCR0,n&255);o(RBCR1,n>>8);o(RSAR0,addr&255);o(RSAR1,addr>>8);
    o(CR,0x0A);
    for(int i=0;i<n;i++)dst[i]=i_(DATA);
    u32 t=ms_now(); while(!(i_(ISR)&0x40)){ if(ms_now()-t>5)break; }
    o(ISR,0x40);
}
static void rx_ring_init(void){
    o(CR,0x21);
    o(PSTART,RX_START);o(PSTOP,RX_STOP);o(BNRY,RX_START);
    o(CR,0x61);o(CURR,RX_START+1);
    o(CR,0x21);
    o(ISR,0xFF);
}
static int probe(u16 b){
    base=b;
    if(i_(CR)==0xFF && i_(ISR)==0xFF) return 0;
    u8 r=i_(RESETP); o(RESETP,r);
    u32 t=ms_now(); while(!(i_(ISR)&0x80)){ if(ms_now()-t>100)break; }
    u8 c=i_(CR);
    if(c==0xFF) return 0;
    if(!((c&0x3f)==0x21||(i_(ISR)&0x80))) return 0;
    o(CR,0x21); o(DCR,0x48); o(RBCR0,0); o(RBCR1,0); o(RCR,0x20); o(TCR,0x02);
    u8 prom[32]; dma_read(prom,32,0);
    int doubled=1; for(int i=0;i<12;i+=2) if(prom[i]!=prom[i+1]) doubled=0;
    int found=0;
    if(doubled){ for(int i=0;i<6;i++)nic_mac[i]=prom[i*2]; found=1; }
    else { for(int i=0;i<6;i++)nic_mac[i]=prom[i]; found=1; }
    int allz=1,allf=1; for(int i=0;i<6;i++){ if(nic_mac[i])allz=0; if(nic_mac[i]!=0xff)allf=0; }
    if(allz||allf){                         /* fall back to the PAR registers */
        o(CR,0x61); for(int i=0;i<6;i++)nic_mac[i]=i_(PAR0+i); o(CR,0x21);
        allz=allf=1; for(int i=0;i<6;i++){ if(nic_mac[i])allz=0; if(nic_mac[i]!=0xff)allf=0; }
        if(allz||allf) return 0;
    }
    return 1;
}
static void start(void){
    o(CR,0x21); o(DCR,0x48); o(RBCR0,0); o(RBCR1,0);
    o(RCR,0x20); o(TCR,0x02);
    o(TPSR,TX_PAGE);
    rx_ring_init();
    o(IMR,0);
    o(CR,0x61);
    for(int i=0;i<6;i++)o(PAR0+i,nic_mac[i]);
    for(int i=0;i<8;i++)o(MAR0+i,0);
    o(CURR,RX_START+1);
    o(CR,0x22);
    o(TCR,0x00);
    o(RCR,0x04);                            /* broadcast + our unicast */
}
static u32 pci_cfg(int bus,int dev,int fn,int off){
    outl(0xCF8,0x80000000u|((u32)bus<<16)|((u32)dev<<11)|((u32)fn<<8)|(off&0xfc));
    return inl(0xCFC);
}
static void pci_cfg_w(int bus,int dev,int fn,int off,u32 v){
    outl(0xCF8,0x80000000u|((u32)bus<<16)|((u32)dev<<11)|((u32)fn<<8)|(off&0xfc));
    outl(0xCFC,v);
}
int nic_init(void){
    nic_ok=0;
    /* 1) PCI NE2000 clones */
    for(int bus=0;bus<2&&!nic_ok;bus++)for(int dev=0;dev<32&&!nic_ok;dev++){
        u32 id=pci_cfg(bus,dev,0,0);
        if(id==0xFFFFFFFFu)continue;
        u16 ven=(u16)id,did=(u16)(id>>16);
        int ne=(ven==0x10EC&&did==0x8029)||(ven==0x1050&&did==0x0940)||(ven==0x11F6&&did==0x1401)||(ven==0x8E2E&&did==0x3000)||(ven==0x4A14&&did==0x5000)||(ven==0x1106&&did==0x0926);
        if(!ne)continue;
        u32 bar=pci_cfg(bus,dev,0,0x10);
        if(!(bar&1))continue;
        u16 io=(u16)(bar&0xFFFC);
        pci_cfg_w(bus,dev,0,4,pci_cfg(bus,dev,0,4)|1);
        if(probe(io)){ nic_ok=1; ksnprintf(nic_name,sizeof nic_name,"NE2000 PCI io=%x",io); }
    }
    /* 2) ISA NE2000 at the usual v86/QEMU address, then other classic ones */
    static const u16 isa[]={0x300,0x280,0x320,0x340,0x360};
    for(int k=0;k<5&&!nic_ok;k++){
        if(probe(isa[k])){ nic_ok=1; ksnprintf(nic_name,sizeof nic_name,"NE2000 ISA io=%x",isa[k]); }
    }
    if(!nic_ok){dbg("nic: no NE2000 found (PCI scan + ISA 0x300/280/320/340/360)\n");return 0;}
    start();
    dbgf("nic: %s mac=%02x:%02x:%02x:%02x:%02x:%02x\n",nic_name,nic_mac[0],nic_mac[1],nic_mac[2],nic_mac[3],nic_mac[4],nic_mac[5]);
    return 1;
}
int nic_send(const u8 *f,int len){
    if(!nic_ok||len<14||len>1514)return 0;
    int n=len<60?60:len;
    u32 t=ms_now();
    while(i_(CR)&0x04){ if(ms_now()-t>30)break; }       /* previous TX still running */
    o(ISR,0x40);
    o(RBCR0,n&255);o(RBCR1,n>>8);o(RSAR0,0);o(RSAR1,TX_PAGE);
    o(CR,0x12);
    for(int i=0;i<len;i++)outb(base+DATA,f[i]);
    for(int i=len;i<n;i++)outb(base+DATA,0);
    t=ms_now(); while(!(i_(ISR)&0x40)){ if(ms_now()-t>5)break; }
    o(ISR,0x40);
    o(TPSR,TX_PAGE);o(TBCR0,n&255);o(TBCR1,n>>8);
    o(CR,0x26);
    t=ms_now(); while(!(i_(ISR)&0x0A)){ if(ms_now()-t>20)break; }
    o(ISR,0x0A);
    nic_tx_frames++;
    return 1;
}
int nic_recv(u8 *buf,int cap){
    if(!nic_ok)return 0;
    u8 isr=i_(ISR);
    if(isr&0x10){                      /* ring overflow: restart receiver */
        nic_rx_drops++;
        o(CR,0x21); u32 t=ms_now(); while(ms_now()-t<2){}
        o(RBCR0,0);o(RBCR1,0);o(TCR,0x02);
        rx_ring_init(); o(CR,0x22); o(TCR,0x00);
        return 0;
    }
    if(isr&0x03)o(ISR,isr&0x03);
    for(int guard=0;guard<8;guard++){
        u8 bnry=i_(BNRY); u8 page=bnry+1; if(page>=RX_STOP)page=RX_START;
        o(CR,0x62); u8 curr=i_(CURR); o(CR,0x22);
        if(page==curr)return 0;
        u8 hdr[4]; dma_read(hdr,4,(u16)page<<8);
        u8 next=hdr[1]; int total=hdr[2]|(hdr[3]<<8);
        if(next<RX_START||next>=RX_STOP||total<4+14||total>4+1518){
            /* corrupted ring: drop everything */
            nic_rx_drops++;
            u8 nb=curr-1; if(nb<RX_START)nb=RX_STOP-1; o(BNRY,nb);
            return 0;
        }
        int len=total-4;
        u8 nb=next-1; if(nb<RX_START)nb=RX_STOP-1;
        if(len>cap){ o(BNRY,nb); nic_rx_drops++; continue; }
        u32 addr=((u32)page<<8)+4, end=(u32)RX_STOP<<8;
        if(addr+len>end){
            int n1=(int)(end-addr);
            dma_read(buf,n1,(u16)addr);
            dma_read(buf+n1,len-n1,(u16)RX_START<<8);
        } else dma_read(buf,len,(u16)addr);
        o(BNRY,nb);
        nic_rx_frames++;
        return len;
    }
    return 0;
}
