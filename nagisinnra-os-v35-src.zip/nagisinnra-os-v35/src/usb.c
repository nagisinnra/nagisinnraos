#include <stdint.h>
#include "nagi.h"
void term_line(const char*s);
static uint32_t pci_read32(uint8_t bus,uint8_t dev,uint8_t fn,uint8_t off);
static uint32_t pci_read32(uint8_t bus,uint8_t dev,uint8_t fn,uint8_t off){outl(0xcf8,0x80000000u|((uint32_t)bus<<16)|((uint32_t)dev<<11)|((uint32_t)fn<<8)|(off&0xfcu));return inl(0xcfc);}

typedef struct {uint32_t fat_lba,data_lba,root_cluster,sectors_per_fat;uint16_t bytes_per_sector;uint8_t sectors_per_cluster;} Fat32;
static Fat32 usb_fat;
static int usb_present=0,usb_mounted=0,uhci_io=0;
static uint8_t *uhci_frame=0,*uhci_qh=0,*uhci_td=0,*usb_buf=0;
static uint8_t usb_addr=0,usb_mps=8,usb_in_ep=0,usb_out_ep=0,usb_in_mps=64,usb_out_mps=64,usb_in_toggle=0,usb_out_toggle=0;
static uint32_t usb_lun=0,usb_tag=0x4e534f31u;

static uint16_t u16le(const uint8_t*p){return (uint16_t)p[0]|((uint16_t)p[1]<<8);}
static uint32_t u32le(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void u32store(uint8_t*p,uint32_t v){p[0]=v;p[1]=v>>8;p[2]=v>>16;p[3]=v>>24;}

/* UHCI TD/QH layout, identity-mapped physical RAM in this hobby kernel. */
typedef struct __attribute__((packed,aligned(16))){uint32_t link,status,token,buffer;} UhciTD;
typedef struct __attribute__((packed,aligned(16))){uint32_t head,element;} UhciQH;
#define TD_ACTIVE (1u<<23)
#define TD_IOC    (1u<<24)
#define TD_ERRMSK (7u<<27)
#define TD_LINK_TERM 1u
#define TD_LINK_QH 2u
#define UHCI_MAXTD 32
static UhciTD *tds(void){return (UhciTD*)uhci_td;}
static UhciQH *qh(void){return (UhciQH*)uhci_qh;}
static uint32_t td_token(uint8_t pid,uint8_t addr,uint8_t ep,uint8_t toggle,uint16_t len){uint32_t ml=(len?((uint32_t)len-1):0x7ffu);return pid|((uint32_t)addr<<8)|((uint32_t)ep<<15)|((uint32_t)toggle<<19)|(ml<<21);}
static int uhci_wait(int count){for(uint32_t n=0;n<3000000;n++){if(!(tds()[count-1].status&TD_ACTIVE)){for(int i=0;i<count;i++)if(tds()[i].status&TD_ERRMSK)return 0;return 1;}}return 0;}
static int uhci_run_tds(int count){UhciTD*t=tds();for(int i=0;i<count;i++)t[i].link=(i+1<count)?((uint32_t)(uintptr_t)&t[i+1]):TD_LINK_TERM;qh()->element=(uint32_t)(uintptr_t)&t[0];uint16_t cmd=inl((uint16_t)uhci_io)&0xffffu;cmd|=1;outb((uint16_t)uhci_io,(uint8_t)cmd);if(!uhci_wait(count)){cmd=inl((uint16_t)uhci_io)&0xffffu;cmd&=(uint16_t)~1u;outb((uint16_t)uhci_io,(uint8_t)cmd);return 0;}cmd=inl((uint16_t)uhci_io)&0xffffu;cmd&=(uint16_t)~1u;outb((uint16_t)uhci_io,(uint8_t)cmd);return 1;}

static void uhci_td_reset(void){for(int i=0;i<UHCI_MAXTD;i++){tds()[i].status=0;tds()[i].link=TD_LINK_TERM;tds()[i].buffer=0;tds()[i].token=0;}}
static int uhci_control(const uint8_t*setup,uint8_t*data,uint16_t len,int in){
 uhci_td_reset();int n=0;uint8_t toggle=0;
 tds()[n].status=TD_ACTIVE|((len==0)?TD_IOC:0);tds()[n].token=td_token(0x2d,usb_addr,0,0,8);tds()[n].buffer=(uint32_t)(uintptr_t)setup;n++;
 if(len){uint16_t off=0;while(off<len&&n<UHCI_MAXTD-2){uint16_t take=(uint16_t)(len-off);if(take>usb_mps)take=usb_mps;tds()[n].status=TD_ACTIVE|(off+take>=len?TD_IOC:0);tds()[n].token=td_token(in?0x69:0xe1,usb_addr,0,toggle,take);tds()[n].buffer=(uint32_t)(uintptr_t)(data+off);toggle^=1;off+=take;n++;}}
 tds()[n].status=TD_ACTIVE|TD_IOC;tds()[n].token=td_token(in?0xe1:0x69,usb_addr,0,1,0);tds()[n].buffer=0;n++;
 return uhci_run_tds(n);
}
static int uhci_bulk(uint8_t ep,uint8_t *buf,uint16_t len,int in){
 uhci_td_reset();uint8_t*cur=buf;uint16_t left=len;int n=0;uint8_t *toggle=in?&usb_in_toggle:&usb_out_toggle;while(left&&n<UHCI_MAXTD){uint16_t take=left;if(take>512)take=512;tds()[n].status=TD_ACTIVE|TD_IOC;tds()[n].token=td_token(in?0x69:0xe1,usb_addr,ep&0x0f,*toggle,take);tds()[n].buffer=(uint32_t)(uintptr_t)cur;*toggle^=1;cur+=take;left-=take;n++;}return left?0:uhci_run_tds(n);
}
static int uhci_find(void){
 uhci_io=0;for(int b=0;b<8;b++)for(int d=0;d<32;d++){uint32_t id=pci_read32((uint8_t)b,(uint8_t)d,0,0);if(id==0xffffffffu)continue;uint32_t cc=pci_read32((uint8_t)b,(uint8_t)d,0,8);if((cc>>24)==0x0c&&((cc>>16)&255)==0x03&&((cc>>8)&255)==0x00){uint32_t bar=pci_read32((uint8_t)b,(uint8_t)d,0,0x20);if((bar&1)&&bar!=0xffffffffu){uhci_io=(uint16_t)(bar&0xfffcu);return 1;}}}return 0;
}
static int uhci_init(void){
 if(!uhci_find())return 0;
 uhci_frame=(uint8_t*)mem_alloc_pages(1);uhci_qh=(uint8_t*)mem_alloc_pages(1);uhci_td=(uint8_t*)mem_alloc_pages(1);usb_buf=(uint8_t*)mem_alloc_pages(2);if(!uhci_frame||!uhci_qh||!uhci_td||!usb_buf)return 0;
 for(int i=0;i<1024;i++)((uint32_t*)uhci_frame)[i]=((uint32_t)(uintptr_t)qh())|TD_LINK_QH;qh()->head=TD_LINK_TERM;qh()->element=TD_LINK_TERM;
 outb((uint16_t)uhci_io+2,0xff);outb((uint16_t)uhci_io+3,0);outb((uint16_t)uhci_io+4,0);outb((uint16_t)uhci_io+5,0);outb((uint16_t)uhci_io+6,0);outb((uint16_t)uhci_io+7,0);outl((uint16_t)uhci_io+8,(uint32_t)(uintptr_t)uhci_frame);outb((uint16_t)uhci_io+0x0c,64);
 uint16_t cmd=0x0002;outb((uint16_t)uhci_io,(uint8_t)cmd);for(volatile int i=0;i<100000;i++);outb((uint16_t)uhci_io,0); 
 for(int port=0;port<2;port++){uint16_t p=(uint16_t)uhci_io+0x10+(uint16_t)port*2;uint16_t v=inb(p)|((uint16_t)inb(p+1)<<8);if(v&1){outb(p,(uint8_t)(v|0x80));outb(p+1,(uint8_t)((v|0x80)>>8));for(volatile int i=0;i<150000;i++);v=inb(p)|((uint16_t)inb(p+1)<<8);v|=4;outb(p,(uint8_t)v);outb(p+1,(uint8_t)(v>>8));}}
 uint16_t c=inb(uhci_io)|((uint16_t)inb(uhci_io+1)<<8);c|=1;outb(uhci_io,(uint8_t)c);outb(uhci_io+1,(uint8_t)(c>>8));return 1;
}
static int usb_get_desc(uint8_t type,uint8_t idx,uint8_t*buf,uint16_t len){uint8_t s[8]={0x80,6,type,idx,0,0,(uint8_t)len,(uint8_t)(len>>8)};return uhci_control(s,buf,len,1);}
static int usb_set_addr(uint8_t a){uint8_t s[8]={0,5,a,0,0,0,0,0};if(!uhci_control(s,0,0,0))return 0;usb_addr=a;return 1;}
static int usb_set_cfg(uint8_t c){uint8_t s[8]={0,9,c,0,0,0,0,0};return uhci_control(s,0,0,0);}
static int usb_bot_reset(void){uint8_t s[8]={0x21,0xff,0,0,0,0,0,0};return uhci_control(s,0,0,0);}
static int usb_get_lun(void){uint8_t s[8]={0xa1,0xfe,0,0,0,0,1,0};uint8_t x=0;if(!uhci_control(s,&x,1,1))return 0;usb_lun=x;return 1;}
static int usb_msc_probe(void){
 uint8_t*d=usb_buf;if(!uhci_init())return 0;usb_addr=0;usb_mps=8;if(!usb_get_desc(1,0,d,8))return 0;usb_mps=d[7];if(!usb_set_addr(1))return 0;for(volatile int i=0;i<30000;i++);if(!usb_get_desc(2,0,d,9))return 0;uint16_t total=u16le(d+2);if(total>1024)total=1024;if(!usb_get_desc(2,0,d,total))return 0;uint8_t cfg=d[5],msc_iface=0xff,found=0;int msc=0;for(uint16_t p=0;p+2<total;){uint8_t l=d[p],t=d[p+1];if(!l)break;if(t==4&&l>=9){msc=(d[p+5]==8&&d[p+6]==6&&d[p+7]==80);if(msc)msc_iface=d[p+2];else msc=0;}if(t==5&&l>=7&&msc){uint8_t ep=d[p+2],attr=d[p+3]&3;if(attr==2){if(ep&0x80){usb_in_ep=ep;usb_in_mps=u16le(d+p+4);}else{usb_out_ep=ep;usb_out_mps=u16le(d+p+4);}}}p+=l;}
 if(!usb_in_ep||!usb_out_ep)return 0;if(!usb_set_cfg(cfg))return 0;usb_in_toggle=usb_out_toggle=0;usb_bot_reset();usb_get_lun();found=1;usb_present=found;return found;
}
static int usb_bot_cmd(uint8_t*cmd,uint8_t cmdlen,uint8_t*data,uint32_t len,int in){
 uint8_t cbw[31];for(int i=0;i<31;i++)cbw[i]=0;u32store(cbw,0x43425355);u32store(cbw+4,++usb_tag);u32store(cbw+8,len);cbw[12]=in?0x80:0;cbw[14]=cmdlen;cbw[13]=(uint8_t)usb_lun;for(int i=0;i<cmdlen;i++)cbw[15+i]=cmd[i];if(!uhci_bulk(usb_out_ep,cbw,31,0))return 0;if(len&&!uhci_bulk( in?usb_in_ep:usb_out_ep,data,(uint16_t)(len>60000?60000:len),in))return 0;uint8_t csw[13];if(!uhci_bulk(usb_in_ep,csw,13,1))return 0;return u32le(csw)==0x53425355u&&csw[12]==0;
}
static int usb_read_sector(uint32_t lba,uint8_t*b){uint8_t c[10]={0x28,0,0,0,0,0,0,0,1,0};c[2]=lba>>24;c[3]=lba>>16;c[4]=lba>>8;c[5]=lba;return usb_bot_cmd(c,10,b,512,1);}
static int fat32_mount(Fat32*v,const uint8_t*b){if(!v||!b)return 0;uint16_t bs=u16le(b+11);uint8_t spc=b[13],nf=b[16];uint16_t rsv=u16le(b+14);uint32_t fatsz=u32le(b+36),root=u32le(b+44);if(bs!=512||!spc||!rsv||nf<1||!fatsz||root<2)return 0;v->bytes_per_sector=bs;v->sectors_per_cluster=spc;v->fat_lba=rsv;v->sectors_per_fat=fatsz;v->data_lba=rsv+(uint32_t)nf*fatsz;v->root_cluster=root;return 1;}
void usb_scan(void){term_line("USB HOST: UHCI + MASS STORAGE");if(usb_msc_probe())term_line("USB MASS STORAGE READY");else term_line("NO UHCI MSC DEVICE");}
int usb_mount_fat32(void){if(!usb_present&& !usb_msc_probe())return 0;if(!usb_read_sector(0,usb_buf))return 0;if(!fat32_mount(&usb_fat,usb_buf))return 0;usb_mounted=1;return 1;}
static uint32_t fat32_next(uint32_t cl){uint32_t lba=usb_fat.fat_lba+(cl*4)/512;if(!usb_read_sector(lba,usb_buf))return 0xffffffffu;return u32le(usb_buf+(cl*4)%512)&0x0fffffffu;}
int fat32_dir(void){if(!usb_mounted&& !usb_mount_fat32()){term_line("D: FAT32 MOUNT FAILED");return 0;}uint32_t cl=usb_fat.root_cluster;uint8_t *sec=usb_buf;term_line("D: / (FAT32 ROOT)");for(int guard=0;guard<128&&cl>=2&&cl<0x0ffffff8u;guard++){for(uint32_t s=0;s<usb_fat.sectors_per_cluster;s++){uint32_t lba=usb_fat.data_lba+(cl-2)*usb_fat.sectors_per_cluster+s;if(!usb_read_sector(lba,sec))return 0;for(int i=0;i<512;i+=32){uint8_t*a=sec+i;if(a[0]==0)return 1;if(a[0]==0xe5||a[11]==0x0f||a[11]&8)continue;char n[16];int k=0;for(int j=0;j<8&&a[j]!=' ';j++)n[k++]=(char)a[j];if(a[8]!=' '){n[k++]='.';for(int j=8;j<11&&a[j]!=' ';j++)n[k++]=(char)a[j];}n[k]=0;term_line(n);if(k>14)break;}}cl=fat32_next(cl);}return 1;}
void usb_status(void){if(!usb_mounted)term_line("D: NOT MOUNTED");else{term_line("D: FAT32 MOUNTED");term_line("USB MASS STORAGE / SCSI READ10");}}
