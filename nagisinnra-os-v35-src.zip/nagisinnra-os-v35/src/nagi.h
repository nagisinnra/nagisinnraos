#ifndef NAGI_H
#define NAGI_H
#include <stdarg.h>
typedef unsigned char u8; typedef unsigned short u16; typedef unsigned int u32;
typedef signed char s8; typedef short s16; typedef int s32;
#define NULL ((void*)0)
#define VERSION_STR "35"

/* ---- port I/O ---- */
static inline u8 inb(u16 p){u8 v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outb(u16 p,u8 v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}
static inline u16 inw(u16 p){u16 v;__asm__ volatile("inw %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outw(u16 p,u16 v){__asm__ volatile("outw %0,%1"::"a"(v),"Nd"(p));}
static inline u32 inl(u16 p){u32 v;__asm__ volatile("inl %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outl(u16 p,u32 v){__asm__ volatile("outl %0,%1"::"a"(v),"Nd"(p));}

/* ---- lib.c ---- */
void *memcpy(void *d,const void *s,u32 n);
void *memmove(void *d,const void *s,u32 n);
void *memset(void *d,int c,u32 n);
int memcmp(const void *a,const void *b,u32 n);
u32 strlen(const char *s);
int strcmp(const char *a,const char *b);
int strncmp(const char *a,const char *b,u32 n);
int stricmp(const char *a,const char *b);
int strnicmp(const char *a,const char *b,u32 n);
char *strcpy(char *d,const char *s);
char *scpy(char *d,const char *s,int n);          /* bounded, always terminates */
char *strchr(const char *s,int c);
char *strstr(const char *h,const char *n);
char *stristr(const char *h,const char *n);
int ktolower(int c); int ktoupper(int c);
int katoi(const char *s);
int ksnprintf(char *buf,int n,const char *fmt,...);
int kvsnprintf(char *buf,int n,const char *fmt,va_list ap);
void dbg(const char *s);                          /* port 0xE9 debug console */
void dbgf(const char *fmt,...);

/* ---- timer.c ---- */
void timer_init(void);
u32 ms_now(void);                                 /* monotonic milliseconds */
#define TIME_AFTER(a,b) ((s32)((a)-(b))>=0)       /* a >= b */
void rtc_read(int *y,int *mo,int *d,int *h,int *mi,int *s);

/* ---- mem.c ---- */
void mem_init(u32 top_bytes);
void *mem_alloc_pages(u32 count);
void mem_free_pages(void *p,u32 count);
u32 mem_free_pages_count(void);
u32 mem_total_pages_count(void);

/* ---- nic.c ---- */
int nic_init(void);                               /* 1 = found */
int nic_send(const u8 *f,int len);
int nic_recv(u8 *buf,int cap);                    /* 0 = nothing */
extern u8 nic_mac[6];
extern char nic_name[32];
extern u32 nic_rx_frames,nic_tx_frames,nic_rx_drops;

/* ---- net.c ---- */
enum {NET_NONE=0,NET_NOIP,NET_DHCP,NET_UP_DHCP,NET_UP_STATIC};
extern u32 net_ip,net_mask,net_gw,net_dns;
extern int net_state;
#define IP4(a,b,c,d) (((u32)(a)<<24)|((u32)(b)<<16)|((u32)(c)<<8)|(u32)(d))
void net_init(void);
void net_poll(void);                              /* call every main-loop iteration */
void net_dhcp_start(void);
void net_set_static(u32 ip,u32 mask,u32 gw,u32 dns);
int ip_parse(const char *s,u32 *ip);
void ip_str(u32 ip,char *out);                    /* out >= 16 */
/* DNS (one outstanding query) */
int dns_start(const char *name);                  /* 1 = ok */
int dns_poll(u32 *ip);                            /* 1 done, 0 pending, -1 fail */
/* ICMP ping */
int ping_send(u32 ip,int seq);
int ping_poll(u32 *from,int *seq,u32 *rtt_ms);    /* 1 = reply */
/* TCP */
enum {TCP_CLOSED=0,TCP_SYN_SENT,TCP_ESTAB,TCP_FIN_WAIT1,TCP_FIN_WAIT2,TCP_CLOSE_WAIT,TCP_LAST_ACK,TCP_CLOSING};
enum {TCPE_NONE=0,TCPE_REFUSED,TCPE_RESET,TCPE_TIMEOUT,TCPE_NOARP};
int tcp_open(u32 ip,u16 port);
int tcp_state(int id);
int tcp_error(int id);
int tcp_write(int id,const void *d,int n);
int tcp_read(int id,void *d,int max);
int tcp_avail(int id);
int tcp_eof(int id);                              /* peer closed and everything read */
void tcp_close(int id);
void tcp_abort(int id);
void tcp_release(int id);

/* ---- http.c ---- */
enum {HTTP_IDLE=0,HTTP_DNS,HTTP_CONNECT,HTTP_REQUEST,HTTP_HEADERS,HTTP_BODY,HTTP_DONE,HTTP_ERROR,HTTP_WAITNET};
typedef struct {
    int state; int err;
    char host[80]; char path[300]; u16 port; u32 ip;
    int status; char location[300]; char ctype[48];
    int content_length; int chunked;
    u8 *buf; int cap; int len; int truncated;
    int id; u32 deadline; u32 started; int hlen; char hdr[8192];
    int chunk_left; int chunk_state; char chunk_line[20]; int chunk_ll;
    int redirects; int body_started;
} Http;
enum {HE_NONE=0,HE_DNS,HE_CONNECT,HE_TIMEOUT,HE_RESET,HE_BADRESP,HE_NONET,HE_HTTPS,HE_BADURL};
int url_split(const char *url,char *host,int hcap,u16 *port,char *path,int pcap); /* 1 ok, -1 https, 0 bad */
void http_get(Http *h,const char *host,u16 port,const char *path,u8 *buf,int cap);
void http_poll(Http *h);
void http_cancel(Http *h);
const char *http_errstr(int e);
#endif
