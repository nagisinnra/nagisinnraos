.code32
.section .text.entry,"ax"
.global _start
.extern kmain
.extern __bss_start
.extern __bss_end
.extern __image_end
.extern exc_handler
.set RAMDISK,0x200000
_start:
 cli
 cld
 movw $0x10,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%fs
 movw %ax,%gs
 movw %ax,%ss
 movl $0x9f000,%esp
 /* 1) move the FS image that the loader put right after the kernel into the RAM disk */
 movl 0x510,%ecx            /* BootInfo.fs_sectors */
 shll $9,%ecx
 movl $__image_end,%esi
 movl $RAMDISK,%edi
 rep movsb
 /* 2) now it is safe to clear BSS (it overlaps the old FS load area) */
 movl $__bss_start,%edi
 movl $__bss_end,%ecx
 subl %edi,%ecx
 xorl %eax,%eax
 rep stosb
 call kmain
1: hlt
 jmp 1b

/* ---- CPU exception stubs ---- */
.macro EXC_NOERR n
exc\n:
 pushl $0
 pushl $\n
 jmp exc_common
.endm
.macro EXC_ERR n
exc\n:
 pushl $\n
 jmp exc_common
.endm
EXC_NOERR 0
EXC_NOERR 1
EXC_NOERR 2
EXC_NOERR 3
EXC_NOERR 4
EXC_NOERR 5
EXC_NOERR 6
EXC_NOERR 7
EXC_ERR 8
EXC_NOERR 9
EXC_ERR 10
EXC_ERR 11
EXC_ERR 12
EXC_ERR 13
EXC_ERR 14
EXC_NOERR 15
EXC_NOERR 16
EXC_ERR 17
EXC_NOERR 18
EXC_NOERR 19
EXC_NOERR 20
EXC_NOERR 21
EXC_NOERR 22
EXC_NOERR 23
EXC_NOERR 24
EXC_NOERR 25
EXC_NOERR 26
EXC_NOERR 27
EXC_NOERR 28
EXC_NOERR 29
EXC_NOERR 30
EXC_NOERR 31
exc_common:
 cli
 movw $0x10,%ax
 movw %ax,%ds
 movw %ax,%es
 movl 8(%esp),%eax
 movl 4(%esp),%ebx
 movl 0(%esp),%ecx
 pushl %eax
 pushl %ebx
 pushl %ecx
 call exc_handler
2: hlt
 jmp 2b
.global irq_stub
irq_stub:
 iret
.section .rodata
.global exc_table
exc_table:
 .long exc0,exc1,exc2,exc3,exc4,exc5,exc6,exc7,exc8,exc9,exc10,exc11,exc12,exc13,exc14,exc15
 .long exc16,exc17,exc18,exc19,exc20,exc21,exc22,exc23,exc24,exc25,exc26,exc27,exc28,exc29,exc30,exc31
.section .note.GNU-stack,"",@progbits
