#include "nagi.h"
/* Freestanding runtime. Written with rep-string asm so GCC cannot turn the
   loops back into calls to themselves. */
void *memcpy(void *d,const void *s,u32 n){
    void *r=d;
    __asm__ volatile("cld; rep movsb":"+D"(d),"+S"(s),"+c"(n)::"memory");
    return r;
}
void *memmove(void *d,const void *s,u32 n){
    u8 *dd=d;const u8 *ss=s;
    if(dd==ss||!n)return d;
    if(dd<ss||dd>=ss+n){ __asm__ volatile("cld; rep movsb":"+D"(dd),"+S"(ss),"+c"(n)::"memory"); }
    else { dd+=n-1; ss+=n-1; __asm__ volatile("std; rep movsb; cld":"+D"(dd),"+S"(ss),"+c"(n)::"memory"); }
    return d;
}
void *memset(void *d,int c,u32 n){
    void *r=d;
    __asm__ volatile("cld; rep stosb":"+D"(d),"+c"(n):"a"(c):"memory");
    return r;
}
int memcmp(const void *a,const void *b,u32 n){
    const u8 *x=a,*y=b;
    while(n--){ if(*x!=*y)return (int)*x-(int)*y; x++;y++; }
    return 0;
}
u32 strlen(const char *s){u32 n=0;while(s[n])n++;return n;}
int strcmp(const char *a,const char *b){while(*a&&*a==*b){a++;b++;}return (u8)*a-(u8)*b;}
int strncmp(const char *a,const char *b,u32 n){
    while(n&&*a&&*a==*b){a++;b++;n--;}
    return n?(u8)*a-(u8)*b:0;
}
char *strstr(const char *h,const char *n){u32 nl=strlen(n);if(!nl)return (char*)h;for(;*h;h++)if(!strncmp(h,n,nl))return (char*)h;return NULL;}
int ktolower(int c){return (c>='A'&&c<='Z')?c+32:c;}
int ktoupper(int c){return (c>='a'&&c<='z')?c-32:c;}
int stricmp(const char *a,const char *b){
    while(*a&&ktolower((u8)*a)==ktolower((u8)*b)){a++;b++;}
    return ktolower((u8)*a)-ktolower((u8)*b);
}
int strnicmp(const char *a,const char *b,u32 n){
    while(n&&*a&&ktolower((u8)*a)==ktolower((u8)*b)){a++;b++;n--;}
    return n?ktolower((u8)*a)-ktolower((u8)*b):0;
}
char *strcpy(char *d,const char *s){char *r=d;while((*d++=*s++));return r;}
char *scpy(char *d,const char *s,int n){
    int i=0; if(n<=0)return d;
    for(;i<n-1&&s[i];i++)d[i]=s[i];
    d[i]=0; return d;
}
char *strchr(const char *s,int c){
    for(;;s++){ if(*s==(char)c)return (char*)s; if(!*s)return NULL; }
}
char *stristr(const char *h,const char *n){
    u32 nl=strlen(n); if(!nl)return (char*)h;
    for(;*h;h++) if(!strnicmp(h,n,nl))return (char*)h;
    return NULL;
}
int katoi(const char *s){
    int v=0,neg=0; while(*s==' ')s++;
    if(*s=='-'){neg=1;s++;}
    while(*s>='0'&&*s<='9'){v=v*10+(*s-'0');s++;}
    return neg?-v:v;
}
/* ---- printf-lite: %d %u %x %X %s %c %% with width, 0 pad, - left ---- */
int kvsnprintf(char *buf,int n,const char *fmt,va_list ap){
    int o=0;
#define PUT(ch) do{ if(o<n-1)buf[o]=(ch); o++; }while(0)
    for(;*fmt;fmt++){
        if(*fmt!='%'){PUT(*fmt);continue;}
        fmt++;
        int left=0,zero=0,width=0;
        if(*fmt=='-'){left=1;fmt++;}
        if(*fmt=='0'){zero=1;fmt++;}
        while(*fmt>='0'&&*fmt<='9'){width=width*10+(*fmt-'0');fmt++;}
        char tmp[16];int tl=0;const char *str=NULL;
        switch(*fmt){
        case 'd':{int v=va_arg(ap,int);u32 u=v<0?(u32)(-v):(u32)v; if(!u)tmp[tl++]='0'; while(u){tmp[tl++]='0'+u%10;u/=10;} if(v<0)tmp[tl++]='-'; break;}
        case 'u':{u32 u=va_arg(ap,u32); if(!u)tmp[tl++]='0'; while(u){tmp[tl++]='0'+u%10;u/=10;} break;}
        case 'x':case 'X':{u32 u=va_arg(ap,u32); const char *dg=(*fmt=='x')?"0123456789abcdef":"0123456789ABCDEF"; if(!u)tmp[tl++]='0'; while(u){tmp[tl++]=dg[u&15];u>>=4;} break;}
        case 'c':{tmp[tl++]=(char)va_arg(ap,int);break;}
        case 's':{str=va_arg(ap,const char*); if(!str)str="(null)"; break;}
        case '%':{PUT('%');continue;}
        default:{PUT('%');PUT(*fmt);continue;}
        }
        int len=str?(int)strlen(str):tl;
        int pad=width>len?width-len:0;
        if(!left)for(int i=0;i<pad;i++)PUT(zero&&!str?'0':' ');
        if(str){for(int i=0;i<len;i++)PUT(str[i]);}
        else{ /* keep '-' in front of zero padding already handled by PUT order */
            for(int i=tl-1;i>=0;i--)PUT(tmp[i]);
        }
        if(left)for(int i=0;i<pad;i++)PUT(' ');
    }
    if(n>0)buf[o<n?o:n-1]=0;
#undef PUT
    return o;
}
int ksnprintf(char *buf,int n,const char *fmt,...){
    va_list ap;va_start(ap,fmt);int r=kvsnprintf(buf,n,fmt,ap);va_end(ap);return r;
}
void dbg(const char *s){while(*s)outb(0xE9,(u8)*s++);}
void dbgf(const char *fmt,...){
    char b[200];va_list ap;va_start(ap,fmt);kvsnprintf(b,sizeof b,fmt,ap);va_end(ap);dbg(b);
}
