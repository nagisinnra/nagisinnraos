#include <stdint.h>
#include "gfx.h"
#define W 800
#define H 600
#define backbuf BACKBUF
static int absi(int v);
static uint32_t rng=0x31c0ffeeu;
static uint32_t rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static int absi(int v){return v<0?-v:v;}
static int band_center(int x){
 /* A gently curved diagonal galactic plane. */
 return 430-(x*11)/20+(x*x)/11000;
}
void draw_sky(void){
 /* Near-black exposure with a barely visible blue-violet depth gradient. */
 for(int y=0;y<H;y++){
  int t=(y*255)/(H-1);
  uint8_t r=(uint8_t)(1+(2*t)/255);
  uint8_t g=(uint8_t)(2+(3*t)/255);
  uint8_t b=(uint8_t)(7+(9*t)/255);
  fill(0,y,W,1,rgb(r,g,b));
 }

 /* Low-resolution irregular Milky Way glow.  Several overlapping lobes
    create large-scale structure without drawing obvious geometric shapes. */
 for(int y=0;y<H;y+=2)for(int x=0;x<W;x+=2){
  int c=band_center(x), d=absi(y-c);
  int glow=0;
  if(d<150) glow=(150-d)/3;
  /* broad secondary clouds along the galactic plane */
  int dx=x-585,dy=y-300;
  int q=(dx*dx)/150+(dy*dy)/80;
  if(q<150) glow+= (150-q)/5;
  dx=x-315;dy=y-405;
  q=(dx*dx)/210+(dy*dy)/105;
  if(q<130) glow+= (130-q)/7;
  if(glow>26)glow=26;
  if(glow>0){
   uint32_t h=(uint32_t)(x*1103515245u+y*12345u);
   int variation=(int)((h>>24)&7)-3;
   int v=glow+variation;
   if(v<2)v=2;
   putp(x,y,rgb((uint8_t)(v/3),(uint8_t)(v/2),(uint8_t)(v+5)));
  }
 }

 /* Dark dust lanes: long broken gaps following the galactic plane. */
 rng=0x6d2b79f5u;
 for(int i=0;i<1800;i++){
  int x=(int)(rnd()%W), y=(int)(rnd()%H);
  int c=band_center(x), d=absi(y-c);
  if(d<78){
   int lane=((x*7+y*3+(int)(rnd()%31))%113);
   if(lane<15 || (x>350&&x<680&&lane>48&&lane<62))
    putp(x,y,rgb(1,2,6));
  }
 }

 /* Galactic stars: positions are sampled around the band rather than
    uniformly over the whole screen.  Triangular jitter makes the density
    fall off naturally toward the edges. */
 rng=0xa17c91e3u;
 for(int i=0;i<2300;i++){
  int x=(int)(rnd()%W);
  int c=band_center(x);
  int j=(int)(rnd()%121)-(int)(rnd()%121);
  int y=c+j;
  if((unsigned)y>=H)continue;
  int d=absi(y-c);
  uint32_t q=rnd()%1000;
  /* Dust hides a portion of stars near the darkest lanes. */
  if(d<58 && q<115 && ((x+y)%17)<5)continue;
  uint8_t v;
  if(q<930)v=(uint8_t)(48+rnd()%68);       /* overwhelming majority: dim */
  else if(q<992)v=(uint8_t)(125+rnd()%75); /* occasional medium stars */
  else v=(uint8_t)(205+rnd()%45);          /* rare bright stars */
  uint32_t hue=rnd()%20;
  if(hue==0)putp(x,y,rgb(v,(uint8_t)(v-18),(uint8_t)(v-6)));
  else if(hue==1)putp(x,y,rgb((uint8_t)(v-12),(uint8_t)(v-5),v));
  else putp(x,y,rgb(v,(uint8_t)(v-2),v));
 }

 /* Sparse foreground/background field stars.  Strongly biased toward
    darkness so the empty sky remains visibly empty. */
 rng=0x48b17e21u;
 for(int i=0;i<520;i++){
  int x=(int)(rnd()%W),y=(int)(rnd()%H);
  int d=absi(y-band_center(x));
  if(d<115)continue;
  uint32_t q=rnd()%100;
  if(q<72)continue;
  uint8_t v=(uint8_t)(55+rnd()%95);
  putp(x,y,rgb(v,(uint8_t)(v-3),(uint8_t)(v+5)));
 }

 /* Only a handful of genuinely bright stars. */
 rng=0x7f4a7c15u;
 for(int i=0;i<16;i++){
  int x=(int)(rnd()%W),y=(int)(rnd()%H);
  uint8_t v=(uint8_t)(210+rnd()%46);
  putp(x,y,rgb(v,v,v));
  if((i&3)==0){
   if(x>0)putp(x-1,y,rgb(v/3,v/3,v/3));
   if(x+1<W)putp(x+1,y,rgb(v/3,v/3,v/3));
   if(y>0)putp(x,y-1,rgb(v/3,v/3,v/3));
   if(y+1<H)putp(x,y+1,rgb(v/3,v/3,v/3));
  }
 }
}
/* FAT12 RAM volume. */
