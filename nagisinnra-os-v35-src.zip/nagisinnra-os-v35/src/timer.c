#include "nagi.h"
/* Time base: PIT channel 0 free-running at 1.193182 MHz, polled.  We only
   need to be called more often than the 54.9 ms wrap; if a stall is longer we
   under-count (timers fire late, never early). */
static u32 last_cnt, ms_acc, frac;
static int pit_ok=1;
static u32 fallback_calls;
static u16 pit_read(void){ outb(0x43,0x00); u8 lo=inb(0x40); u8 hi=inb(0x40); return (u16)(lo|(hi<<8)); }
void timer_init(void){
    outb(0x43,0x34); outb(0x40,0); outb(0x40,0);       /* ch0, lo/hi, mode 2, reload 65536 */
    last_cnt=pit_read(); ms_acc=0; frac=0;
    /* sanity: does the counter move? */
    u16 a=pit_read(); int moved=0;
    for(volatile int i=0;i<200000;i++){ if(pit_read()!=a){moved=1;break;} }
    pit_ok=moved;
    last_cnt=pit_read();
}
u32 ms_now(void){
    if(!pit_ok){ fallback_calls++; return fallback_calls/50; }
    u32 now=pit_read();
    u32 delta=(last_cnt-now)&0xffff;
    last_cnt=now;
    frac+=delta;
    ms_acc+=frac/1193; frac%=1193;
    return ms_acc;
}
static int bcd(int v){return (v&15)+((v>>4)*10);}
static u8 cmos(u8 r){outb(0x70,r);return inb(0x71);}
void rtc_read(int *y,int *mo,int *d,int *h,int *mi,int *s){
    for(int t=0;t<1000&&(cmos(0x0a)&0x80);t++);
    int sec=cmos(0),min=cmos(2),hr=cmos(4),day=cmos(7),mon=cmos(8),yr=cmos(9),cen=cmos(0x32),b=cmos(0x0b);
    if(!(b&4)){sec=bcd(sec);min=bcd(min);hr=bcd(hr&0x7f)|(hr&0x80);day=bcd(day);mon=bcd(mon);yr=bcd(yr);cen=bcd(cen);}
    if(!(b&2)&&(hr&0x80)){hr=((hr&0x7f)%12)+12;}
    if(cen<19||cen>30)cen=20;
    *y=cen*100+yr;*mo=mon;*d=day;*h=hr;*mi=min;*s=sec;
}
