#include "wm.h"
#include "fat12.h"
void idt_init(void);
#define RAMDISK ((u8*)0x200000)
#define RAMDISK_BYTES (4000u*512u)
typedef struct{u32 magic,mem_kb,drive,ksec,fs_sectors,vbe;}BootInfo;
static int drag_win=-1,resize_win=-1;

static void pick_active(void){
    int best=-1,bz=-1;for(int i=0;i<NAPPS;i++)if(win[i].open&&zorder[i]>bz){bz=zorder[i];best=i;}
    active=best;
}
static void close_win(int id){win[id].open=0;if(active==id)pick_active();ui_dirty=1;}
static void key_dispatch(Key *k){
    if(k->sc==K_ESC&&start_menu){start_menu=0;return;}
    /* global shortcuts */
    switch(k->sc){
    case K_F1:open_app(APP_TERM);return;case K_F2:open_app(APP_FILES);return;case K_F3:open_app(APP_EDIT);return;
    case K_F4:open_app(APP_PAINT);return;case K_F5:open_app(APP_TASKS);return;case K_F6:open_app(APP_BROWSER);return;
    case K_F10:open_app(APP_GAMES);return;case K_F12:open_app(APP_ARCADE);return;
    case K_F7:open_app(APP_TETRIS);return;case K_F8:open_app(APP_SNAKE);return;case K_F9:open_app(APP_MINES);return;
    }
    if((k->mods&MOD_CTRL)&&k->sc==0x11&&active>=0){close_win(active);return;}     /* Ctrl+W */
    if(active<0||!win[active].open)return;
    switch(active){
    case APP_TERM:term_key(k);break;case APP_FILES:files_key(k);break;case APP_EDIT:editor_key(k);break;
    case APP_BROWSER:browser_key(k);break;
    default:games_key(k);break;
    }
}
static void press(void){
    if(start_menu&&start_menu_click())return;
    if(my>=578){taskbar_click();return;}
    int id=top_at(mx,my);
    if(id<0){start_menu=0;return;}
    Window *w=&win[id];
    active=id;raise_window(id);start_menu=0;
    if(inside(w->x+w->w-30,w->y,30,28,mx,my)){close_win(id);return;}
    if(w->resizable&&inside(w->x+w->w-48,w->y,18,28,mx,my)){toggle_max(id);return;}
    if(w->resizable&&inside(w->x+w->w-66,w->y,18,28,mx,my)){close_win(id);return;}
    if(inside(w->x,w->y,w->w,28,mx,my)){if(!w->max){drag_win=id;w->ox=mx-w->x;w->oy=my-w->y;}return;}
    if(w->resizable&&!w->max&&inside(w->x+w->w-16,w->y+w->h-16,16,16,mx,my)){resize_win=id;return;}
    switch(id){
    case APP_TERM:term_click(w);break;case APP_FILES:files_click(w);break;case APP_EDIT:editor_click(w);break;
    case APP_PAINT:paint_click(w);break;case APP_TASKS:sys_click(w);break;case APP_BROWSER:browser_click(w);break;
    default:games_click(id,w);break;
    }
}
void kmain(void){
    BootInfo *bi=(BootInfo*)0x500;
    idt_init();
    timer_init();
    u32 top=0x01000000u;
    if(bi->magic==0x3547414Eu&&bi->mem_kb>=15*1024)top=0x100000u+bi->mem_kb*1024u;
    mem_init(top);
    gfx_init();
    memset(RAMDISK+bi->fs_sectors*512u,0,RAMDISK_BYTES-bi->fs_sectors*512u);
    fs_init(RAMDISK);
    drawbuf=SKYBUF;draw_sky();drawbuf=BACKBUF;copy_sky();
    input_init();net_init();
    wm_init();term_init();files_init();editor_init();paint_init();browser_init();games_init();
    term_run_boot();
    redraw();
    int lmx=-1,lmy=-1,lmb=0,hover_pending=0;u32 last_sec=0,last_blink=0,last_redraw=0;
    for(;;){
        u32 now=ms_now();
        input_poll();net_poll();
        term_tick(now);browser_tick(now);if(games_tick(now))ui_dirty=1;
        if(mx!=lmx||my!=lmy){lmx=mx;lmy=my;cursor_move_fast();hover_pending=1;}
        if(mbuttons!=lmb){lmb=mbuttons;ui_dirty=1;}
        if(hover_pending&&now-last_redraw>=40){hover_pending=0;ui_dirty=1;}
        Key k;int guard=0;
        while(guard++<32&&key_get(&k)){ui_dirty=1;key_dispatch(&k);}
        if(mwheel){
            int id=top_at(mx,my);if(id<0)id=active;
            int dz=mwheel;mwheel=0;
            if(id==APP_TERM)term_wheel(dz);else if(id==APP_FILES)files_wheel(dz);else if(id==APP_EDIT)editor_wheel(dz);else if(id==APP_BROWSER)browser_wheel(dz);
            ui_dirty=1;
        }
        if(mpress){mpress=0;press();ui_dirty=1;}
        if(mpress_r){mpress_r=0;}
        if(mbuttons&1){
            if(drag_win>=0){
                Window *w=&win[drag_win];int nx=mx-w->ox,ny=my-w->oy;
                if(nx<0)nx=0;if(ny<0)ny=0;if(nx+w->w>SW)nx=SW-w->w;if(ny+w->h>578)ny=578-w->h;
                w->x=nx;w->y=ny;
            } else if(resize_win>=0){
                Window *w=&win[resize_win];int nw=mx-w->x+6,nh=my-w->y+6;
                if(nw<w->minw)nw=w->minw;if(nh<w->minh)nh=w->minh;if(w->x+nw>SW)nw=SW-w->x;if(w->y+nh>578)nh=578-w->y;
                if(nw!=w->w||nh!=w->h){w->w=nw;w->h=nh;if(resize_win==APP_BROWSER)browser_resized(w);}
            } else if(active==APP_PAINT&&win[APP_PAINT].open)paint_drag(&win[APP_PAINT]);
            else if(active==APP_BROWSER&&win[APP_BROWSER].open)browser_drag(&win[APP_BROWSER]);
        }
        if(mrelease){mrelease=0;drag_win=-1;resize_win=-1;ui_dirty=1;}
        if(now-last_blink>=500){last_blink=now;if(active==APP_TERM||active==APP_EDIT||active==APP_BROWSER||active==APP_FILES)ui_dirty=1;}
        if(now/1000!=last_sec){last_sec=now/1000;ui_dirty=1;}
        if(ui_dirty){ui_dirty=0;hover_pending=0;redraw();last_redraw=ms_now();}
    }
}
