"""Python driver for nagiemu: boot, input injection, screenshots."""
import ctypes, os, sys
import numpy as np
from PIL import Image
_here=os.path.dirname(os.path.abspath(__file__))
L=ctypes.CDLL(os.path.join(_here,'libnagiemu.so'))
L.emu_init.argtypes=[ctypes.c_uint32]; L.emu_init.restype=ctypes.c_int
L.emu_set_disk.argtypes=[ctypes.c_char_p,ctypes.c_uint32]
L.emu_set_nic.argtypes=[ctypes.c_int,ctypes.c_char_p]
L.emu_boot.argtypes=[ctypes.c_int]
L.emu_run.argtypes=[ctypes.c_uint64]; L.emu_run.restype=ctypes.c_int
L.emu_fault.restype=ctypes.c_char_p
L.emu_icount.restype=ctypes.c_uint64; L.emu_vticks.restype=ctypes.c_uint64
L.emu_ram.restype=ctypes.c_void_p; L.emu_fb.restype=ctypes.c_void_p
L.emu_reg.argtypes=[ctypes.c_int]; L.emu_reg.restype=ctypes.c_uint32
L.emu_key.argtypes=[ctypes.c_uint8]
L.emu_mouse.argtypes=[ctypes.c_int]*4
L.emu_nic_rx.argtypes=[ctypes.c_char_p,ctypes.c_int]; L.emu_nic_rx.restype=ctypes.c_int
L.emu_nic_tx_pop.argtypes=[ctypes.c_char_p,ctypes.c_int]; L.emu_nic_tx_pop.restype=ctypes.c_int
L.emu_nic_dropped.restype=ctypes.c_uint64
L.emu_nic_state.argtypes=[ctypes.c_int]; L.emu_nic_state.restype=ctypes.c_uint32
L.emu_set_no_ext.argtypes=[ctypes.c_int]
L.emu_watch.argtypes=[ctypes.c_uint32]
L.emu_watch2.argtypes=[ctypes.c_uint32,ctypes.c_uint32]
L.emu_watch2_n.restype=ctypes.c_uint64; L.emu_watch2_sum.restype=ctypes.c_uint64
L.emu_watch_hits.restype=ctypes.c_uint64; L.emu_watch_span.restype=ctypes.c_uint64

class Emu:
    def __init__(self, img, mem_mb=64, nic=0, mac=b'\x52\x54\x00\x12\x34\x56'):
        self.img=img if isinstance(img,bytes) else open(img,'rb').read()
        assert L.emu_init(mem_mb<<20)
        self._disk=ctypes.create_string_buffer(self.img,len(self.img))
        L.emu_set_disk(self._disk,len(self.img))
        L.emu_set_nic(nic,mac)
        L.emu_boot(0)
        self.rxq=[]
    def run(self,n):
        r=L.emu_run(n)
        return r
    @property
    def icount(self): return L.emu_icount()
    @property
    def ticks(self): return L.emu_vticks()
    def fault(self): return L.emu_fault().decode()
    def key(self,sc,release=True,ext=False):
        if ext: L.emu_key(0xE0)
        L.emu_key(sc)
        if release:
            if ext: L.emu_key(0xE0)
            L.emu_key(sc|0x80)
    def mouse(self,dx=0,dy=0,btn=0,dz=0): L.emu_mouse(dx,-dy,btn,dz)
    def ram(self,addr,n):
        return ctypes.string_at(L.emu_ram()+addr,n)
    def poke(self,addr,data): ctypes.memmove(L.emu_ram()+addr,data,len(data))
    def reg(self,i): return L.emu_reg(i)
    def screenshot(self,path=None,w=800,h=600,pitch=1600):
        raw=ctypes.string_at(L.emu_fb(),pitch*h)
        a=np.frombuffer(raw,dtype=np.uint8).reshape(h,pitch)[:, :w*2].copy().view('<u2').reshape(h,w)
        r=((a>>11)&31)<<3; g=((a>>5)&63)<<2; b=(a&31)<<3
        im=Image.fromarray(np.dstack([r,g,b]).astype(np.uint8),'RGB')
        if path: im.save(path)
        return im
    def nic_rx(self,frame): return L.emu_nic_rx(frame,len(frame))
    def nic_tx(self):
        out=[]
        buf=ctypes.create_string_buffer(2048)
        while True:
            n=L.emu_nic_tx_pop(buf,2048)
            if not n: break
            out.append(buf.raw[:n])
        return out
    def nic_state(self,i): return L.emu_nic_state(i)
