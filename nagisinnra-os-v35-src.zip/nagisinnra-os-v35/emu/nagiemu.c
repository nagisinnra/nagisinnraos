/* nagiemu.c - small i386 emulator used to test Nagisinnra OS without QEMU/v86.
 * Real mode + flat protected mode, BIOS services (INT10 VBE, INT13 ext, INT15 E820)
 * are emulated at a high level.  Devices: PS/2 kbd+mouse, PIT, PCI cfg, CMOS,
 * NE2000 (DP8390, QEMU-like ring semantics), VBE linear framebuffer.
 * Build: gcc -O2 -shared -fPIC -o libnagiemu.so nagiemu.c
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef int64_t s64;

/* ---------------- memory ---------------- */
static u8 *ram; static u32 ramsz;
#define FB_BASE 0xE0000000u
static u8 *fbm; static const u32 fbsz = 8u << 20;
static u8 dummy[16];
static inline u8 *pm(u32 a) {
    if (a < ramsz) return ram + a;
    if (a - FB_BASE < fbsz) return fbm + (a - FB_BASE);
    return dummy;
}
static inline u8 r8(u32 a) { return *pm(a); }
static inline u16 r16(u32 a) { u16 v; memcpy(&v, pm(a), 2); return v; }
static inline u32 r32(u32 a) { u32 v; memcpy(&v, pm(a), 4); return v; }
static inline void w8(u32 a, u8 v) { *pm(a) = v; }
static inline void w16(u32 a, u16 v) { memcpy(pm(a), &v, 2); }
static inline void w32(u32 a, u32 v) { memcpy(pm(a), &v, 4); }
static inline u32 mrd(u32 a, int sz) { return sz == 8 ? r8(a) : sz == 16 ? r16(a) : r32(a); }
static inline void mwr(u32 a, int sz, u32 v) { if (sz == 8) w8(a, v); else if (sz == 16) w16(a, v); else w32(a, v); }

/* ---------------- cpu state ---------------- */
static u32 R[8], eip;
static u32 CF, PF, AF, ZF, SF, OF, DF, IF;
enum { ES, CS, SS, DS, FS, GS };
static u16 sel[6]; static u32 sbase[6];
static int cs_d, ss_b; /* default operand size / stack size: 1 = 32-bit */
static u32 cr0, gdt_base, gdt_limit, idt_base, idt_limit;
static u64 icount;
static int stopcode; /* 0 run, 1 hlt, 2 fault */
static char faultmsg[160];
static u32 start_eip;

static const u8 *disk; static u32 disksz;
static int vbe_mode_set, vbe_active;
static u32 mem_report_kb;
static int no_ext;
void emu_set_no_ext(int v) { no_ext = v; }

static void fault(const char *m) {
    snprintf(faultmsg, sizeof faultmsg, "%s at cs:eip=%04x:%08x op=%02x %02x %02x %02x %02x %02x", m, sel[CS], start_eip,
             r8(sbase[CS] + start_eip), r8(sbase[CS] + start_eip + 1), r8(sbase[CS] + start_eip + 2),
             r8(sbase[CS] + start_eip + 3), r8(sbase[CS] + start_eip + 4), r8(sbase[CS] + start_eip + 5));
    stopcode = 2;
}

static inline u32 get_flags(void) {
    return 2u | CF | (PF << 2) | (AF << 4) | (ZF << 6) | (SF << 7) | (IF << 9) | (DF << 10) | (OF << 11);
}
static inline void set_flags(u32 f) {
    CF = f & 1; PF = (f >> 2) & 1; AF = (f >> 4) & 1; ZF = (f >> 6) & 1; SF = (f >> 7) & 1;
    IF = (f >> 9) & 1; DF = (f >> 10) & 1; OF = (f >> 11) & 1;
}
static inline u32 parity8(u32 v) { v &= 0xff; v ^= v >> 4; v ^= v >> 2; v ^= v >> 1; return (~v) & 1; }

/* ---------------- devices ---------------- */
/* PS/2 controller */
#define KQ 256
static u8 kq[KQ]; static u8 kq_aux[KQ]; static int kq_h, kq_t;
static int mouse_enabled, mouse_id, mouse_sr_seq[3], mouse_sr_n, kbd_wait_param, mouse_wait_param, ctrl_next_aux;
static u8 ctrl_cmd = 0x45; static int ctrl_pending_cmd = 0;
static void kq_push(u8 v, int aux) { int n = (kq_t + 1) % KQ; if (n == kq_h) return; kq[kq_t] = v; kq_aux[kq_t] = aux; kq_t = n; }

/* PIT */
static u32 pit_reload = 0, pit_latch, pit_latched, pit_rd_hi, pit_wr_hi, pit_wr_tmp, pit_acc_mode = 3;
#define INSN_PER_TICK 30u
static u64 vticks(void) { return icount / INSN_PER_TICK; }
static u32 pit_count(void) { u32 rl = pit_reload ? pit_reload : 65536; return rl - (u32)(vticks() % rl); }

/* PCI */
static u32 pci_addr; static int pci_nic;
static u32 pci_read(u32 a) {
    int bus = (a >> 16) & 255, dev = (a >> 11) & 31, fn = (a >> 8) & 7, off = a & 0xfc;
    if (bus || fn) return 0xffffffffu;
    if (dev == 0) { switch (off) { case 0: return 0x12378086u; case 4: return 0x00000007u; case 8: return 0x06000000u; case 0x0c: return 0; default: return 0; } }
    if (dev == 3 && pci_nic) {
        switch (off) { case 0: return 0x802910ECu; case 4: return 0x00000007u; case 8: return 0x02000000u;
            case 0x0c: return 0; case 0x10: return 0xC101u; case 0x3c: return 0x0100u | 11; default: return 0; }
    }
    return 0xffffffffu;
}

/* NE2000 (DP8390) */
static int ne_on; static u32 ne_base = 0x300;
static u8 ne_mem[65536];
static u8 ne_cmd, ne_isr, ne_imr, ne_dcfg, ne_tcr, ne_tsr, ne_rcr, ne_rsr, ne_curpag, ne_tpsr, ne_bnry, ne_pstart, ne_pstop;
static u16 ne_rsar, ne_rcnt, ne_tbcnt; static u8 ne_phys[6], ne_mult[8]; static u8 ne_mac[6] = {0x52, 0x54, 0x00, 0x12, 0x34, 0x56};
#define NE_PMEM_START (16 * 1024)
#define NE_PMEM_END (32 * 1024)
#define NE_MEM_SIZE NE_PMEM_END
static u8 *txq[256]; static int txlen[256]; static int tx_h, tx_t;
static u64 ne_dropped_full;
static void ne_reset(void) {
    memset(ne_mem, 0, sizeof ne_mem);
    for (int i = 0; i < 6; i++) { ne_mem[i * 2] = ne_mac[i]; ne_mem[i * 2 + 1] = ne_mac[i]; }
    ne_mem[28] = 0x57; ne_mem[29] = 0x57; /* signature at bytes 14,15 in word terms */
    ne_mem[14 * 2] = 0x57; ne_mem[14 * 2 + 1] = 0x57; ne_mem[15 * 2] = 0x57; ne_mem[15 * 2 + 1] = 0x57;
    ne_isr = 0x80; ne_cmd = 0x21; ne_imr = 0; ne_rcr = 0; ne_tcr = 0; ne_dcfg = 0; ne_curpag = 0; ne_bnry = 0; ne_pstart = 0; ne_pstop = 0;
}
static u32 ne_mem_ok(u32 a) { return (a < 32) || (a >= NE_PMEM_START && a < NE_PMEM_END); }
static u8 ne_memr(u32 a) { return ne_mem_ok(a) ? ne_mem[a] : 0xff; }
static void ne_memw(u32 a, u8 v) { if (a >= NE_PMEM_START && a < NE_PMEM_END) ne_mem[a] = v; }
static void ne_dma_update(int len) {
    ne_rsar += len;
    if (ne_rsar == (u32)ne_pstop << 8) ne_rsar = (u32)ne_pstart << 8; /* QEMU behaviour */
    if (ne_rcnt <= len) { ne_rcnt = 0; ne_isr |= 0x40; } else ne_rcnt -= len;
}
static int ne_buffer_full(void) {
    int avail, index, boundary;
    if (ne_curpag == ne_bnry) { /* ring empty or full ambiguity: QEMU treats equal as not full unless start==stop */ }
    index = ne_curpag << 8; boundary = ne_bnry << 8;
    if (index < boundary) avail = boundary - index; else avail = (ne_pstop - ne_pstart) * 256 - (index - boundary);
    if (avail < (1536 + 4 + 4)) return 1;
    return 0;
}
static int ne_receive(const u8 *buf, int size) {
    static const u8 bcast[6] = {255, 255, 255, 255, 255, 255};
    u8 pad[60];
    if (!ne_on) return -1;
    if (ne_cmd & 1) return -1; /* stopped */
    if (ne_pstart == 0 || ne_pstop == 0) return -1;
    if (ne_buffer_full()) { ne_dropped_full++; ne_isr |= 0x10; return -1; }
    if (ne_rcr & 0x10) { } else {
        if (!memcmp(buf, bcast, 6)) { if (!(ne_rcr & 0x04)) return -1; }
        else if (buf[0] & 1) { if (!(ne_rcr & 0x08)) return -1; }
        else if (!memcmp(buf, ne_phys, 6)) { }
        else return -1;
    }
    if (size < 60) { memset(pad, 0, 60); memcpy(pad, buf, size); buf = pad; size = 60; }
    u32 index = ne_curpag << 8;
    if (index >= NE_PMEM_END) index = (u32)ne_pstart << 8;
    int total = size + 4;
    u32 next = index + ((total + 4 + 255) & ~0xff);
    if (next >= (u32)ne_pstop << 8) next -= ((u32)(ne_pstop - ne_pstart) << 8);
    ne_mem[index++] = 1; ne_mem[index++] = next >> 8; ne_mem[index++] = total & 255; ne_mem[index++] = total >> 8;
    u32 end = (u32)ne_pstop << 8; int left = size; const u8 *p = buf;
    while (left > 0) {
        int chunk = left; if (index + chunk > end) chunk = end - index;
        memcpy(ne_mem + index, p, chunk); index += chunk; p += chunk; left -= chunk;
        if (index == end) index = (u32)ne_pstart << 8;
    }
    ne_curpag = next >> 8;
    ne_isr |= 0x01;
    return size;
}
static void ne_ioport_write(u32 addr, u8 val) {
    int page = ne_cmd >> 6;
    if (addr >= 0x10) { if (addr == 0x10) goto data_w; if (addr == 0x1f) { ne_reset(); } return; }
    addr &= 0xf;
    if (addr == 0) {
        ne_cmd = val; if (!(val & 1)) ne_isr &= ~0x80;
        if (val & 0x04) { /* transmit */
            int idx = ne_tpsr << 8; int len = ne_tbcnt;
            if (idx + len <= (int)sizeof ne_mem && len > 0 && len <= 1600) {
                int n = (tx_t + 1) & 255;
                if (n != tx_h) { txq[tx_t] = malloc(len); memcpy(txq[tx_t], ne_mem + idx, len); txlen[tx_t] = len; tx_t = n; }
            }
            ne_tsr = 1; ne_isr |= 0x02; ne_cmd &= ~0x04;
        }
        return;
    }
    if (0) { data_w: /* data port write, byte mode */
        if (ne_dcfg & 1) { /* word mode: 8-bit write still advances 2 in QEMU */
            ne_memw(ne_rsar, val); ne_dma_update(2);
        } else { ne_memw(ne_rsar, val); ne_dma_update(1); }
        return;
    }
    if (page == 0) {
        switch (addr) {
            case 1: ne_pstart = val; break; case 2: ne_pstop = val; break; case 3: ne_bnry = val; break;
            case 4: ne_tpsr = val; break; case 5: ne_tbcnt = (ne_tbcnt & 0xff00) | val; break; case 6: ne_tbcnt = (ne_tbcnt & 0xff) | (val << 8); break;
            case 7: ne_isr &= ~(val & 0x7f); break;
            case 8: ne_rsar = (ne_rsar & 0xff00) | val; break; case 9: ne_rsar = (ne_rsar & 0xff) | (val << 8); break;
            case 10: ne_rcnt = (ne_rcnt & 0xff00) | val; break; case 11: ne_rcnt = (ne_rcnt & 0xff) | (val << 8); break;
            case 12: ne_rcr = val; break; case 13: ne_tcr = val; break; case 14: ne_dcfg = val; break; case 15: ne_imr = val; break;
        }
    } else if (page == 1) {
        if (addr >= 1 && addr <= 6) ne_phys[addr - 1] = val;
        else if (addr == 7) ne_curpag = val;
        else if (addr >= 8 && addr <= 15) ne_mult[addr - 8] = val;
    }
}
static u8 ne_ioport_read(u32 addr) {
    int page = ne_cmd >> 6; u8 ret = 0;
    if (addr == 0x1f) { ne_reset(); return 0; }
    if (addr < 0x10) { if (addr == 0) return ne_cmd; goto regs; }
    if (addr == 0x10) {
        if (ne_dcfg & 1) { ret = ne_memr(ne_rsar); ne_dma_update(2); } else { ret = ne_memr(ne_rsar); ne_dma_update(1); }
        return ret;
    }
    return 0;
regs:
    if (page == 0) {
        switch (addr) {
            case 1: return 0; case 2: return 0; case 3: return ne_bnry; case 4: return ne_tsr; case 5: return 0; case 6: return 0;
            case 7: return ne_isr; case 8: return ne_rsar >> 8; case 9: return ne_rsar & 255; case 10: case 11: return 0x50;
            case 12: return ne_rsr; case 13: return 0; case 14: return 0; case 15: return 0; }
        return 0;
    } else if (page == 1) {
        if (addr >= 1 && addr <= 6) return ne_phys[addr - 1];
        if (addr == 7) return ne_curpag;
        if (addr >= 8 && addr <= 15) return ne_mult[addr - 8];
    } else if (page == 2) {
        switch (addr) { case 1: return ne_pstart; case 2: return ne_pstop; case 4: return ne_tpsr; case 12: return ne_rcr; case 13: return ne_tcr; case 14: return ne_dcfg; case 15: return ne_imr; }
    }
    return 0;
}

/* ---------------- port I/O ---------------- */
static u32 cmos_idx; static u32 sys_b; static u32 pic_dummy;
static u32 io_in(u32 port, int sz) {
    if (ne_on && port >= ne_base && port < ne_base + 0x20) {
        u32 v = ne_ioport_read(port - ne_base);
        return v;
    }
    switch (port) {
        case 0x60: { if (kq_h == kq_t) return 0; u8 v = kq[kq_h]; kq_h = (kq_h + 1) % KQ; return v; }
        case 0x64: { u32 st = 0; if (kq_h != kq_t) { st |= 1; if (kq_aux[kq_h]) st |= 0x20; } return st; }
        case 0x61: sys_b ^= 0x10; return sys_b;
        case 0x92: return 2;
        case 0x40: {
            u32 v;
            if (pit_latched) { v = pit_latch; } else v = pit_count();
            u32 r;
            if (pit_acc_mode == 1) { r = v & 255; if (pit_latched) pit_latched = 0; return r; }
            if (pit_acc_mode == 2) { r = (v >> 8) & 255; if (pit_latched) pit_latched = 0; return r; }
            if (!pit_rd_hi) { pit_rd_hi = 1; return v & 255; }
            pit_rd_hi = 0; if (pit_latched) pit_latched = 0; return (v >> 8) & 255;
        }
        case 0x71: {
            switch (cmos_idx & 0x7f) { case 0: return 0x30; case 2: return 0x45; case 4: return 0x14; case 6: return 0x02; case 7: return 0x17;
                case 8: return 0x11; case 9: return 0x26; case 0x32: return 0x20; case 0x0a: return 0x26; case 0x0b: return 0x02; case 0x0d: return 0x80;
                case 0x30: return (mem_report_kb > 0xffff ? 0xff : mem_report_kb) & 255; case 0x31: return ((mem_report_kb > 0xffff ? 0xffff : mem_report_kb) >> 8) & 255; }
            return 0;
        }
        case 0xCFC: return pci_read(pci_addr);
        case 0xCF8: return pci_addr;
        case 0x3da: return 0;
    }
    if (pci_nic && ne_on && port >= 0xC100 && port < 0xC120) return ne_ioport_read(port - 0xC100);
    return sz == 8 ? 0xff : sz == 16 ? 0xffff : 0xffffffffu;
}
static void mouse_cmd(u8 c) {
    if (mouse_wait_param) {
        mouse_wait_param = 0; kq_push(0xFA, 1);
        mouse_sr_seq[0] = mouse_sr_seq[1]; mouse_sr_seq[1] = mouse_sr_seq[2]; mouse_sr_seq[2] = c;
        if (mouse_sr_seq[0] == 200 && mouse_sr_seq[1] == 100 && mouse_sr_seq[2] == 80) mouse_id = 3;
        return;
    }
    switch (c) {
        case 0xF4: mouse_enabled = 1; kq_push(0xFA, 1); break;
        case 0xF5: mouse_enabled = 0; kq_push(0xFA, 1); break;
        case 0xF3: mouse_wait_param = 1; kq_push(0xFA, 1); break;
        case 0xF2: kq_push(0xFA, 1); kq_push(mouse_id, 1); break;
        case 0xFF: kq_push(0xFA, 1); kq_push(0xAA, 1); kq_push(0, 1); mouse_id = 0; break;
        default: kq_push(0xFA, 1);
    }
}
static void io_out(u32 port, int sz, u32 v) {
    if (ne_on && port >= ne_base && port < ne_base + 0x20) { ne_ioport_write(port - ne_base, v); return; }
    switch (port) {
        case 0x60:
            if (ctrl_next_aux) { ctrl_next_aux = 0; mouse_cmd(v); }
            else if (ctrl_pending_cmd == 0x60) { ctrl_cmd = v; ctrl_pending_cmd = 0; }
            else { /* keyboard command */ if (kbd_wait_param) { kbd_wait_param = 0; kq_push(0xFA, 0); } else if (v == 0xED || v == 0xF3) { kbd_wait_param = 1; kq_push(0xFA, 0); } else kq_push(0xFA, 0); }
            break;
        case 0x64:
            if (v == 0xD4) ctrl_next_aux = 1; else if (v == 0x60) ctrl_pending_cmd = 0x60;
            else if (v == 0x20) kq_push(ctrl_cmd, 0); else if (v == 0xFE) { stopcode = 3; }
            break;
        case 0x61: sys_b = (sys_b & 0x10) | (v & 0x0f); break;
        case 0x43: {
            int ch = (v >> 6) & 3, acc = (v >> 4) & 3;
            if (ch == 0) { if (acc == 0) { pit_latch = pit_count(); pit_latched = 1; pit_rd_hi = 0; } else { pit_acc_mode = acc; pit_wr_hi = 0; pit_rd_hi = 0; } }
            break;
        }
        case 0x40:
            if (pit_acc_mode == 1) pit_reload = v & 255; else if (pit_acc_mode == 2) pit_reload = (v & 255) << 8;
            else { if (!pit_wr_hi) { pit_wr_tmp = v & 255; pit_wr_hi = 1; } else { pit_reload = pit_wr_tmp | ((v & 255) << 8); pit_wr_hi = 0; } }
            break;
        case 0x70: cmos_idx = v; break;
        case 0xCF8: pci_addr = v; break;
        case 0xCFC: break;
        case 0x501: break;
    }
    if (pci_nic && ne_on && port >= 0xC100 && port < 0xC120) ne_ioport_write(port - 0xC100, v);
}

/* ---------------- helpers: registers, modrm ---------------- */
static inline u32 getreg(int r, int sz) {
    if (sz == 32) return R[r]; if (sz == 16) return R[r] & 0xffff; return r < 4 ? R[r] & 0xff : (R[r - 4] >> 8) & 0xff;
}
static inline void setreg(int r, int sz, u32 v) {
    if (sz == 32) R[r] = v; else if (sz == 16) R[r] = (R[r] & 0xffff0000u) | (v & 0xffff);
    else if (r < 4) R[r] = (R[r] & 0xffffff00u) | (v & 0xff); else R[r - 4] = (R[r - 4] & 0xffff00ffu) | ((v & 0xff) << 8);
}
static int opsz32, adsz32, segovr, rep;
static inline u8 fetch8(void) { u8 v = r8(sbase[CS] + eip); eip = cs_d ? eip + 1 : (eip + 1) & 0xffff; return v; }
static inline u16 fetch16(void) { u16 a = fetch8(); a |= (u16)fetch8() << 8; return a; }
static inline u32 fetch32(void) { u32 a = fetch16(); a |= (u32)fetch16() << 16; return a; }
static inline u32 fetchz(int sz) { return sz == 8 ? fetch8() : sz == 16 ? fetch16() : fetch32(); }

typedef struct { int mod, reg, rm, isreg; u32 ea, off; } ModRM;
static void decode_modrm(ModRM *m) {
    u8 b = fetch8(); m->mod = b >> 6; m->reg = (b >> 3) & 7; m->rm = b & 7;
    if (m->mod == 3) { m->isreg = 1; return; }
    m->isreg = 0; int seg = DS; u32 ea = 0;
    if (adsz32) {
        if (m->rm == 4) {
            u8 sib = fetch8(); int sc = sib >> 6, idx = (sib >> 3) & 7, bs = sib & 7; u32 bv;
            if (bs == 5) { if (m->mod == 0) bv = fetch32(); else { bv = R[5]; seg = SS; } } else { bv = R[bs]; if (bs == 4) seg = SS; }
            u32 iv = idx == 4 ? 0 : (R[idx] << sc); ea = bv + iv;
            if (m->mod == 1) ea += (s8)fetch8(); else if (m->mod == 2) ea += fetch32();
        } else if (m->rm == 5 && m->mod == 0) ea = fetch32();
        else {
            ea = R[m->rm]; if (m->rm == 5) seg = SS;
            if (m->mod == 1) ea += (s8)fetch8(); else if (m->mod == 2) ea += fetch32();
        }
    } else {
        u32 bx = R[3] & 0xffff, bp = R[5] & 0xffff, si = R[6] & 0xffff, di = R[7] & 0xffff;
        switch (m->rm) {
            case 0: ea = bx + si; break; case 1: ea = bx + di; break; case 2: ea = bp + si; seg = SS; break; case 3: ea = bp + di; seg = SS; break;
            case 4: ea = si; break; case 5: ea = di; break; case 6: if (m->mod == 0) ea = fetch16(); else { ea = bp; seg = SS; } break; default: ea = bx; break;
        }
        if (m->mod == 1) ea += (s8)fetch8(); else if (m->mod == 2) ea += fetch16();
        ea &= 0xffff;
    }
    if (segovr >= 0) seg = segovr;
    m->off = ea; m->ea = sbase[seg] + ea;
}
static inline u32 rm_get(ModRM *m, int sz) { return m->isreg ? getreg(m->rm, sz) : mrd(m->ea, sz); }
static inline void rm_set(ModRM *m, int sz, u32 v) { if (m->isreg) setreg(m->rm, sz, v); else mwr(m->ea, sz, v); }

static inline void push(u32 v, int sz) {
    if (ss_b) { R[4] -= sz / 8; mwr(sbase[SS] + R[4], sz, v); }
    else { u32 sp = (R[4] - sz / 8) & 0xffff; R[4] = (R[4] & 0xffff0000u) | sp; mwr(sbase[SS] + sp, sz, v); }
}
static inline u32 pop(int sz) {
    u32 v;
    if (ss_b) { v = mrd(sbase[SS] + R[4], sz); R[4] += sz / 8; }
    else { u32 sp = R[4] & 0xffff; v = mrd(sbase[SS] + sp, sz); sp = (sp + sz / 8) & 0xffff; R[4] = (R[4] & 0xffff0000u) | sp; }
    return v;
}

static u32 alu(int op, u32 a, u32 b, int sz) {
    u32 mask = sz == 32 ? 0xffffffffu : ((1u << sz) - 1), msb = 1u << (sz - 1), res = 0; u64 r; u32 c;
    a &= mask; b &= mask;
    switch (op) {
        case 0: r = (u64)a + b; res = (u32)r & mask; CF = (r >> sz) & 1; OF = ((~(a ^ b) & (a ^ res)) & msb) != 0; AF = ((a ^ b ^ res) & 0x10) != 0; break;
        case 2: c = CF; r = (u64)a + b + c; res = (u32)r & mask; CF = (r >> sz) & 1; OF = ((~(a ^ b) & (a ^ res)) & msb) != 0; AF = ((a ^ b ^ res) & 0x10) != 0; break;
        case 3: c = CF; r = (u64)a - b - c; res = (u32)r & mask; CF = ((u64)a < (u64)b + c); OF = (((a ^ b) & (a ^ res)) & msb) != 0; AF = ((a ^ b ^ res) & 0x10) != 0; break;
        case 5: case 7: res = (a - b) & mask; CF = a < b; OF = (((a ^ b) & (a ^ res)) & msb) != 0; AF = ((a ^ b ^ res) & 0x10) != 0; break;
        case 1: res = a | b; CF = OF = AF = 0; break;
        case 4: res = a & b; CF = OF = AF = 0; break;
        default: res = a ^ b; CF = OF = AF = 0; break;
    }
    ZF = res == 0; SF = (res & msb) != 0; PF = parity8(res);
    return res;
}
static u32 shiftop(int op, u32 a, u32 cnt, int sz) {
    u32 mask = sz == 32 ? 0xffffffffu : ((1u << sz) - 1), msb = 1u << (sz - 1), res = a & mask; a &= mask;
    cnt &= 31; if (!cnt) return a;
    switch (op) {
        case 0: { u32 c = cnt % sz; res = c ? (((a << c) | (a >> (sz - c))) & mask) : a; CF = res & 1; OF = ((res >> (sz - 1)) & 1) ^ CF; return res; }
        case 1: { u32 c = cnt % sz; res = c ? (((a >> c) | (a << (sz - c))) & mask) : a; CF = (res >> (sz - 1)) & 1; OF = ((res >> (sz - 1)) ^ (res >> (sz - 2))) & 1; return res; }
        case 2: { for (u32 i = 0; i < cnt % (sz + 1); i++) { u32 c = (res >> (sz - 1)) & 1; res = ((res << 1) | CF) & mask; CF = c; } OF = ((res >> (sz - 1)) & 1) ^ CF; return res; }
        case 3: { for (u32 i = 0; i < cnt % (sz + 1); i++) { u32 c = res & 1; res = (res >> 1) | (CF << (sz - 1)); CF = c; } OF = ((res >> (sz - 1)) ^ (res >> (sz - 2))) & 1; return res; }
        case 4: case 6: res = cnt >= 32 ? 0 : (a << cnt) & mask; CF = cnt <= (u32)sz ? (a >> (sz - cnt)) & 1 : 0; OF = ((res & msb) != 0) ^ CF; break;
        case 5: res = a >> cnt; CF = (a >> (cnt - 1)) & 1; OF = (a & msb) != 0; break;
        default: { s32 sa = sz == 32 ? (s32)a : sz == 16 ? (s32)(s16)a : (s32)(s8)a; res = (u32)(sa >> cnt) & mask; CF = (u32)(sa >> (cnt - 1)) & 1; OF = 0; break; }
    }
    ZF = res == 0; SF = (res & msb) != 0; PF = parity8(res); AF = 0;
    return res;
}
static int cond(int cc) {
    int r;
    switch (cc >> 1) { case 0: r = OF; break; case 1: r = CF; break; case 2: r = ZF; break; case 3: r = CF | ZF; break;
        case 4: r = SF; break; case 5: r = PF; break; case 6: r = SF != OF; break; default: r = ZF | (SF != OF); }
    return (cc & 1) ? !r : r;
}

static void load_seg(int s, u16 v) {
    sel[s] = v;
    if (!(cr0 & 1)) { sbase[s] = (u32)v << 4; if (s == SS) ss_b = 0; if (s == CS) cs_d = 0; return; }
    if (!gdt_limit) { sbase[s] = 0; if (s == SS) ss_b = 1; if (s == CS) cs_d = 1; return; }
    u32 d = gdt_base + (v & ~7u); u32 lo = r32(d), hi = r32(d + 4);
    u32 base = (lo >> 16) | ((hi & 0xff) << 16) | (hi & 0xff000000u);
    sbase[s] = base;
    if (s == SS) ss_b = (hi >> 22) & 1; if (s == CS) cs_d = (hi >> 22) & 1;
}

/* ---------------- BIOS HLE ---------------- */
static void bios_int(int n) {
    u16 ax = R[0] & 0xffff;
    if (n == 0x10) {
        if (ax == 0x4F01) {
            u32 a = sbase[ES] + (R[7] & 0xffff); memset(pm(a), 0, 256);
            w16(a, 0x009B); w16(a + 0x10, 1600); w16(a + 0x12, 800); w16(a + 0x14, 600); w8(a + 0x19, 16); w8(a + 0x1B, 6); w32(a + 0x28, FB_BASE);
            w8(a + 0x1D, 1); w8(a + 0x1F, 5); w8(a + 0x20, 11); w8(a + 0x21, 6); w8(a + 0x22, 5); w8(a + 0x23, 5);
            setreg(0, 16, 0x004F); return;
        }
        if (ax == 0x4F02) { vbe_mode_set = R[3] & 0xffff; vbe_active = 1; setreg(0, 16, 0x004F); return; }
        return;
    }
    if (n == 0x13) {
        int ah = (R[0] >> 8) & 255;
        if (ah == 0x42 && no_ext) { setreg(0, 16, 0x0100); CF = 1; return; }
        if (ah == 0x42) {
            u32 d = sbase[DS] + (R[6] & 0xffff); u32 cnt = r16(d + 2), off = r16(d + 4), seg = r16(d + 6); u32 lba = r32(d + 8);
            if ((u64)(lba + cnt) * 512 > disksz) { setreg(0, 16, 0x0100 | (R[0] & 255)); CF = 1; return; }
            memcpy(pm((seg << 4) + off), disk + (u64)lba * 512, cnt * 512); setreg(0, 16, R[0] & 0xff); CF = 0; return;
        }
        if (ah == 0x02) {
            int cnt = R[0] & 255, sec = R[1] & 63, cyl = ((R[1] >> 8) & 255) | (((R[1] >> 6) & 3) << 8), head = (R[2] >> 8) & 255;
            u32 lba = (cyl * 2 + head) * 18 + sec - 1; u32 dst = sbase[ES] + (R[3] & 0xffff);
            if ((u64)(lba + cnt) * 512 > disksz) { setreg(0, 16, 0x0400); CF = 1; return; }
            memcpy(pm(dst), disk + (u64)lba * 512, cnt * 512); setreg(0, 16, cnt); CF = 0; return;
        }
        if (ah == 0x00) { setreg(0, 16, 0); CF = 0; return; }
        if (ah == 0x41) { setreg(3, 16, 0xAA55); setreg(0, 16, 0x2100); setreg(1, 16, 1); CF = 0; return; }
        setreg(0, 16, 0x0100); CF = 1; return;
    }
    if (n == 0x15) {
        if (R[0] == 0xE820 && R[2] == 0x534D4150) { /* EDX='SMAP' */
            u32 idx = R[3]; u32 a = sbase[ES] + (R[7] & 0xffff);
            u32 ent[3][3] = {{0, 0x9fc00, 1}, {0xf0000, 0x10000, 2}, {0x100000, ramsz - 0x100000, 1}};
            if (idx > 2) { CF = 1; return; }
            w32(a, ent[idx][0]); w32(a + 4, 0); w32(a + 8, ent[idx][1]); w32(a + 12, 0); w32(a + 16, ent[idx][2]);
            R[0] = 0x534D4150; R[1] = 20; R[3] = (idx + 1 > 2) ? 0 : idx + 1; CF = 0; return;
        }
        if ((R[0] & 0xffff) == 0xE801) {
            u32 kb1 = (ramsz - 0x100000) / 1024; if (kb1 > 0x3C00) kb1 = 0x3C00;
            u32 blk = ramsz > 0x1000000 ? (ramsz - 0x1000000) / 65536 : 0;
            setreg(0, 16, kb1); setreg(3, 16, blk); setreg(1, 16, kb1); setreg(2, 16, blk); CF = 0; return;
        }
        if (((R[0] >> 8) & 255) == 0x88) { u32 kb = (ramsz - 0x100000) / 1024; setreg(0, 16, kb > 0xffff ? 0xffff : kb); CF = 0; return; }
        CF = 1; setreg(0, 16, 0x8600); return;
    }
}

/* ---------------- main step ---------------- */
static void string_op(int op, int sz) {
    u32 cx_mask = adsz32 ? 0xffffffffu : 0xffff; int step = (sz / 8) * (DF ? -1 : 1);
    int dsseg = segovr >= 0 ? segovr : DS;
    for (;;) {
        if (rep && (R[1] & cx_mask) == 0) return;
        u32 si = adsz32 ? R[6] : R[6] & 0xffff, di = adsz32 ? R[7] : R[7] & 0xffff;
        switch (op) {
            case 0xA4: mwr(sbase[ES] + di, sz, mrd(sbase[dsseg] + si, sz)); break;
            case 0xAA: mwr(sbase[ES] + di, sz, getreg(0, sz)); break;
            case 0xAC: setreg(0, sz, mrd(sbase[dsseg] + si, sz)); break;
            case 0xA6: alu(7, mrd(sbase[dsseg] + si, sz), mrd(sbase[ES] + di, sz), sz); break;
            case 0xAE: alu(7, getreg(0, sz), mrd(sbase[ES] + di, sz), sz); break;
        }
        if (op == 0xA4 || op == 0xA6 || op == 0xAC) { if (adsz32) R[6] += step; else R[6] = (R[6] & 0xffff0000u) | ((R[6] + step) & 0xffff); }
        if (op != 0xAC) { if (adsz32) R[7] += step; else R[7] = (R[7] & 0xffff0000u) | ((R[7] + step) & 0xffff); }
        if (!rep) return;
        if (adsz32) R[1]--; else R[1] = (R[1] & 0xffff0000u) | ((R[1] - 1) & 0xffff);
        icount++;
        if ((op == 0xA6 || op == 0xAE) && ((rep == 0xF3 && !ZF) || (rep == 0xF2 && ZF))) return;
    }
}

static void do_group3(int sz, ModRM *m) {
    u32 v = rm_get(m, sz); u32 mask = sz == 32 ? 0xffffffffu : ((1u << sz) - 1);
    switch (m->reg) {
        case 0: case 1: { u32 im = fetchz(sz); alu(4, v, im, sz); return; }
        case 2: rm_set(m, sz, ~v & mask); return;
        case 3: { u32 r = alu(5, 0, v, sz); rm_set(m, sz, r); CF = (v & mask) != 0; return; }
        case 4: case 5: {
            if (sz == 8) { u32 r = m->reg == 4 ? (u32)((v & 0xff) * (R[0] & 0xff)) : (u32)((s32)(s8)v * (s32)(s8)R[0]); setreg(0, 16, r);
                CF = OF = m->reg == 4 ? ((r >> 8) != 0) : ((s32)(s16)r != (s32)(s8)r); }
            else if (sz == 16) { u32 r = m->reg == 4 ? (u32)((v & 0xffff) * (R[0] & 0xffff)) : (u32)((s32)(s16)v * (s32)(s16)R[0]);
                setreg(0, 16, r); setreg(2, 16, r >> 16); CF = OF = m->reg == 4 ? ((r >> 16) != 0) : ((s32)r != (s32)(s16)r); }
            else { u64 r = m->reg == 4 ? (u64)v * R[0] : (u64)((s64)(s32)v * (s64)(s32)R[0]); R[0] = (u32)r; R[2] = (u32)(r >> 32);
                CF = OF = m->reg == 4 ? (R[2] != 0) : ((s64)r != (s64)(s32)R[0]); }
            return; }
        default: {
            if (v == 0) { fault("divide by zero"); return; }
            if (sz == 8) { if (m->reg == 6) { u32 n = R[0] & 0xffff, q = n / v, r = n % v; if (q > 255) { fault("div overflow"); return; } setreg(0, 8, q); setreg(4, 8, r); }
                else { s32 n = (s16)R[0], d = (s8)v, q = n / d, r = n % d; setreg(0, 8, q); setreg(4, 8, r); } }
            else if (sz == 16) { if (m->reg == 6) { u32 n = ((R[2] & 0xffff) << 16) | (R[0] & 0xffff), q = n / v, r = n % v; if (q > 0xffff) { fault("div overflow"); return; } setreg(0, 16, q); setreg(2, 16, r); }
                else { s32 n = (s32)(((R[2] & 0xffff) << 16) | (R[0] & 0xffff)), d = (s16)v, q = n / d, r = n % d; setreg(0, 16, q); setreg(2, 16, r); } }
            else { if (m->reg == 6) { u64 n = ((u64)R[2] << 32) | R[0]; u64 q = n / v, r = n % v; if (q > 0xffffffffu) { fault("div overflow"); return; } R[0] = (u32)q; R[2] = (u32)r; }
                else { s64 n = (s64)(((u64)R[2] << 32) | R[0]); s64 d = (s32)v; s64 q = n / d, r = n % d; R[0] = (u32)q; R[2] = (u32)r; } }
            return; }
    }
}

static u32 watch2_a, watch2_b; static u64 watch2_t, watch2_sum, watch2_n;
void emu_watch2(u32 a, u32 b) { watch2_a = a; watch2_b = b; watch2_t = 0; watch2_sum = 0; watch2_n = 0; }
u64 emu_watch2_n(void) { return watch2_n; }
u64 emu_watch2_sum(void) { return watch2_sum; }
static u32 watch_addr; static u64 watch_hits, watch_first, watch_last;
void emu_watch(u32 a) { watch_addr = a; watch_hits = 0; }
u64 emu_watch_hits(void) { return watch_hits; }
u64 emu_watch_span(void) { return watch_last - watch_first; }
static void step(void) {
    start_eip = eip; icount++;
    if (watch2_a) { if (eip == watch2_a) watch2_t = icount; else if (eip == watch2_b && watch2_t) { watch2_sum += icount - watch2_t; watch2_n++; watch2_t = 0; } }
    if (eip == watch_addr && watch_addr) { if (!watch_hits) watch_first = icount; watch_hits++; watch_last = icount; }
    opsz32 = cs_d; adsz32 = cs_d; segovr = -1; rep = 0;
    u8 op;
    for (;;) {
        op = fetch8();
        if (op == 0x66) opsz32 ^= 1; else if (op == 0x67) adsz32 ^= 1;
        else if (op == 0xF2 || op == 0xF3) rep = op; else if (op == 0xF0) { }
        else if (op == 0x26) segovr = ES; else if (op == 0x2E) segovr = CS; else if (op == 0x36) segovr = SS; else if (op == 0x3E) segovr = DS;
        else if (op == 0x64) segovr = FS; else if (op == 0x65) segovr = GS; else break;
    }
    int sz = opsz32 ? 32 : 16; ModRM m;
    if (op < 0x40 && (op & 7) < 6) {
        int a = op >> 3, form = op & 7, s = (form & 1) ? sz : 8;
        if (form < 4) {
            decode_modrm(&m);
            if (form < 2) { u32 d = rm_get(&m, s), sv = getreg(m.reg, s); u32 r = alu(a, d, sv, s); if (a != 7) rm_set(&m, s, r); }
            else { u32 d = getreg(m.reg, s), sv = rm_get(&m, s); u32 r = alu(a, d, sv, s); if (a != 7) setreg(m.reg, s, r); }
        } else { u32 im = fetchz(s); u32 r = alu(a, getreg(0, s), im, s); if (a != 7) setreg(0, s, r); }
        return;
    }
    switch (op) {
        case 0x0F: {
            u8 o2 = fetch8();
            if (o2 >= 0x80 && o2 <= 0x8F) { s32 d = sz == 32 ? (s32)fetch32() : (s32)(s16)fetch16(); if (cond(o2 & 15)) { eip += d; if (!cs_d) eip &= 0xffff; } return; }
            if (o2 >= 0x90 && o2 <= 0x9F) { decode_modrm(&m); rm_set(&m, 8, cond(o2 & 15)); return; }
            if (o2 >= 0x40 && o2 <= 0x4F) { decode_modrm(&m); u32 v = rm_get(&m, sz); if (cond(o2 & 15)) setreg(m.reg, sz, v); return; }
            switch (o2) {
                case 0x01: { decode_modrm(&m); if (m.reg == 2) { gdt_limit = r16(m.ea); gdt_base = r32(m.ea + 2); if (!opsz32) gdt_base &= 0xffffff; } else if (m.reg == 3) { idt_limit = r16(m.ea); idt_base = r32(m.ea + 2); } else fault("0f01 sub"); return; }
                case 0x20: { decode_modrm(&m); if (m.reg == 0) setreg(m.rm, 32, cr0); else setreg(m.rm, 32, 0); return; }
                case 0x22: { decode_modrm(&m); if (m.reg == 0) cr0 = R[m.rm]; return; }
                case 0x31: { u64 t = icount * 4; R[0] = (u32)t; R[2] = (u32)(t >> 32); return; }
                case 0xA0: push(sel[FS], sz); return; case 0xA8: push(sel[GS], sz); return;
                case 0xA1: { u32 v = pop(sz); load_seg(FS, v); return; } case 0xA9: { u32 v = pop(sz); load_seg(GS, v); return; }
                case 0xA2: R[0] = 1; R[3] = R[1] = R[2] = 0; return;
                case 0xAF: { decode_modrm(&m); u32 a = getreg(m.reg, sz), b = rm_get(&m, sz);
                    if (sz == 32) { s64 r = (s64)(s32)a * (s64)(s32)b; setreg(m.reg, 32, (u32)r); CF = OF = r != (s64)(s32)r; }
                    else { s32 r = (s32)(s16)a * (s32)(s16)b; setreg(m.reg, 16, r); CF = OF = r != (s32)(s16)r; } return; }
                case 0xB6: { decode_modrm(&m); setreg(m.reg, sz, rm_get(&m, 8)); return; }
                case 0xB7: { decode_modrm(&m); setreg(m.reg, sz, rm_get(&m, 16)); return; }
                case 0xBE: { decode_modrm(&m); setreg(m.reg, sz, (u32)(s32)(s8)rm_get(&m, 8)); return; }
                case 0xBF: { decode_modrm(&m); setreg(m.reg, sz, (u32)(s32)(s16)rm_get(&m, 16)); return; }
                case 0xA3: case 0xAB: case 0xB3: case 0xBB: { decode_modrm(&m); u32 bit = getreg(m.reg, sz) & (sz - 1); u32 v = rm_get(&m, sz); CF = (v >> bit) & 1;
                    if (o2 == 0xAB) v |= 1u << bit; else if (o2 == 0xB3) v &= ~(1u << bit); else if (o2 == 0xBB) v ^= 1u << bit; if (o2 != 0xA3) rm_set(&m, sz, v); return; }
                case 0xBA: { decode_modrm(&m); u32 bit = fetch8() & (sz - 1); u32 v = rm_get(&m, sz); CF = (v >> bit) & 1;
                    if (m.reg == 5) v |= 1u << bit; else if (m.reg == 6) v &= ~(1u << bit); else if (m.reg == 7) v ^= 1u << bit; if (m.reg != 4) rm_set(&m, sz, v); return; }
                case 0xBC: case 0xBD: { decode_modrm(&m); u32 v = rm_get(&m, sz); if (!v) { ZF = 1; } else { ZF = 0; int i = 0; if (o2 == 0xBC) { while (!((v >> i) & 1)) i++; } else { i = sz - 1; while (!((v >> i) & 1)) i--; } setreg(m.reg, sz, i); } return; }
                case 0xA4: case 0xA5: case 0xAC: case 0xAD: { decode_modrm(&m); u32 cnt = (o2 & 1) ? (R[1] & 31) : fetch8() & 31; u32 d = rm_get(&m, sz), s = getreg(m.reg, sz);
                    if (cnt) { u64 r; u32 mask = sz == 32 ? 0xffffffffu : 0xffff;
                        if (o2 < 0xA8) { r = ((u64)d << 32 | s) ; (void)r; u32 res = sz == 32 ? (d << cnt) | (s >> (32 - cnt)) : ((d << cnt) | (s >> (16 - cnt))) & mask; CF = (d >> (sz - cnt)) & 1; rm_set(&m, sz, res); ZF = (res & mask) == 0; SF = (res >> (sz - 1)) & 1; PF = parity8(res); }
                        else { u32 res = sz == 32 ? (d >> cnt) | (s << (32 - cnt)) : ((d >> cnt) | (s << (16 - cnt))) & mask; CF = (d >> (cnt - 1)) & 1; rm_set(&m, sz, res); ZF = (res & mask) == 0; SF = (res >> (sz - 1)) & 1; PF = parity8(res); } }
                    return; }
                default: if (o2 >= 0xC8 && o2 <= 0xCF) { u32 v = R[o2 - 0xC8]; R[o2 - 0xC8] = (v >> 24) | ((v >> 8) & 0xff00) | ((v << 8) & 0xff0000) | (v << 24); return; }
                    fault("unimplemented 0f op"); return;
            }
        }
        case 0x06: push(sel[ES], sz); return; case 0x0E: push(sel[CS], sz); return; case 0x16: push(sel[SS], sz); return; case 0x1E: push(sel[DS], sz); return;
        case 0x07: { u32 v = pop(sz); load_seg(ES, v); return; } case 0x17: { u32 v = pop(sz); load_seg(SS, v); return; } case 0x1F: { u32 v = pop(sz); load_seg(DS, v); return; }
        case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
        case 0x48: case 0x49: case 0x4A: case 0x4B: case 0x4C: case 0x4D: case 0x4E: case 0x4F: {
            int r = op & 7, dec = op >= 0x48; u32 c = CF; u32 v = alu(dec ? 5 : 0, getreg(r, sz), 1, sz); CF = c; setreg(r, sz, v); return; }
        case 0x50: case 0x51: case 0x52: case 0x53: case 0x54: case 0x55: case 0x56: case 0x57: { u32 v = R[op & 7]; if ((op & 7) == 4) v = R[4]; push(sz == 32 ? v : v & 0xffff, sz); return; }
        case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F: { u32 v = pop(sz); setreg(op & 7, sz, v); return; }
        case 0x60: { u32 t = R[4]; for (int i = 0; i < 8; i++) push(i == 4 ? t : R[i], sz); return; }
        case 0x61: { for (int i = 7; i >= 0; i--) { u32 v = pop(sz); if (i != 4) setreg(i, sz, v); } return; }
        case 0x68: { u32 v = fetchz(sz); push(v, sz); return; }
        case 0x6A: { u32 v = (u32)(s32)(s8)fetch8(); push(v, sz); return; }
        case 0x69: case 0x6B: { decode_modrm(&m); u32 b = rm_get(&m, sz); s32 im = op == 0x6B ? (s32)(s8)fetch8() : (sz == 32 ? (s32)fetch32() : (s32)(s16)fetch16());
            if (sz == 32) { s64 r = (s64)(s32)b * (s64)im; setreg(m.reg, 32, (u32)r); CF = OF = r != (s64)(s32)r; } else { s32 r = (s32)(s16)b * im; setreg(m.reg, 16, r); CF = OF = r != (s32)(s16)r; } return; }
        case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:
        case 0x78: case 0x79: case 0x7A: case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F: { s8 d = (s8)fetch8(); if (cond(op & 15)) { eip += d; if (!cs_d) eip &= 0xffff; } return; }
        case 0x80: case 0x81: case 0x82: case 0x83: { int s = (op & 1) ? sz : 8; decode_modrm(&m); u32 d = rm_get(&m, s); u32 im = op == 0x83 ? (u32)(s32)(s8)fetch8() : fetchz(s);
            u32 r = alu(m.reg, d, im, s); if (m.reg != 7) rm_set(&m, s, r); return; }
        case 0x84: case 0x85: { int s = (op & 1) ? sz : 8; decode_modrm(&m); alu(4, rm_get(&m, s), getreg(m.reg, s), s); return; }
        case 0x86: case 0x87: { int s = (op & 1) ? sz : 8; decode_modrm(&m); u32 a = rm_get(&m, s), b = getreg(m.reg, s); rm_set(&m, s, b); setreg(m.reg, s, a); return; }
        case 0x88: case 0x89: { int s = (op & 1) ? sz : 8; decode_modrm(&m); rm_set(&m, s, getreg(m.reg, s)); return; }
        case 0x8A: case 0x8B: { int s = (op & 1) ? sz : 8; decode_modrm(&m); setreg(m.reg, s, rm_get(&m, s)); return; }
        case 0x8C: { decode_modrm(&m); rm_set(&m, m.isreg ? sz : 16, sel[m.reg > 5 ? 0 : m.reg]); return; }
        case 0x8D: { decode_modrm(&m); setreg(m.reg, sz, adsz32 ? m.off : m.off & 0xffff); return; }
        case 0x8E: { decode_modrm(&m); u16 v = rm_get(&m, 16); load_seg(m.reg > 5 ? 0 : m.reg, v); return; }
        case 0x8F: { decode_modrm(&m); u32 v = pop(sz); rm_set(&m, sz, v); return; }
        case 0x90: return;
        case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x97: { u32 a = getreg(0, sz), b = getreg(op & 7, sz); setreg(0, sz, b); setreg(op & 7, sz, a); return; }
        case 0x98: if (sz == 32) R[0] = (u32)(s32)(s16)R[0]; else setreg(0, 16, (u32)(s32)(s8)R[0]); return;
        case 0x99: if (sz == 32) R[2] = (R[0] & 0x80000000u) ? 0xffffffffu : 0; else setreg(2, 16, (R[0] & 0x8000) ? 0xffff : 0); return;
        case 0x9C: push(get_flags(), sz); return;
        case 0x9D: { u32 f = pop(sz); set_flags(f); return; }
        case 0x9E: { u32 f = (R[0] >> 8) & 255; CF = f & 1; PF = (f >> 2) & 1; AF = (f >> 4) & 1; ZF = (f >> 6) & 1; SF = (f >> 7) & 1; return; }
        case 0x9F: { u32 f = 2 | CF | (PF << 2) | (AF << 4) | (ZF << 6) | (SF << 7); setreg(4, 8, f); return; }
        case 0xA0: case 0xA1: case 0xA2: case 0xA3: { int s = (op & 1) ? sz : 8; u32 off = adsz32 ? fetch32() : fetch16(); u32 a = sbase[segovr >= 0 ? segovr : DS] + off;
            if (op < 0xA2) setreg(0, s, mrd(a, s)); else mwr(a, s, getreg(0, s)); return; }
        case 0xA4: string_op(0xA4, 8); return; case 0xA5: string_op(0xA4, sz); return;
        case 0xA6: string_op(0xA6, 8); return; case 0xA7: string_op(0xA6, sz); return;
        case 0xA8: { u32 im = fetch8(); alu(4, R[0] & 0xff, im, 8); return; }
        case 0xA9: { u32 im = fetchz(sz); alu(4, getreg(0, sz), im, sz); return; }
        case 0xAA: string_op(0xAA, 8); return; case 0xAB: string_op(0xAA, sz); return;
        case 0xAC: string_op(0xAC, 8); return; case 0xAD: string_op(0xAC, sz); return;
        case 0xAE: string_op(0xAE, 8); return; case 0xAF: string_op(0xAE, sz); return;
        case 0xB0: case 0xB1: case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: case 0xB7: setreg(op & 7, 8, fetch8()); return;
        case 0xB8: case 0xB9: case 0xBA: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF: setreg(op & 7, sz, fetchz(sz)); return;
        case 0xC0: case 0xC1: { int s = (op & 1) ? sz : 8; decode_modrm(&m); u32 v = rm_get(&m, s); u32 c = fetch8(); rm_set(&m, s, shiftop(m.reg, v, c, s)); return; }
        case 0xD0: case 0xD1: { int s = (op & 1) ? sz : 8; decode_modrm(&m); u32 v = rm_get(&m, s); rm_set(&m, s, shiftop(m.reg, v, 1, s)); return; }
        case 0xD2: case 0xD3: { int s = (op & 1) ? sz : 8; decode_modrm(&m); u32 v = rm_get(&m, s); rm_set(&m, s, shiftop(m.reg, v, R[1] & 31, s)); return; }
        case 0xC2: { u32 n = fetch16(); u32 ret = pop(sz); eip = cs_d ? ret : ret & 0xffff; if (ss_b) R[4] += n; else R[4] = (R[4] & 0xffff0000u) | ((R[4] + n) & 0xffff); return; }
        case 0xC3: { u32 ret = pop(sz); eip = cs_d ? ret : ret & 0xffff; return; }
        case 0xC6: case 0xC7: { int s = (op & 1) ? sz : 8; decode_modrm(&m); u32 im = fetchz(s); rm_set(&m, s, im); return; }
        case 0xC9: { if (ss_b) R[4] = R[5]; else R[4] = (R[4] & 0xffff0000u) | (R[5] & 0xffff); u32 v = pop(sz); setreg(5, sz, v); return; }
        case 0xCC: fault("int3"); return;
        case 0xCD: { u8 n = fetch8(); if (!(cr0 & 1)) bios_int(n); else fault("int in protected mode"); return; }
        case 0xE0: case 0xE1: case 0xE2: { s8 d = (s8)fetch8(); u32 cx; if (adsz32) { cx = --R[1]; } else { cx = (R[1] - 1) & 0xffff; R[1] = (R[1] & 0xffff0000u) | cx; }
            int t = cx != 0; if (op == 0xE1) t &= ZF; if (op == 0xE0) t &= !ZF; if (t) { eip += d; if (!cs_d) eip &= 0xffff; } return; }
        case 0xE3: { s8 d = (s8)fetch8(); u32 cx = adsz32 ? R[1] : R[1] & 0xffff; if (!cx) { eip += d; if (!cs_d) eip &= 0xffff; } return; }
        case 0xE4: { u8 p = fetch8(); setreg(0, 8, io_in(p, 8)); return; }
        case 0xE5: { u8 p = fetch8(); setreg(0, sz, io_in(p, sz)); return; }
        case 0xE6: { u8 p = fetch8(); io_out(p, 8, R[0] & 0xff); return; }
        case 0xE7: { u8 p = fetch8(); io_out(p, sz, getreg(0, sz)); return; }
        case 0xEC: setreg(0, 8, io_in(R[2] & 0xffff, 8)); return;
        case 0xED: setreg(0, sz, io_in(R[2] & 0xffff, sz)); return;
        case 0xEE: io_out(R[2] & 0xffff, 8, R[0] & 0xff); return;
        case 0xEF: io_out(R[2] & 0xffff, sz, getreg(0, sz)); return;
        case 0xE8: { s32 d = sz == 32 ? (s32)fetch32() : (s32)(s16)fetch16(); push(eip, sz); eip += d; if (!cs_d) eip &= 0xffff; return; }
        case 0xE9: { s32 d = sz == 32 ? (s32)fetch32() : (s32)(s16)fetch16(); eip += d; if (!cs_d) eip &= 0xffff; return; }
        case 0xEA: { u32 off = sz == 32 ? fetch32() : fetch16(); u16 s = fetch16(); load_seg(CS, s); eip = off; return; }
        case 0xEB: { s8 d = (s8)fetch8(); eip += d; if (!cs_d) eip &= 0xffff; return; }
        case 0xF4: stopcode = 1; return;
        case 0xF5: CF ^= 1; return; case 0xF8: CF = 0; return; case 0xF9: CF = 1; return;
        case 0xFA: IF = 0; return; case 0xFB: IF = 1; return; case 0xFC: DF = 0; return; case 0xFD: DF = 1; return;
        case 0xF6: { decode_modrm(&m); do_group3(8, &m); return; }
        case 0xF7: { decode_modrm(&m); do_group3(sz, &m); return; }
        case 0xFE: { decode_modrm(&m); u32 v = rm_get(&m, 8); u32 c = CF; v = alu(m.reg ? 5 : 0, v, 1, 8); CF = c; rm_set(&m, 8, v); return; }
        case 0xFF: { decode_modrm(&m);
            switch (m.reg) {
                case 0: case 1: { u32 v = rm_get(&m, sz); u32 c = CF; v = alu(m.reg ? 5 : 0, v, 1, sz); CF = c; rm_set(&m, sz, v); return; }
                case 2: { u32 t = rm_get(&m, sz); push(eip, sz); eip = cs_d ? t : t & 0xffff; return; }
                case 4: { u32 t = rm_get(&m, sz); eip = cs_d ? t : t & 0xffff; return; }
                case 6: { u32 v = rm_get(&m, sz); push(v, sz); return; }
                default: fault("ff sub"); return;
            } }
        default: fault("unimplemented opcode"); return;
    }
}

/* ---------------- public API ---------------- */
int emu_init(u32 mem_bytes) {
    ramsz = mem_bytes; free(ram); free(fbm);
    ram = calloc(1, ramsz); fbm = calloc(1, fbsz);
    memset(R, 0, sizeof R); eip = 0; stopcode = 0; icount = 0; mem_report_kb = ramsz / 1024;
    kq_h = kq_t = 0; tx_h = tx_t = 0; ne_on = 0; pci_nic = 0; mouse_enabled = 0; mouse_id = 0;
    pit_reload = 0; pit_latched = 0; cr0 = 0; vbe_active = 0; ne_dropped_full = 0;
    ne_reset();
    return ram && fbm;
}
void emu_set_disk(const u8 *d, u32 n) { disk = d; disksz = n; }
void emu_set_nic(int mode, const u8 *mac) { /* 0 none, 1 ISA 0x300, 2 PCI */
    ne_on = mode != 0; pci_nic = mode == 2; if (mac) memcpy(ne_mac, mac, 6); ne_reset();
    if (mode == 2) ne_base = 0xC100; else ne_base = 0x300;
}
void emu_boot(int drive) { /* real mode boot from disk sector 0 */
    memcpy(ram + 0x7c00, disk, 512);
    cr0 = 0; for (int i = 0; i < 6; i++) { sel[i] = 0; sbase[i] = 0; } cs_d = ss_b = 0; eip = 0x7c00; R[2] = drive;
    R[4] = 0x7c00; stopcode = 0;
}
void emu_boot_direct(u32 entry, u32 esp) { /* skip loader: flat protected mode */
    cr0 = 1; for (int i = 0; i < 6; i++) { sel[i] = i == CS ? 8 : 16; sbase[i] = 0; } cs_d = ss_b = 1; eip = entry; R[4] = esp; stopcode = 0;
}
int emu_run(u64 maxn) {
    u64 target = icount + maxn;
    while (icount < target && !stopcode) step();
    return stopcode;
}
const char *emu_fault(void) { return faultmsg; }
u64 emu_icount(void) { return icount; }
u64 emu_vticks(void) { return vticks(); }
u8 *emu_ram(void) { return ram; }
u8 *emu_fb(void) { return fbm; }
u32 emu_reg(int i) { return i < 8 ? R[i] : i == 8 ? eip : cr0; }
void emu_key(u8 sc) { kq_push(sc, 0); }
void emu_mouse(int dx, int dy_up, int btn, int dz) {
    if (!mouse_enabled) return;
    if (dx > 255) dx = 255; if (dx < -256) dx = -256; if (dy_up > 255) dy_up = 255; if (dy_up < -256) dy_up = -256;
    u8 b0 = 8 | (btn & 7) | (dx < 0 ? 0x10 : 0) | (dy_up < 0 ? 0x20 : 0);
    kq_push(b0, 1); kq_push((u8)dx, 1); kq_push((u8)dy_up, 1); if (mouse_id == 3) kq_push((u8)dz, 1);
}
int emu_nic_rx(const u8 *f, int n) { return ne_receive(f, n); }
int emu_nic_tx_pop(u8 *buf, int cap) {
    if (tx_h == tx_t) return 0;
    int n = txlen[tx_h]; if (n > cap) n = cap; memcpy(buf, txq[tx_h], n); free(txq[tx_h]); tx_h = (tx_h + 1) & 255; return n;
}
u64 emu_nic_dropped(void) { return ne_dropped_full; }
int emu_vbe_active(void) { return vbe_active; }
u32 emu_nic_state(int what) { switch (what) { case 0: return ne_curpag; case 1: return ne_bnry; case 2: return ne_pstart; case 3: return ne_pstop; case 4: return ne_rcr; case 5: return ne_dcfg; } return 0; }
