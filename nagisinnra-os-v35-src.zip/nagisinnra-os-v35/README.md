# Nagisinnra OS V35

32bit i386 の自作デスクトップOS(800x600 GUI)。V34 をベースに、**HTTPでWebページを取得して表示するところまで**を作り込み、実用に耐えるよう全体を作り直しました。

| 項目 | 内容 |
|---|---|
| 起動イメージ | `nagisinnra-os-v35.img`(1.44MB フロッピーイメージ) |
| 画面 | VBE 800x600 / 16bit、日本語表示対応(8x16 / 16x16 フォント) |
| ネットワーク | NE2000(ISA / PCI)、DHCP・DNS・ICMP・TCP・HTTP/1.1 |
| ブラウザ | HTML をテキストレイアウトで表示、リンク、履歴、リダイレクト、Shift_JIS/EUC-JP/UTF-8 |
| ファイル | FAT12 の RAM ディスク(約 1.9MB、読み書き・サブディレクトリ対応) |
| 必要メモリ | 16MB 以上(64MB 程度を推奨) |

![ブラウザ](docs/screens/s3_japanese.png)

---

## 1. 起動のしかた

### QEMU
```
qemu-system-i386 -m 64 -fda nagisinnra-os-v35.img -boot a -vga std \
    -netdev user,id=n0 -device ne2k_pci,netdev=n0 -debugcon stdio
```
- ISA 版の NE2000 にも対応する設計です: `-device ne2k_isa,netdev=n0,iobase=0x300,irq=9`(PCI 版・ISA 版とも自作エミュレータ上では確認済み)
- QEMU の user ネットワークなら DHCP で `10.0.2.15`、DNS は `10.0.2.3` が割り当てられ、**http://** サイトに繋がるはずです(実機の QEMU での確認は未実施。§5 参照)。
- `-debugcon stdio` を付けると、OS が出す診断ログ(NIC 検出・DHCP・HTTP 失敗理由)がターミナルに出ます。

### v86 など
フロッピー(`fda`)にこのイメージを指定し、ネットワークデバイスとして **NE2000** を有効にしてください(v86 のネットワーク設定はバージョンで名称が異なります)。
v86 の標準ネットワークは `192.168.86.x` です。DHCP が応答しない場合、OS は約 8 秒で `192.168.86.100 / 24`(GW・DNS は `.1`)に自動フォールバックします。

---

## 2. 使い方

| キー | 動作 |
|---|---|
| F1 / F2 / F3 / F4 / F5 / F6 | ターミナル / ファイル / エディタ / ペイント / システム / ブラウザ |
| F7 F8 F9 F10 F12 | テトリス / スネーク / マインズ / ゲームセンター(1000本) / アーケード |
| Ctrl+W | アクティブなウィンドウを閉じる |
| マウス | タイトルバーのドラッグで移動、右下の角でリサイズ、●で最大化、赤い × で閉じる、ホイール対応 |

**ブラウザ**: `Ctrl+L` アドレス欄、`Ctrl+R` 再読込、`Alt+←/→` 戻る/進む、`Ctrl+U` ソース表示、`Esc` 中止、PgUp/PgDn/Home/End/Space でスクロール。
HTTPS は TLS が無いため開けません(その旨のページが表示されます)。テキスト以外のファイルは `\DOWNLOAD` に自動保存されます。

**ターミナル**(Tab 補完、↑↓ 履歴、PgUp/PgDn スクロール、Ctrl+C でジョブ中断):
```
dir cd pwd type copy ren del mkdir rmdir echo text > file edit file run file.com
ifconfig [ip mask gw dns]   dhcp   ping host [n]   nslookup host
wget url [file]   curl url   browse [url]
mem  date  uptime  ver  cls  usb  mount  udir  reboot  shutdown
```
ping / wget / curl / nslookup / dhcp は非同期で動くため、実行中も画面は固まりません。

**エディタ**: Ctrl+S 保存、Ctrl+O 開く、Ctrl+N 新規、名前を付けて保存、UTF-8(日本語表示)。
**ペイント**: ペン/消しゴム/塗りつぶし、16色、ブラシ3段階、24bit BMP で保存。

> RAM ディスクなので、作成したファイルは **再起動で消えます**(ディスクへの書き戻しは未実装)。

---

## 3. V34 から何を直したか

作業の最初に、V34 のコードを読んで次の問題を見つけ、作り直しました。

| 区分 | V34 の問題 | V35 |
|---|---|---|
| NIC | `DCR=0x49`(16bit転送)なのにデータポートを1バイトずつ読む。QEMU 等では1アクセスで2バイト進み受信データが壊れる | 標準手順(8bit転送 `0x48`)に変更 |
| NIC | MAC を `PAR` レジスタから読む(実機・QEMU では未初期化=0) | PROM から読み、NE2000 の「バイト2重化」配置も判別 |
| NIC | 受信を ISR のビットで判定 → 連続受信で取りこぼす | `BNRY`/`CURR` のリングポインタで判定、ラップは2回に分けて読む |
| ネット | IP が `192.168.86.x` 固定、DHCP なし | DHCP、失敗時に自動フォールバック |
| ネット | DNS の CNAME 未対応、TCP は再送・順序制御なし | CNAME 追跡、再送(指数バックオフ)、重複ACK、ウィンドウ制御 |
| HTTP | `Content-Length`・chunked・リダイレクト非対応 | 3方式の本文終端判定、301/302/303/307/308 追従 |
| 時間 | タイムアウト・ゲーム速度が「ループ回数」依存(CPU速度で変わる) | PIT による実時間ベース |
| 表示 | 5x7 フォントは大文字のみ、`/` が `S`、`_` が `Z` に化ける(URLが読めない) | 全 ASCII + Latin-1 + 日本語(第1水準漢字+かな+記号)。旧フォントも記号を修正 |
| ブート | BSS をゼロクリアしていない(実機で不定) | エントリコードでクリア(先にFSを退避してから) |
| ブート | カーネル 56KB 上限・サイズ固定 | イメージ側ヘッダでサイズ可変(現在 ~250KB)、RAM 容量を E801 で検出 |
| ブート | INT13h 拡張が無い BIOS で起動不可 | CHS フォールバック |
| FS | 保存は常に `EDIT.TXT` 固定、96セクタのみ | 作成・上書き・削除・リネーム・mkdir・パス解決、約 1.9MB |
| 入力 | 拡張キー(E0)・Ctrl/Alt・Home/End/Del 等が未対応、ホイールなし | 対応(IntelliMouse ホイールも) |
| 例外 | 例外で無言リセット | パニック画面(例外番号・EIP)を表示 |
| 操作 | 全画面再描画のたびにカーソルが止まる | カーソルだけ画面メモリへ直接描画(描画コストと切り離し) |

---

## 4. 構造

### ディスクとメモリ
```
LBA 0        ブートセクタ(512B。末尾 0x1F0 にサイズヘッダ。mkimg が書き込む)
LBA 1..495   カーネル(0x10000 に読み込み。253,440 バイト)
LBA 496..550 FAT12 ボリュームの先頭部分(55 セクタ)(カーネル直後に読み込み → 起動時に RAM ディスクへ移動)

0x00500   BootInfo(マジック 'NAG5'、RAM(KB)、起動ドライブ、読込セクタ数 …)
0x10000   カーネル(.text/.rodata/.data 約 250KB、うちフォント 約 120KB)、直後に BSS(~0x7FFxx まで。上限 0x8E000 はビルド時に検査)
0x90000   VBE モード情報 / 0x9F000 スタック上端
0x200000  RAM ディスク(FAT12、4000 セクタ)
0x400000  バックバッファ  /  0x500000 背景(星空)
0x600000〜 ページアロケータ(検出した RAM の末端まで、最大 60MB)
```

### ネットワークスタック(`src/nic.c net.c http.c`)
Ethernet → ARP(保留フレーム付き)→ IPv4 → ICMP / UDP / TCP。DHCP クライアント、DNS リゾルバ(キャッシュ・CNAME)、TCP クライアント(再送・順序外データの再要求・FIN/RST 処理・受信ウィンドウ制限)、HTTP/1.1 クライアント(ヘッダ 8KB まで、本文 256KB まで)。
すべてポーリング駆動で、メインループから呼ばれます(`net_poll()` / `http_poll()`)。

### ブラウザ(`src/html.c browser.c`)
HTML を単語単位で折り返すテキストレイアウトに変換します(見出し・段落・箇条書き・番号リスト・表・`<pre>`・`<hr>`・リンク・エンティティ・`<script>`/`<style>` の除去)。文字コードは HTTP ヘッダ / `<meta>` / 自動判定で UTF-8・Shift_JIS・EUC-JP・Latin-1 を処理します。

---

## 5. 検証について(重要)

**このOSを QEMU・v86・実機で動かしての確認は、私の環境ではできていません**(実行環境に QEMU/v86 がなく、ネットワークも使えませんでした)。
代わりに、検証のために **x86 エミュレータを自作**(`emu/nagiemu.c`、C 約 700 行)しました。実モード+プロテクトモード、BIOS(INT10h VBE / INT13h / INT15h)、PS/2、PIT、PCI、CMOS、VBE フレームバッファ、そして QEMU の挙動に合わせた NE2000(DP8390 のリングバッファ)を備えます。さらに v86 風の仮想ネットワーク(`tests/peer.py`: ARP・DHCP・DNS・ICMP と、本物のTCPサーバ)を Python で書き、ブートからHTTP取得までを自動テストしています。

自作エミュレータ自体の妥当性は、**V34 の配布イメージ(別のコード)をそのまま起動して GUI が正しく出る**ことで確認しました。

| テスト | 結果 |
|---|---|
| DHCP→DNS(CNAME)→HTTP、150KB(115セグメント)のバイト単位一致、chunked、close終端、リダイレクト、404、HTTPS拒否、NXDOMAIN、ping | 合格 |
| 損失 5% / 15%、順序入れ替え 20%、重複 10%+損失 5%+入替 10%、PCI NIC、DHCPなし、MSS 536 | 全て完全一致で取得 |
| FAT12: 254 項目(拡張・満杯・上書き・リネーム・削除・サブディレクトリ)+**別実装の FAT パーサ**で突き合わせ | 0 失敗、クロスリンク・リークなし |
| HTML レイアウト: 12 ケース(UTF-8/SJIS/EUC/Latin-1、リスト・表・`<pre>`・不正 HTML) | 目視確認済み |
| 起動: INT13h 拡張あり/なし × RAM 16/32/64MB | 全て起動 |
| GUI 総合: ターミナル/ブラウザ/エディタ/ファイル/ペイント/ゲーム、24回連続読み込み | メモリ増加 0、エラー系から復帰 |
| 再現性: 展開した別ディレクトリで `make` した結果 | **配布イメージとバイト一致** |

**未確認のこと**
- 実際の QEMU / v86 / 実機での動作。特に **v86 の NE2000 や DHCP/ARP の細かな挙動**は、仕様に沿って書いたものの未検証です。
- USB マスストレージ層(`usb.c`)は V34 のコードをそのまま移植したもので、エミュレータに UHCI が無いため未検証です。
- 実インターネット上のサイト(私のテストでは通信できません)。

初回の実行で問題が出た場合は、QEMU の `-debugcon stdio` の出力(`nic: ... / dhcp: ... / http: ... failed`)と、ターミナルの `ifconfig` の表示を手がかりにしてください。

---

## 6. 既知の制限

- **HTTPS 非対応**(TLS なし)。http:// のみ。
- RAM ディスクのため**保存は揮発**。
- 画像・CSS・JavaScript・フォーム送信は非対応(テキスト表示)。表は文字の並びで表現します。
- 漢字は JIS 第1水準+かな・記号まで(第2水準は未収録)。日本語入力(IME)なし。キーボードは US 配列として扱います。
- NIC は NE2000 のみ(RTL8139 / E1000 / virtio は未対応)。IPv4 のみ。IP フラグメントの再構成なし。
- ページは 256KB、レイアウトは約 12 万文字まで(超過分は切り捨て)。
- ビジーループ動作のため CPU を常時使用します。

## 7. ビルドとテスト

必要なもの: `gcc`(32bit 生成可)、`binutils`(`as` `ld` `objcopy`)、`make`、Python 3(+ `numpy` `Pillow`)。
```
make            # nagisinnra-os-v35.img を生成
make test       # エミュレータをビルドし、全回帰テストを実行(数分かかります)
```
```
src/    カーネル(boot.S entry.S kmain.c wm.c gfx.c term.c browser.c html.c editor.c files.c paint.c sys.c
        nic.c net.c http.c fat12.c input.c timer.c mem.c lib.c panic.c / games.c sky.c usb.c は V34 から移植)
tools/  mkimg.py(イメージ生成)mkfat.py(FAT12)genfont.py(フォントデータ生成)
emu/    nagiemu.c(テスト用 x86 エミュレータ)emu.py(Python から制御)
tests/  peer.py(仮想ネットワーク)と各テスト、run_all.sh
docs/   スクリーンショット
```
