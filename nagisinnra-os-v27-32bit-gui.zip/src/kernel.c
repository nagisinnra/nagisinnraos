#include <stdint.h>

#define W 800
#define H 600
#define FSBASE 0x20000u
#define VBE_INFO 0x90000u
static volatile uint16_t *const fb=(volatile uint16_t*)0xE0000000u;
/* v23: system RAM back buffer. All drawing goes here; one full-frame copy
   is performed after a redraw. This removes visible tearing/flicker. */
static volatile uint16_t *const backbuf=(volatile uint16_t*)0x00300000u;
static uint32_t fb_phys=0, pitch=1600;

static inline uint8_t inb(uint16_t p){uint8_t v;__asm__ volatile("inb %1,%0":"=a"(v):"Nd"(p));return v;}
static inline void outb(uint16_t p,uint8_t v){__asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p));}

static uint16_t rgb(uint8_t r,uint8_t g,uint8_t b){return (uint16_t)(((r>>3)<<11)|((g>>2)<<5)|(b>>3));}
static void putp(int x,int y,uint16_t c){if((unsigned)x<W&&(unsigned)y<H) backbuf[(uintptr_t)y*W+(uintptr_t)x]=c;}
static void fill(int x,int y,int w,int h,uint16_t c){if(w<=0||h<=0)return;if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}if(x+w>W)w=W-x;if(y+h>H)h=H-y;if(w<=0||h<=0)return;for(int yy=0;yy<h;yy++){volatile uint16_t*d=backbuf+(uintptr_t)(y+yy)*W+(uintptr_t)x;for(int xx=0;xx<w;xx++)d[xx]=c;}}
static int inside(int x,int y,int w,int h,int px,int py){return px>=x&&px<x+w&&py>=y&&py<y+h;}

/* Compact 5x7 font: A-Z, 0-9, space and UI punctuation. */
static const uint8_t font[][7]={
{14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},
{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,14},{17,17,17,31,17,17,17},
{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},
{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},
{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,27,17},{17,17,10,4,10,17,17},
{17,17,10,4,4,4,4},{31,1,2,4,8,16,31},
{14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},
{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},
{14,17,17,14,17,17,14},{14,17,17,15,1,1,14},
{0,0,0,0,0,0,0},{0,4,0,0,0,4,0},{0,0,0,31,0,0,0},{0,0,0,0,0,0,4},
{31,1,2,4,8,16,31},{31,16,8,4,2,1,31}
};
static const char chars[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 :-._/< >";
static const uint8_t*glyph(char c){if(c>='a'&&c<='z')c=(char)(c-'a'+'A');for(unsigned i=0;i<sizeof(chars)-1;i++)if(chars[i]==c)return font[i];return font[36];}
static void text(int x,int y,const char*s,uint16_t c,int scale){while(*s){const uint8_t*g=glyph(*s++);for(int r=0;r<7;r++)for(int b=0;b<5;b++)if(g[r]&(1u<<(4-b)))fill(x+b*scale,y+r*scale,scale,scale,c);x+=6*scale;}}

/* Rounded rectangles. */
static void roundrect(int x,int y,int w,int h,int r,uint16_t c){
 if(r<1){fill(x,y,w,h,c);return;} if(r*2>w)r=w/2;if(r*2>h)r=h/2;
 fill(x+r,y,w-2*r,h,c);fill(x,y+r,r,h-2*r,c);fill(x+w-r,y+r,r,h-2*r,c);
 for(int yy=0;yy<r;yy++)for(int xx=0;xx<r;xx++){int dx=r-1-xx,dy=r-1-yy;if(dx*dx+dy*dy<r*r){putp(x+xx,y+yy,c);putp(x+w-1-xx,y+yy,c);putp(x+xx,y+h-1-yy,c);putp(x+w-1-xx,y+h-1-yy,c);}}
}

/* Background: deep sky + deterministic stars + diagonal Milky Way band. */
static uint32_t rng=0x51a7c3d1u;
static uint32_t rnd(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static void draw_sky(void){
 uint16_t top=rgb(5,7,25), bottom=rgb(2,3,12);
 for(int y=0;y<H;y++){uint8_t t=(uint8_t)((y*255)/(H-1));uint8_t r=(uint8_t)(((top>>11)&31)*8 + (((bottom>>11)&31)*8-((top>>11)&31)*8)*t/255);(void)r;uint8_t rr=(uint8_t)(5-(3*t/255)),gg=(uint8_t)(7-(4*t/255)),bb=(uint8_t)(25-(13*t/255));fill(0,y,W,1,rgb(rr,gg,bb));}
 /* soft Milky Way: many tiny translucent-looking pale pixels, concentrated along x/1.8 - y/2.0. */
 rng=0x51a7c3d1u;
 for(int i=0;i<2600;i++){int x=(int)(rnd()%W), y=(int)(rnd()%H);int band=(x*3/4 + 80);int d=y-band;if(d<0)d=-d;if(d<55){uint32_t q=rnd()%100;int size=(q<92)?1:2;uint8_t br=(uint8_t)(22+(55-(d<55?d:55))/2+(rnd()%35));uint8_t rr=(uint8_t)(br/2),gg=(uint8_t)(br*3/4),bb=br;roundrect(x,y,size,size,1,rgb(rr,gg,bb));}}
 /* brighter stars */
 for(int i=0;i<180;i++){int x=(int)(rnd()%W),y=(int)(rnd()%H);uint8_t b=(uint8_t)(120+rnd()%136);putp(x,y,rgb(b,b,b));if((rnd()&7)==0){putp(x+1,y,rgb(b/2,b/2,b/2));putp(x-1,y,rgb(b/2,b/2,b/2));}}
}

/* FAT12 RAM volume. */
static uint8_t*fs=(uint8_t*)FSBASE;
static uint16_t fat12_get(uint16_t cl){uint32_t o=512+((uint32_t)cl*3)/2;uint16_t v=fs[o]|((uint16_t)fs[o+1]<<8);return (cl&1)?(v>>4)&0xfff:v&0xfff;}
static uint8_t*cluster_ptr(uint16_t cl){return fs+(5u+(cl-2u))*512u;}
static void name83(char*out,const uint8_t*e){int k=0;for(int i=0;i<8&&e[i]!=' ';i++)out[k++]=e[i];if(e[8]!=' '){out[k++]='.';for(int i=8;i<11&&e[i]!=' ';i++)out[k++]=e[i];}out[k]=0;}
static int file_count(void){int n=0;for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]!=0xe5&&e[11]!=0x0f)n++;}return n;}
static int read_file(int ent,char*out,int cap){if(ent<0)return 0;uint8_t*e=fs+1536+ent*32;uint16_t cl=e[26]|((uint16_t)e[27]<<8);uint32_t sz=e[28]|((uint32_t)e[29]<<8)|((uint32_t)e[30]<<16)|((uint32_t)e[31]<<24);if(sz>(uint32_t)cap-1)sz=cap-1;uint32_t pos=0;while(cl>=2&&cl<0xff8&&pos<sz){uint8_t*p=cluster_ptr(cl);uint32_t take=sz-pos;if(take>512)take=512;for(uint32_t i=0;i<take;i++)out[pos+i]=(char)p[i];pos+=take;cl=fat12_get(cl);}out[pos]=0;return (int)pos;}
static int find_entry(const char*name){for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;char n[16];name83(n,e);int j=0;while(name[j]&&n[j]&&name[j]==n[j])j++;if(!name[j]&&!n[j])return i;}return -1;}

/* PS/2 */
static int mx=400,my=300;static uint8_t mp[3],mpos,mbuttons,mlast,mpress;
static uint8_t shift;
static void wait_ibf_clear(void){for(int i=0;i<100000;i++)if(!(inb(0x64)&2))return;}
static int wait_obf(void){for(int i=0;i<100000;i++)if(inb(0x64)&1)return 1;return 0;}
static void mouse_cmd(uint8_t c){wait_ibf_clear();outb(0x64,0xd4);wait_ibf_clear();outb(0x60,c);}
static void mouse_init(void){wait_ibf_clear();outb(0x64,0xa8);mouse_cmd(0xf4);if(wait_obf())(void)inb(0x60);mpos=0;mx=400;my=300;mbuttons=mlast=mpress=0;}
static int mouse_poll(void){int changed=0;while((inb(0x64)&1)&&(inb(0x64)&0x20)){uint8_t b=inb(0x60);mp[mpos++]=b;if(mpos<3)continue;mpos=0;int dx=(int8_t)mp[1],dy=(int8_t)mp[2];if(!(mp[0]&0xc0)){int nx=mx+dx,ny=my-dy;if(nx<0)nx=0;if(nx>=W)nx=W-1;if(ny<0)ny=0;if(ny>=H)ny=H-1;if(nx!=mx||ny!=my)changed=1;mx=nx;my=ny;}mbuttons=mp[0]&7;if((mbuttons&1)&&!(mlast&1))mpress=1;mlast=mbuttons;}return changed;}
static int keyboard_get(uint8_t*out){if(!(inb(0x64)&1))return 0;if(inb(0x64)&0x20)return 0;uint8_t s=inb(0x60);if(s==0x2a||s==0x36){shift=1;return 0;}if(s==0xaa||s==0xb6){shift=0;return 0;}if(s&0x80)return 0;*out=s;return 1;}
static char keychar(uint8_t s){
 switch(s){
  case 0x02:return shift?'!':'1'; case 0x03:return shift?'@':'2'; case 0x04:return shift?'#':'3';
  case 0x05:return shift?'$':'4'; case 0x06:return shift?'%':'5'; case 0x07:return shift?'^':'6';
  case 0x08:return shift?'&':'7'; case 0x09:return shift?'*':'8'; case 0x0a:return shift?'(':'9';
  case 0x0b:return shift?')':'0'; case 0x0c:return shift?'_':'-'; case 0x0d:return shift?'+':'=';
  case 0x0e:return '\b'; case 0x0f:return '\t'; case 0x10:return 'q'; case 0x11:return 'w';
  case 0x12:return 'e'; case 0x13:return 'r'; case 0x14:return 't'; case 0x15:return 'y';
  case 0x16:return 'u'; case 0x17:return 'i'; case 0x18:return 'o'; case 0x19:return 'p';
  case 0x1a:return shift?'{':'['; case 0x1b:return shift?'}':']'; case 0x1c:return '\n';
  case 0x1e:return 'a'; case 0x1f:return 's'; case 0x20:return 'd'; case 0x21:return 'f';
  case 0x22:return 'g'; case 0x23:return 'h'; case 0x24:return 'j'; case 0x25:return 'k';
  case 0x26:return 'l'; case 0x27:return shift?':':';'; case 0x28:return shift?'"':'\'';
  case 0x29:return shift?'~':'`'; case 0x2b:return shift?'|':'\\'; case 0x2c:return 'z';
  case 0x2d:return 'x'; case 0x2e:return 'c'; case 0x2f:return 'v'; case 0x30:return 'b';
  case 0x31:return 'n'; case 0x32:return 'm'; case 0x33:return shift?'<':','; case 0x34:return shift?'>':'.';
  case 0x35:return shift?'?':'/'; case 0x39:return ' '; default:return 0;
 }
}

#define APP_TERM 0
#define APP_FILES 1
#define APP_EDIT 2
#define APP_PAINT 3
#define APP_TASKS 4
#define APP_BROWSER 5
#define APP_TETRIS 6
#define APP_SNAKE 7
#define APP_MINES 8
#define APP_BREAKOUT 9
#define APP_GAMES 10
#define APP_ARCADE 11
typedef struct {int x,y,w,h,open,drag,ox,oy;uint8_t app;char title[16];} Window;
static Window win[12];static int active=0,drag_win=-1;
static int arcade_game=0;
static void titlebar(Window*w);
static void window_bg(Window*w);
static char term_in[48];static int term_n;
static char term_out[9][55];static int term_lines;
static char editor[4097];static int editor_n,editor_file=-1;static int editor_row,editor_col;
static int paint_color=14;
static uint16_t *paintbuf=(uint16_t*)0x00400000u;
#define PW 394
#define PH 215
static char browser_url[64];
static int browser_focus=0;
static int browser_url_n;
static char browser_lines[12][72];
static int browser_n;
/* Tetris: compact 10x20 board, rendered inside its own window. */
static uint8_t tboard[200];
static int tx=3,ty=0,trot=0,tpiece=0,tscore=0,tlines=0,timer=0,tgame=0;
static const uint8_t tshapes[7][4][4]={
 {{0,0,0,0},{1,1,1,1},{0,0,0,0},{0,0,0,0}},
 {{1,0,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
 {{0,0,1,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
 {{1,1,0,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
 {{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
 {{0,1,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
 {{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}}};
static uint16_t tcols[8];
static uint32_t trng=0x12345678u;
static uint32_t trand(void){trng^=trng<<13;trng^=trng>>17;trng^=trng<<5;return trng;}

extern int net_init(void);
extern int net_http_get(const char*host,const char*path,char*out,int cap);

static void scpy(char*d,const char*s,int n){int i=0;for(;i<n-1&&s[i];i++)d[i]=s[i];d[i]=0;}

/* Games Center + six compact arcade games. The original four games remain separate. */
static int pong_l=100,pong_r=100,pong_x=190,pong_y=110,pong_dx=2,pong_dy=1,pong_score_l=0,pong_score_r=0,pong_run=0,pong_tick=0;
static int dodger_x=190,dodger_y=350,dodger_score=0,dodger_run=0,dodger_tick=0;
static int flap_y=150,flap_v=0,flap_score=0,flap_run=0,flap_tick=0,flap_gap=100,flap_px=250;
static int react_wait=0,react_ready=0,react_done=0,react_score=0,react_tick=0;
static int maze_x=1,maze_y=1,maze_won=0;
static uint8_t maze_map[12][16]={
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
 {1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},
 {1,0,1,0,1,0,1,1,1,0,1,0,1,1,0,1},
 {1,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1},
 {1,0,1,1,1,1,1,0,1,1,1,0,1,0,1,1},
 {1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1},
 {1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,1},
 {1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,1},
 {1,0,1,0,1,1,1,0,1,1,1,1,0,1,0,1},
 {1,0,1,0,0,0,0,0,0,0,0,1,0,0,0,1},
 {1,0,0,0,1,1,1,1,1,1,0,1,1,1,0,1},
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
static uint8_t g2048[16]; static int g2048_score=0,g2048_run=0;
static uint32_t g_rng=0x72a51b3du;
static uint32_t g_rand(void){g_rng^=g_rng<<13;g_rng^=g_rng>>17;g_rng^=g_rng<<5;return g_rng;}
static void g2048_add(void){int freei[16],n=0;for(int i=0;i<16;i++)if(!g2048[i])freei[n++]=i;if(!n)return;g2048[freei[g_rand()%n]]=(g_rand()%10==0)?2:1;}
static void g2048_new(void){for(int i=0;i<16;i++)g2048[i]=0;g2048_score=0;g2048_run=1;g2048_add();g2048_add();}
static int g2048_move(int dir){uint8_t old[16];for(int i=0;i<16;i++)old[i]=g2048[i];
 for(int line=0;line<4;line++){uint8_t a[4]={0},b[4]={0};int k=0;
  for(int j=0;j<4;j++){int idx=(dir==0?j*4+line:dir==1?line*4+(3-j):dir==2?(3-j)*4+line:line*4+j);if(g2048[idx])a[k++]=g2048[idx];}
  int z=0;for(int j=0;j<k;j++){if(j+1<k&&a[j]==a[j+1]){b[z++]=(uint8_t)(a[j]+1);g2048_score+=(1<<b[z-1]);j++;}else b[z++]=a[j];}
  while(z<4)b[z++]=0;for(int j=0;j<4;j++){int idx=(dir==0?j*4+line:dir==1?line*4+(3-j):dir==2?(3-j)*4+line:line*4+j);g2048[idx]=b[j];}}
 int changed=0;for(int i=0;i<16;i++)if(old[i]!=g2048[i])changed=1;if(changed)g2048_add();return changed;}
static void pong_new(void){pong_l=pong_r=95;pong_x=235;pong_y=135;pong_dx=2;pong_dy=1;pong_score_l=pong_score_r=0;pong_tick=0;pong_run=1;}
static void pong_step(void){if(!pong_run)return;pong_x+=pong_dx;pong_y+=pong_dy;if(pong_y<10||pong_y>260)pong_dy=-pong_dy;if(pong_x<30&&pong_x>20&&pong_y>=pong_l-12&&pong_y<=pong_l+50)pong_dx=2;if(pong_x>440&&pong_x<450&&pong_y>=pong_r-12&&pong_y<=pong_r+50)pong_dx=-2;if(pong_x<0){pong_score_r++;pong_x=235;pong_y=135;pong_dx=2;}if(pong_x>470){pong_score_l++;pong_x=235;pong_y=135;pong_dx=-2;}if(pong_r+25<pong_y)pong_r+=2;if(pong_r+25>pong_y+8)pong_r-=2;if(pong_l+25<pong_y)pong_l+=2;if(pong_l+25>pong_y+8)pong_l-=2;}
static void dodger_new(void){dodger_x=235;dodger_y=270;dodger_score=0;dodger_tick=0;dodger_run=1;}
static void dodger_step(void){if(!dodger_run)return;dodger_tick++;if((dodger_tick%18)==0)dodger_score++;}
static void flap_new(void){flap_y=150;flap_v=0;flap_score=0;flap_gap=100;flap_px=250;flap_tick=0;flap_run=1;}
static void flap_step(void){if(!flap_run)return;flap_v++;flap_y+=flap_v/3;if(flap_y<5){flap_y=5;flap_v=0;}if(flap_y>285)flap_run=0;flap_tick++;if(flap_tick%50==0){flap_gap=70+(int)(g_rand()%130);flap_score++;}}
static void react_new(void){react_wait=40+(int)(g_rand()%100);react_ready=0;react_done=0;react_score=0;react_tick=0;}
static void maze_new(void){maze_x=1;maze_y=1;maze_won=0;}
static void arcade_new(int g){arcade_game=g;if(g==0)pong_new();else if(g==1)g2048_new();else if(g==2)dodger_new();else if(g==3)flap_new();else if(g==4)react_new();else if(g==5)maze_new();}
static void draw_games(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"GAMES CENTER",rgb(100,255,160),1);text(w->x+18,w->y+58,"10 GAMES",rgb(160,180,220),1);
 const char*names[] = {"TETRIS","SNAKE","MINES","BREAKOUT","PONG","2048","DODGER","FLAPPY","REACTION","MAZE"};
 const char*sub[] = {"BLOCKS","ARCADE","PUZZLE","BALL","2 PLAYER","PUZZLE","DODGE","FLY","SPEED","ESCAPE"};
 for(int i=0;i<10;i++){int col=i%2,row=i/2,x=w->x+18+col*190,y=w->y+80+row*55;roundrect(x,y,175,44,7,rgb(10,14,27));text(x+10,y+8,names[i],rgb(235,240,255),1);text(x+10,y+23,sub[i],rgb(120,150,190),1);text(x+148,y+17,"PLAY",rgb(80,220,255),1);}}
static void draw_arcade(Window*w){window_bg(w);titlebar(w);const char*names[]={"PONG","2048","DODGER","FLAPPY","REACTION","MAZE"};text(w->x+18,w->y+40,names[arcade_game],rgb(100,255,160),1);text(w->x+w->w-100,w->y+40,"ESC BACK",rgb(160,180,220),1);
 if(arcade_game==0){roundrect(w->x+15,w->y+58,470,300,5,rgb(3,6,13));fill(w->x+25,w->y+58+pong_l,7,50,rgb(80,220,255));fill(w->x+463,w->y+58+pong_r,7,50,rgb(255,130,100));roundrect(w->x+15+pong_x,w->y+58+pong_y,8,8,4,rgb(245,245,255));char z[24];z[0]='0'+pong_score_l;z[1]=':';z[2]='0'+pong_score_r;z[3]=0;text(w->x+230,w->y+72,z,rgb(235,240,255),2);text(w->x+120,w->y+380,"W/S  LEFT   UP/DOWN  RIGHT",rgb(170,190,220),1);text(w->x+175,w->y+400,"SPACE START",rgb(255,180,100),1);}
 else if(arcade_game==1){for(int y=0;y<4;y++)for(int x=0;x<4;x++){int v=g2048[y*4+x];roundrect(w->x+40+x*78,w->y+65+y*78,70,70,8,v?rgb(40+v*12,45+v*10,75+v*8):rgb(10,14,27));if(v){char z[8];int val=1<<v,n=0;if(val>=1000){z[n++]='0'+val/1000;z[n++]='0'+(val/100)%10;z[n++]='0'+(val/10)%10;z[n++]='0'+val%10;}else if(val>=100){z[n++]='0'+val/100;z[n++]='0'+(val/10)%10;z[n++]='0'+val%10;}else if(val>=10){z[n++]='0'+val/10;z[n++]='0'+val%10;}else z[n++]='2';z[n]=0;text(w->x+63+x*78,w->y+92+y*78,z,rgb(240,245,255),2);}}text(w->x+40,w->y+390,"ARROWS MOVE   SPACE NEW",rgb(170,190,220),1);}
 else if(arcade_game==2){roundrect(w->x+20,w->y+60,470,300,5,rgb(4,7,14));roundrect(w->x+dodger_x,w->y+dodger_y,30,30,6,rgb(80,220,255));for(int i=0;i<8;i++){int bx=30+(i*61+(dodger_score*7)%61)%430;int by=75+(i*31+(dodger_score*11)%240)%260;roundrect(w->x+bx,w->y+by,18,18,5,rgb(255,90,110));}text(w->x+20,w->y+390,"LEFT / RIGHT   SPACE START",rgb(170,190,220),1);}
 else if(arcade_game==3){roundrect(w->x+20,w->y+60,470,300,5,rgb(4,7,14));fill(w->x+flap_px,w->y+flap_gap-55,28,55,rgb(80,220,170));fill(w->x+flap_px,w->y+flap_gap+65,28,180,rgb(80,220,170));roundrect(w->x+90,w->y+flap_y,22,22,10,rgb(255,210,70));text(w->x+20,w->y+390,"SPACE FLAP   SCORE",rgb(170,190,220),1);}
 else if(arcade_game==4){roundrect(w->x+70,w->y+80,350,190,12,react_ready?rgb(55,180,120):rgb(18,24,40));if(react_done)text(w->x+130,w->y+160,"RESULT",rgb(240,245,255),2);else text(w->x+125,w->y+160,react_ready?"CLICK!":"WAIT...",rgb(240,245,255),2);text(w->x+120,w->y+300,"MOUSE CLICK   SPACE NEW",rgb(170,190,220),1);}
 else {int ox=w->x+60,oy=w->y+60,cell=25;for(int y=0;y<12;y++)for(int x=0;x<16;x++){uint16_t c=maze_map[y][x]?rgb(16,22,38):rgb(5,8,15);fill(ox+x*cell,oy+y*cell,24,24,c);}roundrect(ox+maze_x*cell+5,oy+maze_y*cell+5,14,14,5,rgb(80,220,255));roundrect(ox+14*cell+5,oy+10*cell+5,14,14,5,rgb(100,255,160));text(w->x+20,w->y+380,"ARROWS MOVE   REACH GREEN",rgb(170,190,220),1);if(maze_won)text(w->x+190,w->y+380,"CLEAR!",rgb(100,255,170),1);}}

static void init_windows(void){
 win[0]=(Window){64,112,430,300,1,0,0,0,APP_TERM,"Terminal"};
 win[1]=(Window){190,145,390,285,0,0,0,0,APP_FILES,"Files"};
 win[2]=(Window){220,128,420,290,0,0,0,0,APP_EDIT,"Editor"};
 win[3]=(Window){250,105,430,340,0,0,0,0,APP_PAINT,"Paint"};
 win[4]=(Window){310,170,260,220,0,0,0,0,APP_TASKS,"Tasks"};
 win[5]=(Window){70,62,660,450,0,0,0,0,APP_BROWSER,"Browser"};
 win[6]=(Window){335,105,300,420,0,0,0,0,APP_TETRIS,"Tetris"};
 win[7]=(Window){55,85,350,430,0,0,0,0,APP_SNAKE,"Snake"};
 win[8]=(Window){190,70,420,470,0,0,0,0,APP_MINES,"Mines"};
 win[9]=(Window){150,85,500,430,0,0,0,0,APP_BREAKOUT,"Breakout"};
 win[10]=(Window){145,72,510,500,0,0,0,0,APP_GAMES,"Games"};
 win[11]=(Window){145,72,510,500,0,0,0,0,APP_ARCADE,"Game"};
}
static void titlebar(Window*w){
 /* Ultra-thin, 22px chrome: the desktop is the frame. */
 roundrect(w->x,w->y,w->w,22,5,rgb(18,21,38));
 fill(w->x+5,w->y,w->w-10,11,rgb(18,21,38));
 text(w->x+10,w->y+7,w->title,rgb(225,231,248),1);
 /* tiny close control, intentionally subtle */
 roundrect(w->x+w->w-22,w->y+7,10,8,3,rgb(175,55,78));
}
static void window_bg(Window*w){
 /* 1px visual edge + almost-black content. */
 roundrect(w->x,w->y+18,w->w,w->h-18,5,rgb(3,5,12));
 fill(w->x+5,w->y+18,w->w-10,w->h-23,rgb(3,5,12));
}
static void desktop(void){
 draw_sky();
 /* No heavy desktop bezel. Only a tiny brand mark. */
 text(20,18,"NAGISINNRA",rgb(225,231,248),1);
 text(694,18,"V27",rgb(135,160,205),1);
}
static void taskbar(void){
 fill(0,578,W,22,rgb(8,10,22));fill(0,578,W,1,rgb(42,49,75));text(12,585,"N",rgb(115,220,255),1);
 const char*names[]={"Term","Files","Edit","Paint","Tasks","Web","Games"};int ids[]={0,1,2,3,4,5,10};int x=42;
 for(int k=0;k<7;k++){int id=ids[k],ww=(k==6)?58:48;uint16_t bg=(active==id&&win[id].open)?rgb(37,48,78):rgb(8,10,22);roundrect(x,580,ww,18,4,bg);text(x+8,586,names[k],(active==id&&win[id].open)?rgb(240,245,255):rgb(155,168,195),1);x+=ww+4;}
 text(720,586,"READY",rgb(105,225,165),1);
}
static void draw_term(Window*w){
 window_bg(w);titlebar(w);
 text(w->x+18,w->y+48,"NAGISINNRA OS",rgb(100,255,160),1);
 int yy=w->y+70;for(int i=0;i<term_lines&&yy<w->y+w->h-82;i++){text(w->x+18,yy,term_out[i],rgb(190,200,225),1);yy+=12;}
 text(w->x+18,w->y+w->h-64,"NAGISINNRA>",rgb(100,220,255),1);
 text(w->x+108,w->y+w->h-64,term_in,rgb(245,245,255),1);
 fill(w->x+108+term_n*6,w->y+w->h-66,5,9,rgb(245,245,255));
 text(w->x+18,w->y+w->h-35,"HELP VER DIR TYPE",rgb(150,170,205),1);
}
static void draw_files(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+48,"FAT12 VOLUME",rgb(100,255,160),1);int row=0;for(int i=0;i<32&&row<12;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;char n[16];name83(n,e);text(w->x+22,w->y+76+row*17,n,rgb(235,240,255),2);row++;}text(w->x+18,w->y+w->h-32,"CLICK FILE TO OPEN",rgb(160,180,220),2);}
static void draw_editor(Window*w){
 window_bg(w);titlebar(w);text(w->x+18,w->y+48,"TEXT EDITOR",rgb(100,255,160),1);
 int yy=w->y+76,col=w->x+18,row=0,cx=0;
 for(int i=0;i<editor_n&&yy<w->y+w->h-55;i++){char ch=editor[i];if(ch=='\n'){yy+=17;row++;col=w->x+18;cx=0;continue;}char one[2]={ch,0};text(col,yy,one,rgb(240,240,250),2);col+=12;cx++;if(col>w->x+w->w-30){yy+=17;row++;col=w->x+18;cx=0;}}
 if(editor_row>=0&&editor_row<((w->h-125)/17+1)){int cy=w->y+76+editor_row*17;int cxx=w->x+18+editor_col*12;if(cy<w->y+w->h-55&&cxx<w->x+w->w-20)fill(cxx,cy+1,2,15,rgb(80,220,255));}
 roundrect(w->x+18,w->y+w->h-42,76,28,6,rgb(40,190,190));text(w->x+31,w->y+w->h-34,"SAVE",rgb(0,0,0),2);roundrect(w->x+104,w->y+w->h-42,76,28,6,rgb(40,190,190));text(w->x+117,w->y+w->h-34,"OPEN",rgb(0,0,0),2);
}
static void draw_paint(Window*w){
 window_bg(w);titlebar(w);text(w->x+18,w->y+48,"PAINT",rgb(100,255,160),1);
 for(int y=0;y<PH;y++){volatile uint16_t*d=backbuf+(uintptr_t)(w->y+72+y)*W+(uintptr_t)(w->x+18);for(int x=0;x<PW;x++)d[x]=paintbuf[y*PW+x];}
 roundrect(w->x+20,w->y+w->h-42,22,22,5,rgb(80,220,255));roundrect(w->x+50,w->y+w->h-42,22,22,5,rgb(255,120,100));roundrect(w->x+80,w->y+w->h-42,22,22,5,rgb(220,220,220));text(w->x+116,w->y+w->h-34,"CLEAR",rgb(225,230,245),1);
}
static void draw_tasks(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+48,"MULTITASK",rgb(100,255,160),1);int row=0;for(int i=0;i<12;i++)if(win[i].open){text(w->x+20,w->y+78+row*25,win[i].title,(i==active)?rgb(100,255,180):rgb(235,240,255),2);row++;}}
static int starts(const char*s,const char*p);
static void browser_line(const char*s){if(browser_n<12){scpy(browser_lines[browser_n++],s,72);return;}for(int i=1;i<12;i++)scpy(browser_lines[i-1],browser_lines[i],72);scpy(browser_lines[11],s,72);}
static void browser_home(void){browser_n=0;browser_line("NAGISINNRA OS BROWSER");browser_line("REAL HTTP/1.0 NETWORKING");browser_line("");browser_line("Enter: http://host/path");browser_line("Example: http://neverssl.com/");browser_line("");browser_line("nagisinnra://home");browser_line("file://README.TXT");browser_line("file://ABOUT.TXT");}
static void browser_open(const char*u){
 scpy(browser_url,u,64);browser_url_n=0;while(browser_url[browser_url_n])browser_url_n++;browser_n=0;
 if(starts(u,"NAGISINNRA://HOME")||starts(u,"nagisinnra://home")){browser_home();return;}
 if(starts(u,"FILE://")||starts(u,"file://")){const char*name=u+7;int ent=find_entry(name);if(ent<0){browser_line("404 - FILE NOT FOUND");return;}char b[768];int n=read_file(ent,b,sizeof(b));browser_line(name);browser_line("");char line[72];int j=0;for(int i=0;i<n;i++){char ch=b[i];if(ch=='\r')continue;if(ch=='\n'||j>=70){line[j]=0;browser_line(line);j=0;}else line[j++]=ch;}if(j){line[j]=0;browser_line(line);}return;}
 if(starts(u,"HTTP://")||starts(u,"http://")){const char*host=u+7;const char*slash=host;while(*slash&&*slash!='/')slash++;char h[64];int hn=(int)(slash-host);if(hn<=0||hn>=63){browser_line("BAD URL");return;}for(int i=0;i<hn;i++)h[i]=host[i];h[hn]=0;const char*path=*slash?slash:"/";char body[1536];browser_line("CONNECTING...");browser_line("DNS / ARP / TCP / HTTP");int n=net_http_get(h,path,body,sizeof(body));if(n<0){browser_line("NETWORK ERROR");browser_line("Use v86 with NE2000 networking");browser_line("Backend: fetch / wsproxy / wisp");return;}browser_n=0;browser_line(h);browser_line("");int j=0;char line[72];for(int i=0;i<n;i++){char ch=body[i];if(ch=='\r')continue;if(ch=='\n'||j>=70){line[j]=0;browser_line(line);j=0;}else if((unsigned char)ch>=32||ch=='\t')line[j++]=ch;}if(j){line[j]=0;browser_line(line);}return;}
 browser_line("URL NOT SUPPORTED");browser_line("Use http://host/path");
}
static int tshape_cell(int piece,int rot,int x,int y){
 int sx=x,sy=y;
 /* rotations around a 4x4 box */
 for(int i=0;i<rot;i++){int nx=3-sy,ny=sx;sx=nx;sy=ny;}
 return tshapes[piece][sy][sx];
}
static int tvalid(int nx,int ny,int piece,int rot){
 for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(tshape_cell(piece,rot,x,y)){int bx=nx+x,by=ny+y;if(bx<0||bx>=10||by<0||by>=20||tboard[by*10+bx])return 0;}
 return 1;
}
static void tclear_lines(void){
 for(int y=19;y>=0;y--){int full=1;for(int x=0;x<10;x++)if(!tboard[y*10+x]){full=0;break;}
  if(full){for(int yy=y;yy>0;yy--)for(int x=0;x<10;x++)tboard[yy*10+x]=tboard[(yy-1)*10+x];for(int x=0;x<10;x++)tboard[x]=0;tlines++;tscore+=100;y++;}
 }
}
static void tspawn(void){tpiece=(int)(trand()%7);tx=3;ty=0;trot=0;if(!tvalid(tx,ty,tpiece,trot))tgame=0;}
static void tlock(void){for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(tshape_cell(tpiece,trot,x,y)){int bx=tx+x,by=ty+y;if(bx>=0&&bx<10&&by>=0&&by<20)tboard[by*10+bx]=tpiece+1;}tclear_lines();tspawn();}
static void tstep(void){if(!tgame)return;if(tvalid(tx,ty+1,tpiece,trot))ty++;else tlock();}
static void tnew(void){for(int i=0;i<200;i++)tboard[i]=0;tscore=0;tlines=0;timer=0;tgame=1;tspawn();}

/* Snake */
static uint8_t snake_x[180],snake_y[180];
static int snake_len=5,snake_dir=1,snake_next=1,snake_fx=12,snake_fy=10,snake_score=0,snake_game=0,snake_tick=0;
static uint32_t snake_rng=0x91a72b31u;
static uint32_t snake_rand(void){snake_rng^=snake_rng<<13;snake_rng^=snake_rng>>17;snake_rng^=snake_rng<<5;return snake_rng;}
static void snake_spawn_food(void){for(int tries=0;tries<500;tries++){int x=(int)(snake_rand()%20),y=(int)(snake_rand()%20);int ok=1;for(int i=0;i<snake_len;i++)if(snake_x[i]==x&&snake_y[i]==y)ok=0;if(ok){snake_fx=x;snake_fy=y;return;}}}
static void snake_new(void){snake_len=5;snake_dir=1;snake_next=1;snake_score=0;snake_tick=0;snake_game=1;for(int i=0;i<snake_len;i++){snake_x[i]=(uint8_t)(9-i);snake_y[i]=10;}snake_spawn_food();}
static void snake_step(void){if(!snake_game)return;snake_dir=snake_next;int nx=snake_x[0],ny=snake_y[0];if(snake_dir==0)ny--;else if(snake_dir==1)nx++;else if(snake_dir==2)ny++;else nx--;if(nx<0||nx>=20||ny<0||ny>=20){snake_game=0;return;}for(int i=0;i<snake_len;i++)if(snake_x[i]==nx&&snake_y[i]==ny){snake_game=0;return;}int eat=(nx==snake_fx&&ny==snake_fy);int lim=snake_len+(eat?1:0);if(lim>179)lim=179;for(int i=lim-1;i>0;i--){snake_x[i]=snake_x[i-1];snake_y[i]=snake_y[i-1];}snake_x[0]=nx;snake_y[0]=ny;if(eat){snake_len=lim;snake_score+=10;snake_spawn_food();}}
static void draw_snake(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"SNAKE",rgb(100,255,160),1);int ox=w->x+20,oy=w->y+62,cell=15;roundrect(ox,oy,302,302,5,rgb(5,8,15));for(int i=0;i<snake_len;i++)roundrect(ox+2+snake_x[i]*cell,oy+2+snake_y[i]*cell,12,12,3,i==0?rgb(80,240,180):rgb(35,150,120));roundrect(ox+2+snake_fx*cell,oy+2+snake_fy*cell,12,12,5,rgb(255,90,100));char n[16];int v=snake_score,k=0;if(!v)n[k++]='0';else{char q[12];int z=0;while(v&&z<11){q[z++]=(char)('0'+v%10);v/=10;}while(z)n[k++]=q[--z];}n[k]=0;text(w->x+20,w->y+380,"SCORE",rgb(150,170,205),1);text(w->x+62,w->y+380,n,rgb(100,255,180),1);text(w->x+150,w->y+380,"ARROWS / SPACE",rgb(180,195,220),1);if(!snake_game)text(w->x+100,w->y+402,"SPACE START",rgb(255,170,100),1);}

/* Minesweeper: 9x9 board, 10 mines, keyboard cursor + reveal/flag. */
static uint8_t mine_cell[81],mine_reveal[81],mine_flag[81];
static int mine_x=0,mine_y=0,mine_left=10,mine_game=0,mine_over=0,mine_won=0;
static uint32_t mine_rng=0x47a1cc29u;
static uint32_t mine_rand(void){mine_rng^=mine_rng<<13;mine_rng^=mine_rng>>17;mine_rng^=mine_rng<<5;return mine_rng;}
static int mine_adj(int x,int y){int n=0;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if(dx||dy){int a=x+dx,b=y+dy;if(a>=0&&a<9&&b>=0&&b<9&&mine_cell[b*9+a])n++;}return n;}
static void mine_flood(int x,int y){if(x<0||x>=9||y<0||y>=9)return;int i=y*9+x;if(mine_reveal[i]||mine_flag[i])return;mine_reveal[i]=1;if(mine_adj(x,y)==0)for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if(dx||dy)mine_flood(x+dx,y+dy);}
static void mine_new(void){for(int i=0;i<81;i++){mine_cell[i]=mine_reveal[i]=mine_flag[i]=0;}for(int m=0;m<10;){int i=(int)(mine_rand()%81);if(!mine_cell[i]){mine_cell[i]=1;m++;}}mine_x=mine_y=0;mine_left=10;mine_game=1;mine_over=mine_won=0;}
static void mine_reveal_at(void){if(!mine_game||mine_flag[mine_y*9+mine_x])return;int i=mine_y*9+mine_x;if(mine_cell[i]){mine_over=1;mine_game=0;for(int j=0;j<81;j++)if(mine_cell[j])mine_reveal[j]=1;return;}mine_flood(mine_x,mine_y);int safe=0;for(int j=0;j<81;j++)if(!mine_cell[j]&&!mine_reveal[j])safe=1;if(!safe){mine_won=1;mine_game=0;}}
static void mine_flag_at(void){if(!mine_game)return;int i=mine_y*9+mine_x;if(mine_reveal[i])return;if(mine_flag[i]){mine_flag[i]=0;mine_left++;}else if(mine_left>0){mine_flag[i]=1;mine_left--;}}
static void draw_mines(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"MINES",rgb(100,255,160),1);int ox=w->x+25,oy=w->y+62,cell=34;for(int y=0;y<9;y++)for(int x=0;x<9;x++){int i=y*9+x;uint16_t c=mine_reveal[i]?rgb(34,40,55):rgb(12,16,28);if(mine_flag[i])c=rgb(75,45,70);roundrect(ox+x*cell,oy+y*cell,32,32,4,c);if(mine_reveal[i]){if(mine_cell[i])text(ox+x*cell+11,oy+y*cell+8,"*",rgb(255,100,100),2);else{int a=mine_adj(x,y);if(a){char z[2]={(char)('0'+a),0};text(ox+x*cell+11,oy+y*cell+8,z,rgb(90,210,255),2);}}}else if(mine_flag[i])text(ox+x*cell+11,oy+y*cell+8,"F",rgb(255,180,100),2);if(x==mine_x&&y==mine_y)roundrect(ox+x*cell,oy+y*cell,32,32,4,rgb(70,210,255));}text(w->x+25,w->y+382,"ARROWS MOVE  ENTER OPEN  F FLAG",rgb(175,190,215),1);char z[16];z[0]='0'+(mine_left/10);z[1]='0'+(mine_left%10);z[2]=0;text(w->x+25,w->y+402,"MINES:",rgb(180,195,220),1);text(w->x+67,w->y+402,z,rgb(255,170,100),1);if(mine_over)text(w->x+150,w->y+402,"BOOM - SPACE",rgb(255,100,100),1);else if(mine_won)text(w->x+150,w->y+402,"CLEAR! - SPACE",rgb(100,255,170),1);}

/* Breakout */
static int br_x=235,br_y=360,br_dx=2,br_dy=-2,br_pad=65,br_score=0,br_game=0,br_tick=0;
static uint8_t br_bricks[40];
static void br_new(void){for(int i=0;i<40;i++)br_bricks[i]=1;br_x=245;br_y=360;br_dx=2;br_dy=-2;br_pad=65;br_score=0;br_tick=0;br_game=1;}
static void br_step(void){if(!br_game)return;br_x+=br_dx;br_y+=br_dy;if(br_x<8){br_x=8;br_dx=-br_dx;}if(br_x>472){br_x=472;br_dx=-br_dx;}if(br_y<40){br_y=40;br_dy=-br_dy;}int py=370;if(br_y>=350&&br_y<=380&&br_x>=br_pad&&br_x<=br_pad+70){br_dy=-2;br_dx += (br_x-(br_pad+35))/18;if(br_dx>4)br_dx=4;if(br_dx<-4)br_dx=-4;}if(br_y>405){br_game=0;return;}for(int r=0;r<4;r++)for(int c=0;c<10;c++)if(br_bricks[r*10+c]){int bx=10+c*47,by=55+r*22;if(br_x+8>=bx&&br_x<=bx+43&&br_y+8>=by&&br_y<=by+17){br_bricks[r*10+c]=0;br_dy=-br_dy;br_score+=10;return;}}}
static void draw_breakout(Window*w){window_bg(w);titlebar(w);text(w->x+18,w->y+40,"BREAKOUT",rgb(100,255,160),1);int ox=w->x+15,oy=w->y+58;roundrect(ox,oy,470,320,5,rgb(4,7,14));for(int r=0;r<4;r++)for(int c=0;c<10;c++)if(br_bricks[r*10+c])roundrect(ox+10+c*47,oy+10+r*22,43,17,3,(r==0)?rgb(255,100,120):(r==1?rgb(255,190,80):(r==2?rgb(100,190,255):rgb(110,240,170))));roundrect(ox+br_x,oy+br_y,9,9,4,rgb(245,245,255));roundrect(ox+br_pad,oy+292,70,9,4,rgb(90,220,255));char z[16];int v=br_score,k=0;if(!v)z[k++]='0';else{char q[12];int n=0;while(v&&n<11){q[n++]=(char)('0'+v%10);v/=10;}while(n)z[k++]=q[--n];}z[k]=0;text(w->x+20,w->y+390,"SCORE",rgb(150,170,205),1);text(w->x+62,w->y+390,z,rgb(100,255,180),1);text(w->x+150,w->y+390,"LEFT / RIGHT",rgb(180,195,220),1);if(!br_game)text(w->x+315,w->y+390,"SPACE START",rgb(255,170,100),1);}

static void draw_tetris(Window*w){
 window_bg(w);titlebar(w);
 int ox=w->x+18,oy=w->y+42,cell=16;
 roundrect(ox,oy,10*cell+2,20*cell+2,3,rgb(5,7,14));
 for(int y=0;y<20;y++)for(int x=0;x<10;x++){uint8_t v=tboard[y*10+x];if(v){uint8_t r=(v==1)?80:(v==2?255:(v==3?80:(v==4?220:(v==5?80:(v==6?255:180)))));uint8_t g=(v==1)?220:(v==2?150:(v==3?120:(v==4?210:(v==5?80:(v==6?90:80)))));uint8_t b=(v==1)?255:(v==2?60:(v==3?220:(v==4?80:(v==5?220:(v==6?220:255)))));roundrect(ox+1+x*cell,oy+1+y*cell,14,14,2,rgb(r,g,b));}}
 if(tgame)for(int y=0;y<4;y++)for(int x=0;x<4;x++)if(tshape_cell(tpiece,trot,x,y)){int bx=tx+x,by=ty+y;if(bx>=0&&bx<10&&by>=0&&by<20)roundrect(ox+1+bx*cell,oy+1+by*cell,14,14,2,tcols[tpiece+1]);}
 text(w->x+188,w->y+55,"TETRIS",rgb(225,231,248),1);
 text(w->x+188,w->y+82,"SCORE",rgb(150,170,205),1);char num[16];int n=tscore,di=0;if(n==0)num[di++]='0';else{char rev[12];int k=0;while(n&&k<11){rev[k++]=(char)('0'+n%10);n/=10;}while(k)num[di++]=rev[--k];}num[di]=0;text(w->x+188,w->y+98,num,rgb(100,255,180),1);
 text(w->x+188,w->y+124,"ARROWS MOVE",rgb(180,195,220),1);text(w->x+188,w->y+140,"UP ROTATE",rgb(180,195,220),1);text(w->x+188,w->y+156,"DOWN DROP",rgb(180,195,220),1);text(w->x+188,w->y+172,"SPACE START",rgb(180,195,220),1);
 if(!tgame)text(w->x+188,w->y+205,"PRESS SPACE",rgb(255,170,100),1);
}
static void draw_browser(Window*w){window_bg(w);titlebar(w);roundrect(w->x+16,w->y+32,w->w-32,24,5,rgb(236,239,247));text(w->x+26,w->y+40,browser_url,rgb(15,18,28),1);if(browser_focus)fill(w->x+26+browser_url_n*6,w->y+39,5,9,rgb(20,25,35));roundrect(w->x+w->w-62,w->y+32,38,24,5,rgb(55,180,210));text(w->x+w->w-52,w->y+40,"GO",rgb(0,0,0),1);int yy=w->y+72;for(int i=0;i<browser_n&&yy<w->y+w->h-24;i++){text(w->x+22,yy,browser_lines[i],rgb(225,230,245),1);yy+=16;}}
static void cursor(void){for(int i=0;i<11;i++)for(int j=0;j<=i/2;j++)putp(mx+i,my+j,rgb(255,255,255));}
static void present(void){
 /* Copy the completed back buffer to the physical LFB in scanline order. */
 for(int y=0;y<H;y++){
  volatile uint16_t *dst=(volatile uint16_t*)((uintptr_t)fb_phys+(uintptr_t)y*pitch);
  volatile const uint16_t *src=backbuf+(uintptr_t)y*W;
  for(int x=0;x<W;x++)dst[x]=src[x];
 }
}
static void redraw(void){
 desktop();
 for(int i=0;i<12;i++)if(win[i].open){
  switch(win[i].app){case APP_TERM:draw_term(&win[i]);break;case APP_FILES:draw_files(&win[i]);break;case APP_EDIT:draw_editor(&win[i]);break;case APP_PAINT:draw_paint(&win[i]);break;case APP_TASKS:draw_tasks(&win[i]);break;case APP_BROWSER:draw_browser(&win[i]);break;case APP_TETRIS:draw_tetris(&win[i]);break;case APP_SNAKE:draw_snake(&win[i]);break;case APP_MINES:draw_mines(&win[i]);break;case APP_BREAKOUT:draw_breakout(&win[i]);break;case APP_GAMES:draw_games(&win[i]);break;case APP_ARCADE:draw_arcade(&win[i]);break;}
 }
 taskbar();
 cursor();
 present();
}

static void term_line(const char*s){
 if(term_lines<9){scpy(term_out[term_lines++],s,55);return;}
 for(int i=1;i<9;i++)scpy(term_out[i-1],term_out[i],55);
 scpy(term_out[8],s,55);
}
static int starts(const char*s,const char*p){while(*p){if(*s++!=*p++)return 0;}return 1;}
static void term_command(const char*cmd){
 char c[48];scpy(c,cmd,48);
 for(int i=0;c[i];i++)if(c[i]>='a'&&c[i]<='z')c[i]=(char)(c[i]-'a'+'A');
 if(!c[0])return;
 if(starts(c,"VER") && c[3]==0){term_line("NAGISINNRA OS V27");term_line("32-BIT I386 / VBE 800X600 / NET");}
 else if(starts(c,"HELP") && c[4]==0){term_line("HELP VER DIR TYPE ABOUT CLS REBOOT");}
 else if(starts(c,"ABOUT") && c[5]==0){term_line("NAGISINNRA OS - FAT12 DESKTOP");term_line("WINDOWS / EDITOR / PAINT / TASKS");}
 else if(starts(c,"CLS") && c[3]==0){term_lines=0;for(int i=0;i<9;i++)term_out[i][0]=0;}
 else if(starts(c,"DIR") && c[3]==0){term_line("FAT12:");for(int i=0;i<32&&term_lines<9;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;char n[16];name83(n,e);term_line(n);}}
 else if(starts(c,"TYPE ")){int ent=find_entry(c+5);if(ent<0)term_line("FILE NOT FOUND");else{char b[56];read_file(ent,b,sizeof(b));if(!b[0])term_line("(EMPTY)");else{char line[55];int j=0;for(int i=0;b[i]&&j<54;i++){if(b[i]=='\r')continue;if(b[i]=='\n'){line[j]=0;term_line(line);j=0;}else line[j++]=b[i];}if(j){line[j]=0;term_line(line);}}}}
 else term_line("BAD COMMAND - TYPE HELP");
}
static int alloc_cluster(void){for(uint16_t cl=8;cl<95;cl++)if(fat12_get(cl)==0){/* set later */return cl;}return -1;}
static void fat12_set(uint16_t cl,uint16_t val){uint32_t o=512+((uint32_t)cl*3)/2;uint16_t v=fs[o]|((uint16_t)fs[o+1]<<8);if(cl&1){v=(v&0x000f)|((val&0xfff)<<4);}else{v=(v&0xf000)|(val&0xfff);}fs[o]=(uint8_t)v;fs[o+1]=(uint8_t)(v>>8);uint32_t fo=1024+o;fs[fo]=fs[o];fs[fo+1]=fs[o+1];}
static int find_free_entry(void){for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0||e[0]==0xe5)return i;}return -1;}
static void free_chain(uint16_t cl){int guard=0;while(cl>=2&&cl<0xff8&&guard++<100){uint16_t nx=fat12_get(cl);fat12_set(cl,0);cl=nx;}}
static int write_file_entry(int ent,const uint8_t*data,uint32_t sz){uint8_t*e=fs+1536+ent*32;uint16_t old=e[26]|((uint16_t)e[27]<<8);if(old>=2)free_chain(old);uint32_t need=(sz+511)/512;uint16_t first=0,prev=0;for(uint32_t i=0;i<need;i++){int cl=alloc_cluster();if(cl<0){if(first)free_chain(first);return 0;}if(!first)first=(uint16_t)cl;if(prev)fat12_set(prev,(uint16_t)cl);fat12_set((uint16_t)cl,0xfff);prev=(uint16_t)cl;uint8_t*p=cluster_ptr((uint16_t)cl);for(int j=0;j<512;j++)p[j]=0;uint32_t off=i*512,take=sz-off;if(take>512)take=512;for(uint32_t j=0;j<take;j++)p[j]=data[off+j];}
 for(int i=0;i<11;i++)e[i]=' ';e[11]=0x20;scpy((char*)e,"EDIT     TXT",12); /* overwrite with canonical 8.3 below */
 e[0]='E';e[1]='D';e[2]='I';e[3]='T';e[4]=' ';e[5]=' ';e[6]=' ';e[7]=' ';e[8]='T';e[9]='X';e[10]='T';e[26]=(uint8_t)first;e[27]=(uint8_t)(first>>8);e[28]=(uint8_t)sz;e[29]=(uint8_t)(sz>>8);e[30]=(uint8_t)(sz>>16);e[31]=(uint8_t)(sz>>24);return 1;}
static void save_editor(void){int ent=editor_file;if(ent<0)ent=find_entry("EDIT.TXT");if(ent<0)ent=find_free_entry();if(ent>=0&&write_file_entry(ent,(const uint8_t*)editor,(uint32_t)editor_n)){editor_file=ent;term_line("EDITOR: SAVED EDIT.TXT");}}
static void paint_clear(void){for(int i=0;i<PW*PH;i++)paintbuf[i]=rgb(8,9,16);}
static void paint_at(int x,int y){if(x<0||x>=PW||y<0||y>=PH)return;paintbuf[y*PW+x]=rgb(80,220,255);if(x+1<PW)paintbuf[y*PW+x+1]=rgb(80,220,255);if(y+1<PH)paintbuf[(y+1)*PW+x]=rgb(80,220,255);}
static void load_editor(int ent){if(ent>=0){editor_file=ent;editor_n=read_file(ent,editor,sizeof(editor));win[APP_EDIT].open=1;active=APP_EDIT;}}
static void click_window(int id){Window*w=&win[id];if(inside(w->x+w->w-28,w->y,28,22,mx,my)){w->open=0;active=-1;drag_win=-1;return;}if(inside(w->x,w->y,w->w,22,mx,my)){active=id;drag_win=id;w->ox=mx-w->x;w->oy=my-w->y;return;}active=id;if(id!=APP_BROWSER)browser_focus=0;
 if(id==APP_FILES){int row=(my-(w->y+76))/17;if(row>=0&&row<12){int seen=0;for(int i=0;i<32;i++){uint8_t*e=fs+1536+i*32;if(e[0]==0)break;if(e[0]==0xe5||e[11]==0x0f)continue;if(seen++==row){load_editor(i);win[APP_EDIT].open=1;active=APP_EDIT;return;}}}}
 if(id==APP_EDIT){
   if(inside(w->x+18,w->y+42,w->w-36,w->h-92,mx,my)){editor_col=(mx-(w->x+18))/12;editor_row=(my-(w->y+76))/17;if(editor_col<0)editor_col=0;if(editor_row<0)editor_row=0;active=APP_EDIT;}
   else if(inside(w->x+18,w->y+w->h-42,76,28,mx,my)){save_editor();}
   else if(inside(w->x+104,w->y+w->h-42,76,28,mx,my)){load_editor(find_entry("README.TXT"));}
 }
 if(id==APP_PAINT){if(inside(w->x+18,w->y+72,PW,PH,mx,my)){active=APP_PAINT;paint_at(mx-(w->x+18),my-(w->y+72));}else if(inside(w->x+20,w->y+w->h-42,22,22,mx,my)){paint_clear();}}
 if(id==APP_TETRIS){active=APP_TETRIS;if(inside(w->x+188,w->y+190,95,30,mx,my))tnew();}
 if(id==APP_GAMES){
   /* Games Center: explicit one-to-one mapping.  Never infer the target from
      the window number; this prevents Tetris/Snake/etc. from opening the wrong game. */
   int gx=w->x+18, gy=w->y+80;
   for(int g=0;g<10;g++){
     int col=g%2,row=g/2,bx=gx+col*190,by=gy+row*55;
     if(inside(bx,by,175,44,mx,my)){
       for(int i=6;i<=11;i++)win[i].open=0;
       if(g==0){win[APP_TETRIS].open=1;active=APP_TETRIS;tnew();}
       else if(g==1){win[APP_SNAKE].open=1;active=APP_SNAKE;snake_new();}
       else if(g==2){win[APP_MINES].open=1;active=APP_MINES;mine_new();}
       else if(g==3){win[APP_BREAKOUT].open=1;active=APP_BREAKOUT;br_new();}
       else {win[APP_ARCADE].open=1;active=APP_ARCADE;arcade_new(g-4);}
       return;
     }
   }
 }
 if(id==APP_ARCADE){if(inside(w->x+w->w-115,w->y,w->w,22,mx,my)){win[APP_ARCADE].open=0;active=APP_GAMES;return;}if(arcade_game==4&&inside(w->x+70,w->y+80,350,190,mx,my)&&react_ready&&!react_done){react_done=1;react_score=react_tick;return;}}
 if(id==APP_BROWSER){
  if(inside(w->x+16,w->y+32,w->w-100,24,mx,my)){active=APP_BROWSER;browser_focus=1;}
  else if(inside(w->x+w->w-62,w->y+32,38,24,mx,my)){browser_focus=1;browser_url[browser_url_n]=0;browser_open(browser_url);}
}
 if(id==APP_TASKS){int row=0;for(int i=0;i<10;i++)if(win[i].open){if(inside(w->x+10,w->y+62+row*25,w->w-20,24,mx,my)){active=i;return;}row++;}}
}
static int top_at(int x,int y){for(int i=11;i>=0;i--)if(win[i].open&&inside(win[i].x,win[i].y,win[i].w,win[i].h,x,y))return i;return -1;}
static void task_click(void){
 if(my<578)return;int id=-1,x=42;int ids[]={0,1,2,3,4,5,10};
 for(int k=0;k<7;k++){int ww=(k==6)?58:48;if(mx>=x&&mx<x+ww){id=ids[k];break;}x+=ww+4;}
 if(id>=0){win[id].open=1;active=id;browser_focus=(id==APP_BROWSER);if(id==APP_BROWSER&&browser_n==0)browser_home();drag_win=-1;}
}
static void mouse_actions(void){
 if(mbuttons&1&&active==APP_PAINT&&win[APP_PAINT].open&&inside(win[APP_PAINT].x+18,win[APP_PAINT].y+72,PW,PH,mx,my)){paint_at(mx-(win[APP_PAINT].x+18),my-(win[APP_PAINT].y+72));return;}
 if(!mpress)return;mpress=0;if(my>=578){task_click();redraw();return;}int id=top_at(mx,my);if(id>=0){click_window(id);redraw();}
}
static void editor_insert(char c){if(editor_n>=4095)return;if(editor_col<0)editor_col=0;int pos=0,row=0,col=0;while(pos<editor_n&&row<editor_row){if(editor[pos++]=='\n')row++;}while(pos<editor_n&&row==editor_row&&col<editor_col){if(editor[pos]=='\n')break;pos++;col++;}for(int i=editor_n;i>pos;i--)editor[i]=editor[i-1];editor[pos]=c;editor_n++;editor_row=row+(c=='\n');editor_col=(c=='\n')?0:col+1;editor[editor_n]=0;}
static void editor_back(void){if(editor_n<=0)return;int pos=0,row=0,col=0;while(pos<editor_n&&row<editor_row){if(editor[pos++]=='\n')row++;}while(pos<editor_n&&row==editor_row&&col<editor_col){pos++;col++;}if(pos>0){pos--;if(editor[pos]=='\n'){editor_row=editor_row?editor_row-1:0;editor_col=0;}else editor_col=editor_col?editor_col-1:0;for(int i=pos;i<editor_n;i++)editor[i]=editor[i+1];editor_n--;}}
static void type_key(uint8_t s){
 char c=keychar(s);
 if(active==APP_TETRIS&&win[APP_TETRIS].open){
  if(s==0x48){if(!tgame)tnew();else if(tvalid(tx,ty,tpiece,(trot+1)&3))trot=(trot+1)&3;return;}
  if(s==0x4b){if(!tgame)tnew();else if(tvalid(tx-1,ty,tpiece,trot))tx--;return;}
  if(s==0x4d){if(!tgame)tnew();else if(tvalid(tx+1,ty,tpiece,trot))tx++;return;}
  if(s==0x50){if(!tgame)tnew();else while(tvalid(tx,ty+1,tpiece,trot))ty++;return;}
  if(c==' '){tnew();return;}
  return;
 }
 if(active==APP_EDIT&&win[APP_EDIT].open){
  if(s==0x4b){if(editor_col>0)editor_col--;return;} if(s==0x4d){editor_col++;return;}
  if(s==0x48){if(editor_row>0)editor_row--;return;} if(s==0x50){editor_row++;return;}
  if(c=='\b'){editor_back();return;} if(c=='\n'){editor_insert('\n');return;}
  if(c>=32&&c<=126){editor_insert(c);return;} return;
 }
 if(active==APP_SNAKE&&win[APP_SNAKE].open){
  if(c==' '){snake_new();return;}if(s==0x48&&snake_dir!=2)snake_next=0;if(s==0x4d&&snake_dir!=3)snake_next=1;if(s==0x50&&snake_dir!=0)snake_next=2;if(s==0x4b&&snake_dir!=1)snake_next=3;return;
 }
 if(active==APP_MINES&&win[APP_MINES].open){
  if(c==' '){mine_new();return;}if(s==0x48&&mine_y>0)mine_y--;if(s==0x50&&mine_y<8)mine_y++;if(s==0x4b&&mine_x>0)mine_x--;if(s==0x4d&&mine_x<8)mine_x++;if(c=='\n')mine_reveal_at();if(c=='f'||c=='F')mine_flag_at();return;
 }
 if(active==APP_BREAKOUT&&win[APP_BREAKOUT].open){
  if(c==' '){br_new();return;}if(s==0x4b&&br_pad>18)br_pad-=8;if(s==0x4d&&br_pad<395)br_pad+=8;return;
 }
 if(active==APP_ARCADE&&win[APP_ARCADE].open){
  if(s==0x01){win[APP_ARCADE].open=0;win[APP_GAMES].open=1;active=APP_GAMES;return;}
  if(arcade_game==0){if(c==' '){pong_new();return;}if(s==0x11&&pong_l>5)pong_l-=8;if(s==0x1f&&pong_l<230)pong_l+=8;if(s==0x48&&pong_r>5)pong_r-=8;if(s==0x50&&pong_r<230)pong_r+=8;}
  else if(arcade_game==1){if(c==' '){g2048_new();return;}if(s==0x48)g2048_move(0);else if(s==0x4d)g2048_move(1);else if(s==0x50)g2048_move(2);else if(s==0x4b)g2048_move(3);}
  else if(arcade_game==2){if(c==' '){dodger_new();return;}if(s==0x4b&&dodger_x>25)dodger_x-=8;if(s==0x4d&&dodger_x<455)dodger_x+=8;}
  else if(arcade_game==3){if(c==' '){flap_new();flap_v=-5;return;}}
  else if(arcade_game==4){if(c==' '){react_new();return;}}
  else if(arcade_game==5){if(c==' '){maze_new();return;}int nx=maze_x,ny=maze_y;if(s==0x48)ny--;if(s==0x50)ny++;if(s==0x4b)nx--;if(s==0x4d)nx++;if(nx>=0&&nx<16&&ny>=0&&ny<12&&!maze_map[ny][nx]){maze_x=nx;maze_y=ny;if(nx==14&&ny==10)maze_won=1;}}
  return;
 }
 if(browser_focus&&win[APP_BROWSER].open){if(c=='\b'){if(browser_url_n>0)browser_url[--browser_url_n]=0;return;}if(c=='\n'){browser_url[browser_url_n]=0;browser_open(browser_url);return;}if(c=='\t')return;if(c>=32&&c<=126&&browser_url_n<62){browser_url[browser_url_n++]=c;browser_url[browser_url_n]=0;}return;}
 if(active==APP_BROWSER&&win[APP_BROWSER].open){if(c=='\b'){if(browser_url_n>0)browser_url[--browser_url_n]=0;return;}if(c=='\n'){browser_url[browser_url_n]=0;browser_open(browser_url);return;}if(c>=32&&c<=126&&browser_url_n<62){browser_url[browser_url_n++]=c;browser_url[browser_url_n]=0;}return;}
 if(c=='\b'){if(term_n>0)term_in[--term_n]=0;return;}if(c=='\n'){term_in[term_n]=0;term_command(term_in);term_n=0;term_in[0]=0;return;}if(c=='\t')return;if(c>=32&&c<=126&&term_n<44){if(c>='a'&&c<='z')c=(char)(c-'a'+'A');term_in[term_n++]=c;term_in[term_n]=0;}
}
void kernel_main(void){
 uint8_t*mi=(uint8_t*)VBE_INFO;
 fb_phys=mi[0x28]|((uint32_t)mi[0x29]<<8)|((uint32_t)mi[0x2a]<<16)|((uint32_t)mi[0x2b]<<24);
 pitch=mi[0x10]|((uint32_t)mi[0x11]<<8);
 if(!fb_phys||!pitch){fb_phys=0xE0000000u;pitch=W*2;}
 /* Clear the back buffer once before the first frame. */
 for(uint32_t i=0;i<(uint32_t)W*H;i++)backbuf[i]=0;
 net_init();
 mouse_init();
 init_windows();
 term_n=0;term_in[0]=0;term_lines=0;
 for(int i=0;i<9;i++)term_out[i][0]=0;
 term_line("TYPE HELP FOR COMMANDS");
 term_line("NET: NE2000 / HTTP READY");
 editor_n=0;editor[0]=0;editor_row=0;editor_col=0;browser_url[0]=0;browser_url_n=0;browser_n=0;browser_focus=0;
 tcols[1]=rgb(80,220,255);tcols[2]=rgb(255,120,80);tcols[3]=rgb(90,140,255);tcols[4]=rgb(240,220,80);tcols[5]=rgb(80,220,120);tcols[6]=rgb(190,100,255);tcols[7]=rgb(255,100,180);tgame=0;tnew();tgame=0;snake_game=0;mine_game=0;mine_over=mine_won=0;br_game=0;paint_clear();
 redraw();
 for(;;){
  int changed=mouse_poll();
  if(active==APP_TETRIS&&tgame){if(++timer>=180000){timer=0;tstep();changed=1;}}
  if(active==APP_SNAKE&&snake_game){if(++snake_tick>=90000){snake_tick=0;snake_step();changed=1;}}
  if(active==APP_BREAKOUT&&br_game){if(++br_tick>=35000){br_tick=0;br_step();changed=1;}}
  if(active==APP_ARCADE&&arcade_game==0&&pong_run){if(++pong_tick>=30000){pong_tick=0;pong_step();changed=1;}}
  if(active==APP_ARCADE&&arcade_game==2&&dodger_run){if(++dodger_tick>=25000){dodger_tick=0;dodger_step();changed=1;}}
  if(active==APP_ARCADE&&arcade_game==3&&flap_run){if(++flap_tick>=22000){flap_tick=0;flap_step();changed=1;}}
  if(active==APP_ARCADE&&arcade_game==4&&!react_done){if(react_wait>0){react_wait--;if(react_wait==0)react_ready=1;react_tick++;changed=1;}}
  if(drag_win>=0){
   Window*w=&win[drag_win];
   if(mbuttons&1){
    int nx=mx-w->ox,ny=my-w->oy;
    if(nx<0)nx=0;if(ny<46)ny=46;if(nx+w->w>W)nx=W-w->w;if(ny+w->h>568)ny=568-w->h;
    w->x=nx;w->y=ny;changed=1;
   }else drag_win=-1;
  }
  uint8_t s;int key_guard=0;
  while(key_guard++<16 && keyboard_get(&s)){
   changed=1;
   if(s==0x3b){win[0].open=1;active=0;browser_focus=0;}
   else if(s==0x3c){win[1].open=1;active=1;browser_focus=0;}
   else if(s==0x3d){win[2].open=1;active=2;browser_focus=0;}
   else if(s==0x3e){win[3].open=1;active=3;browser_focus=0;}
   else if(s==0x3f){win[4].open=1;active=4;browser_focus=0;}
   else if(s==0x40){win[5].open=1;active=5;browser_focus=1;if(browser_n==0)browser_home();}
   else if(s==0x41){win[6].open=1;active=6;browser_focus=0;if(!tgame)tnew();}
   else if(s==0x42){win[7].open=1;active=7;browser_focus=0;if(!snake_game)snake_new();}
   else if(s==0x43){win[8].open=1;active=8;browser_focus=0;if(!mine_game&&!mine_over&&!mine_won)mine_new();}
   else if(s==0x44){win[10].open=1;active=10;browser_focus=0;}
   else if(s==0x57){win[11].open=1;active=11;browser_focus=0;}
   else if(s==0x01){for(int i=0;i<12;i++)win[i].open=0;active=-1;browser_focus=0;}
   else type_key(s);
  }
  if(mpress)mouse_actions();
  if(changed)redraw();
 }
}
